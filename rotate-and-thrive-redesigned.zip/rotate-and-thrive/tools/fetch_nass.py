#!/usr/bin/env python3
"""Fetch California county crop acreage from the USDA NASS Quick Stats API and cache it as data/nass.js
(the site never calls NASS from the browser: the API needs a personal key and does not allow browser requests).

Usage:
  export NASS_API_KEY=your-key        # free key: https://quickstats.nass.usda.gov/api
  python3 tools/fetch_nass.py [year]  # default 2022 = latest Census of Agriculture (county detail)

Writes raw responses to raw/nass/, the site cache to data/nass.js, and a review list of NASS
commodities that did not map to a planner crop to tools/nass_unmatched.txt."""
import json, os, subprocess, sys, time, urllib.parse
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KEY = os.environ.get('NASS_API_KEY', '').strip()
if not KEY: sys.exit('Set NASS_API_KEY first (free key: https://quickstats.nass.usda.gov/api).')
YEAR = sys.argv[1] if len(sys.argv) > 1 else '2022'
API = 'https://quickstats.nass.usda.gov/api/'
RAW = os.path.join(ROOT, 'raw', 'nass'); os.makedirs(RAW, exist_ok=True)

def call(endpoint, **params):
    q = urllib.parse.urlencode({'key': KEY, 'format': 'JSON', **params})
    for attempt in range(4):
        r = subprocess.run(['curl', '-sS', '-m', '180', API + endpoint + '/?' + q], capture_output=True)
        if r.returncode == 0:
            try:
                j = json.loads(r.stdout)
            except ValueError:
                j = {'error': [r.stdout[:200].decode(errors='replace')]}
            if 'error' not in j: return j
            if 'unauthorized' in str(j['error']): sys.exit('NASS rejected the API key (unauthorized).')
            if 'exceeds limit' in str(j['error']): sys.exit('Query too large: ' + str(j['error']))
            print('  NASS error:', j['error']); return {'data': []}
        time.sleep(5 * (attempt + 1))
    sys.exit('NASS Quick Stats did not respond: ' + r.stderr.decode(errors='replace')[:200])

BASE = dict(source_desc='CENSUS', year=YEAR, agg_level_desc='COUNTY', state_alpha='CA', domain_desc='TOTAL')
QUERIES = {
    'harvested': dict(BASE, sector_desc='CROPS', statisticcat_desc='AREA HARVESTED', unit_desc='ACRES'),
    'bearing':   dict(BASE, sector_desc='CROPS', statisticcat_desc='AREA BEARING & NON-BEARING', unit_desc='ACRES'),
    'grown':     dict(BASE, sector_desc='CROPS', statisticcat_desc='AREA GROWN', unit_desc='ACRES'),   # berries (e.g. strawberries)
    'cropland':  dict(BASE, short_desc='AG LAND, CROPLAND, HARVESTED - ACRES'),
}
rows = {}
for name, q in QUERIES.items():
    n = call('get_counts', **q).get('count', 0)
    print(f'{name}: {n} records')
    if n > 50000: sys.exit(f'{name} query has {n} records (> 50,000 API limit); narrow it.')
    data = call('api_GET', **q).get('data', []) if n else []
    json.dump(data, open(os.path.join(RAW, f'ca_county_{name}_{YEAR}.json'), 'w'))
    rows[name] = data; time.sleep(1)

def val(r):
    v = str(r.get('Value', '')).replace(',', '').strip()
    try: return float(v), False
    except ValueError: return 0.0, v in ('(D)', '(Z)')      # (D) = withheld to avoid disclosing a single farm
def fips(r):
    c = (r.get('county_ansi') or '').strip()
    return (r.get('state_fips_code', '06') + c.zfill(3)) if c else None

# planner crop id -> which NASS rows count. stat: 'harvested' (field/vegetable crops), 'bearing' (trees & vines) or 'grown' (berries)
SPEC = {
 'tomato': ('harvested', ['TOMATOES'], None), 'strawberry': ('grown', ['STRAWBERRIES'], None), 'lettuce': ('harvested', ['LETTUCE'], None),
 'broccoli': ('harvested', ['BROCCOLI'], None), 'spinach': ('harvested', ['SPINACH'], None), 'carrot': ('harvested', ['CARROTS'], None),
 'garlic': ('harvested', ['GARLIC'], None), 'onion': ('harvested', ['ONIONS'], None), 'melon': ('harvested', ['MELONS', 'CANTALOUPS', 'HONEYDEWS'], None),
 'artichoke': ('harvested', ['ARTICHOKES'], None), 'corn': ('harvested', ['CORN'], None), 'cotton': ('harvested', ['COTTON'], None),
 'wheat': ('harvested', ['WHEAT'], None), 'safflower': ('harvested', ['SAFFLOWER'], None), 'sunflower': ('harvested', ['SUNFLOWER'], None),
 'garbanzo': ('harvested', ['CHICKPEAS'], None), 'drybean': ('harvested', ['BEANS'], lambda c: c.startswith('DRY EDIBLE')),
 'sorghum': ('harvested', ['SORGHUM'], None), 'rice': ('harvested', ['RICE'], None), 'alfalfa': ('harvested', ['HAY'], lambda c: c == 'ALFALFA'),
 'almond': ('bearing', ['ALMONDS'], None), 'walnut': ('bearing', ['WALNUTS'], None), 'pistachio': ('bearing', ['PISTACHIOS'], None),
 'peach': ('bearing', ['PEACHES'], None), 'citrus': ('bearing', ['ORANGES', 'LEMONS', 'TANGERINES', 'MANDARINS', 'GRAPEFRUIT', 'TANGELOS', 'LIMES'], None),
 'avocado': ('bearing', ['AVOCADOS'], None), 'olive': ('bearing', ['OLIVES'], None), 'pomegranate': ('bearing', ['POMEGRANATES'], None),
 'date': ('bearing', ['DATES'], None), 'jojoba': ('harvested', ['JOJOBA'], None), 'winegrape': ('bearing', ['GRAPES'], None), 'tablegrape': ('bearing', ['GRAPES'], None),
}
PRACTICE = ['ALL PRODUCTION PRACTICES', 'IN THE OPEN']
def pick(rs, cls_ok):
    """Total acres for one county & commodity without double counting sub-categories."""
    for prac in PRACTICE:
        p = [r for r in rs if r.get('prodn_practice_desc') == prac]
        if p: rs = p; break
    else:
        return None
    classes = {r.get('class_desc') for r in rs}
    if cls_ok: classes = {c for c in classes if c != 'ALL CLASSES' and cls_ok(c)}
    elif 'ALL CLASSES' in classes: classes = {'ALL CLASSES'}
    total, withheld, seen = 0.0, False, False
    for c in classes:
        rc = [r for r in rs if r.get('class_desc') == c]
        utils = {r.get('util_practice_desc') for r in rc}
        use = {'ALL UTILIZATION PRACTICES'} if 'ALL UTILIZATION PRACTICES' in utils else utils
        for r in rc:
            if r.get('util_practice_desc') in use:
                v, d = val(r); total += v; withheld |= d; seen = True
    if not seen: return None
    return round(total) if total or not withheld else 'D'

by = {}  # (stat, fips, commodity) -> rows
names = {}
for stat in ('harvested', 'bearing', 'grown'):
    for r in rows[stat]:
        f = fips(r)
        if not f: continue
        names[f] = r.get('county_name', '').title()
        by.setdefault((stat, f, r.get('commodity_desc')), []).append(r)
counties = {}
for f in sorted(names):
    crops = {}
    for cid, (stat, comms, cls_ok) in SPEC.items():
        parts = [pick(by[(stat, f, c)], cls_ok) for c in comms if (stat, f, c) in by]
        parts = [p for p in parts if p is not None]
        if not parts: continue
        nums = [p for p in parts if p != 'D']
        crops[cid] = round(sum(nums)) if nums else 'D'
    counties[f] = {'name': names[f], 'crops': crops}
for r in rows['cropland']:
    f = fips(r)
    if f:
        v, d = val(r); counties.setdefault(f, {'name': r.get('county_name', '').title(), 'crops': {}})['cropland'] = round(v) if not d else 'D'

used = {c for _, comms, _ in SPEC.values() for c in comms}
unmatched = {}
for stat in ('harvested', 'bearing', 'grown'):
    for r in rows[stat]:
        if r.get('commodity_desc') not in used and fips(r):
            v, _ = val(r); unmatched[r.get('commodity_desc')] = unmatched.get(r.get('commodity_desc'), 0) + v
open(os.path.join(ROOT, 'tools', 'nass_unmatched.txt'), 'w').write('NASS commodities in California with no planner crop (acres, all counties):\n' +
    '\n'.join(f'{k}: {round(v):,}' for k, v in sorted(unmatched.items(), key=lambda kv: -kv[1])) + '\n')
missing = [c for c in SPEC if not any(c in v['crops'] for v in counties.values())]
out = {'source': f'USDA NASS Quick Stats — {YEAR} Census of Agriculture, county level', 'year': int(YEAR), 'fetched': time.strftime('%Y-%m-%d'),
       'note': 'Acres harvested (field & vegetable crops), bearing + non-bearing acres (trees & vines) or acres grown (strawberries). "D" = withheld by NASS to protect individual farms. Wine and table grapes share the NASS all-grapes total.',
       'counties': counties}
open(os.path.join(ROOT, 'data', 'nass.js'), 'w').write('/* Generated by tools/fetch_nass.py from the USDA NASS Quick Stats API. */\nwindow.NASS=' + json.dumps(out, separators=(',', ':')) + ';\n')
print(f'{len(counties)} counties written to data/nass.js')
if missing: print('No NASS rows found for:', ', '.join(missing))
print('Review unmapped commodities in tools/nass_unmatched.txt')

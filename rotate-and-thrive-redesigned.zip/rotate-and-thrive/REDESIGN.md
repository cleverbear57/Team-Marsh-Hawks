# Rotate & Thrive — blue, green, and white redesign

The redesigned site keeps the original three-page structure and crop-planning workflow. The original Downloads folder is unchanged.

## Open the site

From this folder, run:

```powershell
python -m http.server 8766 --bind 127.0.0.1
```

Then open http://127.0.0.1:8766/. If a preview is already running at that address, use it directly. The site should be served over HTTP, as in the original project.

## What changed

- New home-page composition, brand mark, navigation, field photo treatment, metrics strip, and priority shortcuts.
- A shared blue/green/white visual system for the planner and data page, with blue Current and green Proposed comparisons.
- Button lift, press feedback, highlight sweep, and click ripples. Effects support dynamically rendered planner buttons and honor reduced-motion preferences. Keyboard focus remains visible.
- Responsive layouts, scrollable crop rows and data tables, and a compact mobile scoreboard.
- Page styling is local CSS; the Tailwind CDN runtime is no longer required. Google Fonts remain optional, with system-font fallbacks.

`refresh.css` contains the visual redesign. `microeffects.js` contains the delegated click effect. Simulation logic and datasets are preserved; changes in `game.js` are limited to comparison colors and accessible step labels.

## Higgsfield ideas

Open `animation-ideas.html` on the same server. It contains four catalog previews found through the connected Higgsfield API: Monospace Callouts, Pastel Shape Choreography, Echo Wave, and Pixel Block Yard. Recommendations describe possible adaptations, not generated results. No paid generation was submitted, and no API secret is embedded in the website. Preview media requires internet access.

## Verification

- Original `tests.html`: **22 / 22 passed**.
- Browser walkthrough: location search → cached NASA weather → rotation editor → settings → simulation → summary.
- Evidence dialog opened and closed; CSV export downloaded successfully.
- Home, planner, data page, crop editor, and summary visually checked in 390-pixel frames as well as desktop.
- Model files and datasets retained from the source project. Custom-pin live NASA requests still depend on the external API, as before.

The site's original educational limitations, data disclosures, and photo credits are retained.

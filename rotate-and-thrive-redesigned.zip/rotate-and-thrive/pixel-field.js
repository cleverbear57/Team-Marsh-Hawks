/* Pixel landscape using the same original sprite artwork as the crop picker.
   All numeric captions and scene conditions come from the existing simulation. */
function fieldSVG(k, Sk, E, t) {
  const r=E[k].first[t-1], row=r.rows[0], crop=r.slot.crop&&CROPS_G[r.slot.crop];
  const rand=mulberry(t*131+(r.slot.crop||'').length*977);
  const wet=r.pidx>1.3, dry=r.pidx<.75, soil=Sk?clamp(Sk.soil/100,0,1):.4;
  const earth=soil>.65?'#63452f':soil>.4?'#89633e':'#ac8050';
  let art='';
  const rect=(x,y,w,h,c)=>`<rect x="${Math.round(x)}" y="${Math.round(y)}" width="${Math.round(w)}" height="${Math.round(h)}" fill="${c}"/>`;
  art+=rect(0,0,240,170,wet?'#8babbc':dry?'#e9c998':'#a8d9ef');
  art+=rect(0,34,240,22,wet?'#b5c9cf':dry?'#efdbb1':'#cceaf1');
  // Square sun and stepped clouds, deliberately without blur or gradients.
  if(!wet){art+=rect(195,12,14,14,'#fff0aa')+rect(199,8,6,22,'#fff0aa')+rect(191,16,22,6,'#fff0aa');}
  for(const [x,y] of [[18,15],[84,9],[148,22]]){
    const c=wet?'#718c9b':'#f3fbfc';
    art+=rect(x,y,32,7,c)+rect(x+7,y-5,17,5,c)+rect(x-5,y+4,42,5,c);
  }
  for(let x=0;x<240;x+=6){
    const y=45+Math.round(Math.sin(x/27)*5);
    art+=rect(x,y,6,62-y,wet?'#6e997e':dry?'#b2aa73':'#83b795');
    const y2=53+Math.round(Math.sin(x/21+2)*4);
    art+=rect(x,y2,6,64-y2,dry?'#92935b':'#518660');
  }
  art+=rect(0,62,240,64,earth);
  // Pixel stair-step furrows and living winter-cover strips.
  for(let y=63;y<126;y+=3){
    const depth=(y-62)/64;
    for(let col=0;col<7;col++){
      const x=120+(col-3)*(16+depth*20);
      art+=rect(x,y,2+depth*5,3,r.slot.cover?'#4f913e':'#4e3829');
      if(r.slot.cover)art+=rect(x+2,y,2,2,'#8bc65c');
    }
  }
  const modeled=crop&&!row.unmodeled;
  if(modeled){
    const young=!!crop.bear&&row.Y===0;
    const vigor=young?.45:clamp(row.Y==null?.5:row.Y,.15,1);
    const missing=clamp((1-(row.pestF==null?1:row.pestF))*1.5,0,.5);
    for(let depth=0;depth<4;depth++)for(let col=0;col<6;col++){
      if(rand()<missing)continue;
      const size=Math.round((11+depth*4)*(.65+vigor*.35));
      const x=Math.round(120+(col-2.5)*(19+depth*9)-size/2), y=70+depth*15-size;
      art+=rect(x+3,y+size-2,size-3,3,'#493d2c');
      if(young){
        art+=rect(x+size/2,y+size-8,2,8,'#5e442e')+rect(x+size/2-3,y+size-10,4,4,'#75b34b')+rect(x+size/2+1,y+size-12,4,4,'#a7d968');
      }else{
        const sprite=CROP_ICO[crop.id];
        if(sprite)art+=`<svg x="${x}" y="${y}" width="${size}" height="${size}" viewBox="0 0 48 48">${sprite()}</svg>`;
      }
    }
  }
  if(wet){
    for(let i=0;i<23;i++){const x=rand()*238,y=rand()*53;art+=rect(x,y,1,4,'#537b98');}
    for(let i=0;i<4;i++)art+=rect(12+rand()*205,100+rand()*20,9,2,'#91cadb');
  }
  if(row.wsF!=null&&row.wsF<.9)for(let i=0;i<12;i++){
    const x=rand()*235,y=88+rand()*33;art+=rect(x,y,2,5,'#3f3029')+rect(x+2,y+4,4,2,'#3f3029');
  }
  art+=rect(0,128,240,42,'#a78053')+rect(0,128,240,10,earth);
  if(row.wet!=null)art+=rect(0,170-clamp(row.wet,0,1)*30,240,clamp(row.wet,0,1)*30,'#607c7f');
  for(let i=0;i<45;i++)art+=rect(rand()*238,139+rand()*29,1+Math.floor(rand()*2),1,rand()>.5?'#cfb17f':'#795b3e');
  if(modeled)for(let i=0;i<10;i++){
    const x=10+i*24, length=Math.min(29,Math.round((ROOTM[crop.cat]||1)*20));
    for(let j=0;j<length;j+=3)art+=rect(x+Math.floor(j/8)*(i%2?1:-1),137+j,1,3,'#ead9a6');
    art+=rect(x,146,5,1,'#ead9a6');
  }
  const status=!crop?'Fallow':row.unmodeled?'Not modeled':crop.bear&&row.Y===0?'Young plants · not bearing':wet?'Wet year':dry?'Dry year':'Typical rainfall';
  const label=`Pixel-art field for ${crop?crop.name:'fallow'}, ${status}${row.Y!=null?', yield '+Math.round(row.Y*100)+'%':''}`;
  return `<div class="pixel-field"><svg viewBox="0 0 240 170" width="100%" shape-rendering="crispEdges" role="img" aria-label="${esc(label)}">${art}</svg><div class="pixel-weather">${esc(status)}${r.slot.cover?' · winter cover':''}</div><div class="pixel-soil"><span>Topsoil${Sk?' · soil score '+Math.round(Sk.soil):''}</span><span>${row.wet!=null?'NASA soil wetness '+row.wet.toFixed(2):'Soil wetness unavailable'}</span></div></div>`;
}

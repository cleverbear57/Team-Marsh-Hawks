/* Delegated effects also work on planner controls created after each render. */
(() => {
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  document.addEventListener('pointerdown', event => {
    if (reduce.matches || event.button !== 0) return;
    const button = event.target.closest('.btn, .st, .cat, .seg button, .lnk');
    if (!button || button.disabled) return;
    const rect = button.getBoundingClientRect();
    const ripple = document.createElement('span');
    ripple.className = 'button-ripple';
    ripple.setAttribute('aria-hidden', 'true');
    const size = Math.max(rect.width, rect.height) * 2;
    Object.assign(ripple.style, {width: `${size}px`, height: `${size}px`, left: `${event.clientX - rect.left - size / 2}px`, top: `${event.clientY - rect.top - size / 2}px`});
    button.appendChild(ripple);
    ripple.addEventListener('animationend', () => ripple.remove(), {once: true});
    setTimeout(() => ripple.remove(), 700);
  });
})();

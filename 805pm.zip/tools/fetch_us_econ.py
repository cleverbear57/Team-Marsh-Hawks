#!/usr/bin/env python3
"""Build data/us_econ.js — the real-data inputs used when planning outside California.

  * Revenue: each state's average yield x price received (USDA NASS Quick Stats surveys, 2020-2024).
  * Costs:   USDA ERS Commodity Costs and Returns, $/planted acre by ERS farm resource region (2023-2025 average),
             excluding land rent, fertilizer and purchased irrigation water (the model adds those itself).
             CSVs are downloaded from https://www.ers.usda.gov/data-products/commodity-costs-and-returns into raw/ers/.
  * Water:   state irrigation water applied, acre-feet per acre (NASS 2023 Irrigation & Water Management Survey) and
             the share of each county's harvested cropland that is irrigated (NASS 2022 Census of Agriculture).

Usage:
  export NASS_API_KEY=your-key            # free key: https://quickstats.nass.usda.gov/api
  python3 tools/fetch_us_econ.py          # raw NASS responses are cached in raw/econ/ (delete to refresh)
"""
import csv, json, os, subprocess, sys, time, urllib.parse
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KEY = os.environ.get('NASS_API_KEY', '').strip()
API = 'https://quickstats.nass.usda.gov/api/api_GET/?'
RAW = os.path.join(ROOT, 'raw', 'econ'); os.makedirs(RAW, exist_ok=True)

def get(name, **params):
    path = os.path.join(RAW, name + '.json')
    if os.path.exists(path): return json.load(open(path))
    if not KEY: sys.exit('Set NASS_API_KEY first (free key: https://quickstats.nass.usda.gov/api).')
    q = urllib.parse.urlencode({'key': KEY, 'format': 'JSON', **params})
    for attempt in range(5):
        r = subprocess.run(['curl', '-sS', '-m', '180', API + q], capture_output=True)
        try: j = json.loads(r.stdout)
        except ValueError: j = {'error': [r.stdout[:120].decode(errors='replace')]}
        if 'data' in j:
            json.dump(j['data'], open(path, 'w')); time.sleep(1.5); return j['data']
        if 'no data' in str(j.get('error', '')).lower():
            json.dump([], open(path, 'w')); return []
        print(f'  {name}: NASS error, retrying —', str(j.get('error'))[:100], flush=True); time.sleep(15 * (attempt + 1))
    sys.exit(f'NASS did not answer for {name}; run again to resume.')

def num(v):
    try: return float(str(v).replace(',', ''))
    except ValueError: return None

# planner crop id -> (yield short_desc, price short_desc, $ per yield unit factor)
#   factor converts (yield unit x price unit) to dollars, e.g. lb x $/cwt -> /100; sorghum bu x $/cwt -> 0.56
CROPS = {
 'graincorn': ('CORN, GRAIN - YIELD, MEASURED IN BU / ACRE', 'CORN, GRAIN - PRICE RECEIVED, MEASURED IN $ / BU', 1),
 'soybean':   ('SOYBEANS - YIELD, MEASURED IN BU / ACRE', 'SOYBEANS - PRICE RECEIVED, MEASURED IN $ / BU', 1),
 'wheat':     ('WHEAT - YIELD, MEASURED IN BU / ACRE', 'WHEAT - PRICE RECEIVED, MEASURED IN $ / BU', 1),
 'cotton':    ('COTTON, UPLAND - YIELD, MEASURED IN LB / ACRE', 'COTTON, UPLAND - PRICE RECEIVED, MEASURED IN $ / LB', 1),
 'sorghum':   ('SORGHUM, GRAIN - YIELD, MEASURED IN BU / ACRE', 'SORGHUM, GRAIN - PRICE RECEIVED, MEASURED IN $ / CWT', .56),
 'peanut':    ('PEANUTS - YIELD, MEASURED IN LB / ACRE', 'PEANUTS - PRICE RECEIVED, MEASURED IN $ / LB', 1),
 'alfalfa':   ('HAY, ALFALFA - YIELD, MEASURED IN TONS / ACRE', 'HAY, ALFALFA - PRICE RECEIVED, MEASURED IN $ / TON', 1),
 'potato':    ('POTATOES - YIELD, MEASURED IN CWT / ACRE', 'POTATOES - PRICE RECEIVED, MEASURED IN $ / CWT', 1),
 'sugarbeet': ('SUGARBEETS - YIELD, MEASURED IN TONS / ACRE', 'SUGARBEETS - PRICE RECEIVED, MEASURED IN $ / TON', 1),
 'canola':    ('CANOLA - YIELD, MEASURED IN LB / ACRE', 'CANOLA - PRICE RECEIVED, MEASURED IN $ / CWT', .01),
 'oats':      ('OATS - YIELD, MEASURED IN BU / ACRE', 'OATS - PRICE RECEIVED, MEASURED IN $ / BU', 1),
 'barley':    ('BARLEY - YIELD, MEASURED IN BU / ACRE', 'BARLEY - PRICE RECEIVED, MEASURED IN $ / BU', 1),
 'garbanzo':  ('CHICKPEAS - YIELD, MEASURED IN LB / ACRE', 'CHICKPEAS - PRICE RECEIVED, MEASURED IN $ / CWT', .01),
 'sunflower': ('SUNFLOWER - YIELD, MEASURED IN LB / ACRE', 'SUNFLOWER - PRICE RECEIVED, MEASURED IN $ / CWT', .01),
 'safflower': ('SAFFLOWER - YIELD, MEASURED IN LB / ACRE', 'SAFFLOWER - PRICE RECEIVED, MEASURED IN $ / CWT', .01),
 'drybean':   ('BEANS, DRY EDIBLE, (EXCL CHICKPEAS) - YIELD, MEASURED IN LB / ACRE', 'BEANS, DRY EDIBLE, (EXCL CHICKPEAS) - PRICE RECEIVED, MEASURED IN $ / CWT', .01),
}
YEARS = dict(year__GE='2020', year__LE='2024')

def state_avg(rows, price=False):
    """state alpha -> average over years (annual figures only; marketing-year prices preferred)."""
    by = {}
    for r in rows:
        if r.get('agg_level_desc') != 'STATE' or r.get('freq_desc') != 'ANNUAL': continue
        if price and r.get('reference_period_desc') not in ('MARKETING YEAR', 'YEAR'): continue
        if not price and r.get('reference_period_desc') != 'YEAR': continue
        v = num(r.get('Value'))
        if v is None: continue
        st = r['state_alpha']; key = (r['year'], r.get('reference_period_desc'))
        by.setdefault(st, {})[key] = v
    out = {}
    for st, d in by.items():
        mk = [v for (y, p), v in d.items() if p == 'MARKETING YEAR'] if price else []
        vals = mk or list(d.values())
        out[st] = sum(vals) / len(vals)
    return out

states = {}
for cid, (ysd, psd, f) in CROPS.items():
    print('crop', cid, flush=True)
    y = state_avg(get(f'yield_{cid}', source_desc='SURVEY', agg_level_desc='STATE', short_desc=ysd, **YEARS))
    p = state_avg(get(f'price_{cid}', source_desc='SURVEY', agg_level_desc='STATE', short_desc=psd, **YEARS), price=True)
    for st in y:
        if st in p:
            states.setdefault(st, {'crops': {}})['crops'][cid] = {'yield': round(y[st], 1), 'price': round(p[st], 3), 'rev': round(y[st] * p[st] * f)}

# irrigation water applied per irrigated acre (2023 IWMS), by state
for r in get('iwms_water_2023', source_desc='CENSUS', year='2023', agg_level_desc='STATE', short_desc='AG LAND, IRRIGATED - WATER APPLIED, MEASURED IN ACRE FEET / ACRE'):
    v = num(r.get('Value'))
    if v is not None and r.get('domain_desc') == 'TOTAL': states.setdefault(r['state_alpha'], {'crops': {}})['waterAf'] = v

# share of each county's harvested cropland that is irrigated (2022 Census)
def county_map(name, sd):
    out = {}
    for r in get(name, source_desc='CENSUS', year='2022', agg_level_desc='COUNTY', short_desc=sd, domain_desc='TOTAL'):
        c = (r.get('county_ansi') or '').strip()
        v = num(r.get('Value'))
        if c and v is not None: out[str(r['state_fips_code']).zfill(2) + c.zfill(3)] = v
    return out
irr = county_map('county_irrigated_2022', 'AG LAND, CROPLAND, HARVESTED, IRRIGATED - ACRES')
harv = county_map('county_harvested_2022', 'AG LAND, CROPLAND, HARVESTED - ACRES')
counties = {f: round(min(1, irr.get(f, 0) / h), 3) for f, h in harv.items() if h > 0}

# ERS costs by farm resource region ($/planted acre, 2023-2025 average)
ERS_CROPS = {'graincorn': 'corn', 'soybean': 'soybeans', 'wheat': 'wheat', 'cotton': 'cotton', 'sorghum': 'sorghum', 'peanut': 'peanuts', 'oats': 'oats', 'barley': 'barley'}
costs = {}
for cid, fn in ERS_CROPS.items():
    path = os.path.join(ROOT, 'raw', 'ers', fn + '.csv')
    if not os.path.exists(path): print('missing', path); continue
    vals = {}
    for r in csv.DictReader(open(path, encoding='utf-8-sig')):
        if r['Size'] != 'No specific size' or r['Year'] not in ('2023', '2024', '2025'): continue
        item = r['Item'].strip(); v = num(r['Value'])
        if v is None or not r['Units'].startswith('dollars per planted acre'): continue
        vals.setdefault(r['Region'], {}).setdefault(item, []).append(v)
    for region, items in vals.items():
        avg = lambda k: (sum(items[k]) / len(items[k])) if k in items else 0
        if 'Total, costs listed' not in items: continue
        c = avg('Total, costs listed') - avg('Opportunity cost of land') - avg('Fertilizer') - avg('Purchased irrigation water')
        costs.setdefault(region, {})[cid] = round(c)

# state -> ERS farm resource region (approximation: ERS regions follow county lines; each state takes its main region)
ERS_REGION = {}
for region, sts in {'Heartland': 'IA IL IN OH MO MN', 'Northern Crescent': 'MI WI NY PA NJ CT MA RI VT NH ME MD DE',
                    'Northern Great Plains': 'ND SD MT', 'Prairie Gateway': 'KS NE OK TX CO NM', 'Eastern Uplands': 'KY TN WV VA',
                    'Southern Seaboard': 'NC SC GA AL', 'Mississippi Portal': 'AR MS LA', 'Fruitful Rim': 'CA AZ FL WA OR HI',
                    'Basin and Range': 'NV UT ID WY AK'}.items():
    for st in sts.split(): ERS_REGION[st] = region
for st, d in states.items(): d['ers'] = ERS_REGION.get(st, 'U.S. total')

out = {'source': 'USDA NASS Quick Stats (yields & prices received 2020-2024; 2023 Irrigation & Water Management Survey; 2022 Census irrigated cropland) and USDA ERS Commodity Costs and Returns (2023-2025)',
       'fetched': time.strftime('%Y-%m-%d'), 'states': states, 'costs': costs, 'irrShare': counties}
open(os.path.join(ROOT, 'data', 'us_econ.js'), 'w').write('/* Generated by tools/fetch_us_econ.py from USDA NASS and USDA ERS data. */\nwindow.US_ECON=' + json.dumps(out, separators=(',', ':')) + ';\n')
print(f"{len(states)} states, {len(costs)} ERS regions, {len(counties)} counties -> data/us_econ.js")

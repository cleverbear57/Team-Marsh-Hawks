'use strict';
/* Rotation mistake detector, score trend arrows, and the NASA evidence behind the recommendation.
   Loaded after farmplus.js, before game.js. Uses only the crop catalog, the model's outputs and the NASA POWER record. */

/* ---------- NASA climate facts for this place (today's climate, not the what-if) ---------- */
function nasaFacts(rec){if(!rec)return null;const n=rec.n,yrs=rec.years,P=rec.annualP,mP=rec.meanP;
  const slope=(ys)=>{const xs=ys.map((_,i)=>i),mx=mean(xs),my=mean(ys);let a=0,b=0;xs.forEach((x,i)=>{a+=(x-mx)*(ys[i]-my);b+=(x-mx)**2});return b?a/b:0};
  const hotM=[6,7].reduce((a,m)=>mean(rec.Tm.map(y=>y[m]))>mean(rec.Tm.map(y=>y[a]))?m:a,6),hot=mean(rec.Tm.map(y=>y[hotM]));
  const summer=rec.Tm.map(y=>mean([y[5],y[6],y[7]])),warm=slope(summer)*10;
  const dry=P.filter(p=>p<.75*mP).length,cv=Math.sqrt(mean(P.map(p=>(p-mP)**2)))/mP;
  const sw=rec.Sw?rec.Sw.map(y=>y[2]):null,swM=sw?mean(sw):null,swDry=sw?sw.filter(v=>v<.5).length:null;
  const frost=rec.Tl?rec.Tl.filter(y=>Math.min(y[1],y[2])<0).length:0;
  const et0=mean(rec.et0.map(y=>y.reduce((a,b)=>a+b,0))),swTrend=sw?slope(sw)*10:null,x=rec.ext||{};
  const avg=a=>a&&a.length?mean(a):null;
  return{n,y0:yrs[0],y1:yrs[n-1],mP,dry,cv,hot,hotM,warm,swM,swDry,frost,rainTrend:slope(P)*10/mP*100,et0,swTrend,
    wetDays:avg(x.wetDays),maxDay:x.maxDay?Math.max(...x.maxDay):null,hotDays:avg(x.hotDays),hotTrend:x.hotDays?slope(x.hotDays)*10:null,frostDays:avg(x.frostDays),topWet:x.topWet??null,daily:!!x.wetDays}}
/* average NASA max temperature in a crop's hottest growing month here */
function seasonHeat(cr,rec,zone){const ms=(cr.zm[zone]||cr.months).map(m=>m-1);return Math.max(...ms.map(m=>mean(rec.Tm.map(y=>y[m]))))}

/* ---------- mistake detector ---------- */
const MON3=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function rotationIssues(rot,zone,rec){
  const out=[],C=id=>CROPS_G[id],R=expandRot(rot.filter(s=>s.crop)),L=R.length,add=(sev,title,why,fix,yrs)=>out.push({sev,title,why,fix,yrs});if(!L)return out;
  const nm=i=>C(R[i].crop).name,sh=c=>c.name.split(' /')[0].split(' (')[0],next=i=>(i+1)%L,per=c=>c.perennial&&c.id!=='alfalfa';
  const legumes=Object.values(CROPS_G).filter(c=>c.nFix>0&&!c.unmodeled&&!per(c)&&fitOf(c.id,zone)!=='poor').map(c=>sh(c).toLowerCase()).slice(0,2).join(' or ')||'a bean crop';
  /* repeats */
  if(L===1&&!per(C(R[0].crop)))add('high',`${nm(0)} every year`,'Pests and diseases build up.',`Add a year of ${legumes} or wheat.`,[0]);
  else if(new Set(R.map(s=>s.crop)).size===1&&!per(C(R[0].crop)))add('high',`Only ${nm(0)}`,'Not really a rotation.','Swap one year for a different crop family.',R.map((_,i)=>i));
  else if(L>1)for(let i=0;i<L;i++){const j=next(i);if(j===0&&L<3)continue;const a=C(R[i].crop),b=C(R[j].crop);if(per(a)||per(b))continue;
    if(a.id===b.id)add('med',`${sh(a)} twice in a row`,'Keeps its pests going.',`Put a different crop between years ${i+1} and ${j+1}.`,[i,j]);
    else if(a.fam===b.fam&&a.fam!=='Mixed natives')add('med',`${sh(a)} → ${sh(b)}: same family`,'They share pests and diseases.','Move one of them, or put wheat or a legume between.',[i,j])}
  /* covers */
  R.forEach((s,i)=>{if(!s.cover)return;const cv=COVERS[s.cover];
    if(coverConflict(s.crop,s.cover,zone))add('high',`Cover clashes with ${sh(C(s.crop))}`,`Year ${i+1}: seasons overlap.`,'Remove that cover or pick a crop that leaves winter free.',[i]);
    const b=C(R[next(i)].crop);if(L>1&&cv.fam===b.fam)add('med',`${cv.name.split(' /')[0]} before ${sh(b)}`,'Same family — can carry disease.','Use a vetch or rye cover instead.',[i,next(i)])});
  /* nitrogen */
  const legume=R.some(s=>C(s.crop).nFix>0||(s.cover&&COVERS[s.cover].nFix>0)),hungry=R.filter(s=>C(s.crop).nNeed>=150).length;
  if(!legume&&hungry&&!R.every(s=>per(C(s.crop))))add(hungry>=L/2?'med':'low','No legume','Nothing adds nitrogen, so fertilizer costs stay high.',`Add a vetch/clover cover or a year of ${legumes}.`,[]);
  for(let i=0;i<L-1;i++)if(C(R[i].crop).nNeed>=150&&C(R[i+1].crop).nNeed>=150&&!R[i].cover)add('low','Two hungry crops in a row',`${sh(C(R[i].crop))} then ${sh(C(R[i+1].crop))}.`,`Add a vetch cover after ${sh(C(R[i].crop))}.`,[i,i+1]);
  /* bare winters */
  const bare=R.map((s,i)=>i).filter(i=>{const c=C(R[i].crop);if(per(c)||c.cat==='native'||R[i].cover)return false;const ms=c.zm[zone]||c.months;return![11,12,1,2].some(m=>ms.includes(m))});
  const storms=rec&&rec.ext&&rec.ext.wetDays?mean(rec.ext.wetDays):0;
  if(bare.length&&storms>=2)add('med',`Bare soil + heavy storms`,`NASA: ~${storms.toFixed(1)} days a year with 25 mm+ rain here.`,'Keep a winter cover on every bare year.',bare);
  else   if(bare.length&&bare.length>=Math.ceil(L/2))add(bare.length===L?'med':'low',`Bare in winter (${L===1?'every year':bare.length+' of '+L+' years'})`,'Rain washes soil and nitrate away.','Add a winter cover crop (rye or vetch).',bare);
  /* fit */
  R.forEach((s,i)=>{const c=C(s.crop),f=fitOf(s.crop,zone);if(f==='poor')add('high',`${sh(c)} is a poor fit here`,'Expect low yields.','Pick a crop marked “Good local fit”.',[i]);else if(f==='unmodeled')add('low',`${sh(c)} isn't modeled`,'That year is left out of the scores.','Swap it for a modeled crop to compare fairly.',[i])});
  if(L>1&&R.some(s=>per(C(s.crop)))&&R.some(s=>!per(C(s.crop))||s.crop!==R[0].crop))add('high','Trees/vines in a rotation','Pulling them out costs ~$1,200/acre each time.','Keep the orchard on its own and rotate annual crops elsewhere.',[]);
  /* NASA weather */
  if(rec){const f=nasaFacts(rec);
    R.forEach((s,i)=>{const c=C(s.crop);if(c.unmodeled||c.cat==='native')return;const h=seasonHeat(c,rec,zone);
      if(h>c.heatThr+1)add(h>c.heatThr+4?'med':'low',`Heat stress for ${sh(c)}`,`NASA: ${h.toFixed(0)} °C highs vs its ${c.heatThr} °C limit.`,c.heatThr<=30?'Grow it in the cool season (fall–spring) instead.':'Swap for a heat-tolerant crop like sorghum or cotton.',[i]);
      if(c.frostMonths.length&&c.frostSens>=.6&&rec.Tl){const fm=c.frostMonths.filter(m=>mean(rec.Tl.map(y=>y[m-1]))<0);if(fm.length)add('low',`Frost risk for ${sh(c)}`,`NASA lows below 0 °C in ${fm.map(m=>MON3[m-1]).join('/')}.`,'Plant later or add frost protection.',[i])}});
    if(f.hotDays!=null&&f.hotDays>=30){const sens=R.filter(s=>{const c=C(s.crop);return!c.unmodeled&&c.heatThr<=30}).length;if(sens)add('med','Many heat-stress days',`NASA: ~${fmt(f.hotDays)} days a year above 35 °C${f.hotTrend>1?`, rising ${fmt(f.hotTrend)} per decade`:''}.`,'Move cool-season crops to fall–spring or pick heat-tolerant ones.',[])}
    if(f.swTrend!=null&&f.swTrend<-.03&&R.filter(s=>C(s.crop).kc>=1.1).length)add('low','Soil is drying over time',`NASA soil wetness fell ${Math.abs(f.swTrend).toFixed(2)} per decade since ${f.y0}.`,'Favour drought-tolerant crops and covers that save water.',[]);
    const thirsty=R.filter(s=>C(s.crop).kc>=1.1).length;
    if(thirsty>=Math.ceil(L/2)&&(f.mP<350||f.dry>=f.n/4))add('med','Too many thirsty crops',`NASA: ${f.dry} of ${f.n} years were dry here.`,'Swap one year for wheat, safflower or sorghum.',[])}
  const o={high:0,med:1,low:2},seen=new Set();return out.filter(x=>!seen.has(x.title)&&seen.add(x.title)).sort((a,b)=>o[a.sev]-o[b.sev])}

const SEV={high:[pxe('stop'),'Problem'],med:[pxe('warn'),'Watch out'],low:[pxe('info'),'Minor']};
function issuesHTML(k){if(!U.rots[k].length||!U.zone)return'';const L=rotationIssues(U.rots[k],U.zone,U.rec),open=U.issOpen&&U.issOpen[k];
  if(!L.length)return`<div class="iss ok"><span>${pxe('check')}</span> <b>Rotation check:</b> no problems found in ${RK[k].n}.</div>`;
  const n={high:0,med:0,low:0};L.forEach(x=>n[x.sev]++);const show=open?L:L.slice(0,3);
  return`<div class="iss" style="--c:${RK[k].c}"><div class="issh"><b>${pxe('magnifier')} Rotation check — ${RK[k].n}</b><span class="tiny">${['high','med','low'].filter(s=>n[s]).map(s=>`${SEV[s][0]} ${n[s]} ${SEV[s][1].toLowerCase()}${n[s]>1&&s!=='med'?'s':''}`).join(' · ')}</span></div>
   <ul>${show.map(x=>`<li class="${x.sev}"><span class="ic" aria-label="${SEV[x.sev][1]}">${SEV[x.sev][0]}</span><div><b>${esc(x.title)}</b> <span>${esc(x.why)}</span><em class="fix">${pxe('bulb')} Try: ${esc(x.fix)}</em></div></li>`).join('')}</ul>
   ${L.length>3?`<button class="lnk2 tiny" data-act="issmore" data-rot="${k}">${open?'Show fewer':`Show all ${L.length}`}</button>`:''}</div>`}
/* compact line for the summary */
function issuesLine(){const s=['cur','prop'].map(k=>{const L=rotationIssues(U.rots[k],U.zone,U.rec),h=L.filter(x=>x.sev==='high').length,m=L.filter(x=>x.sev==='med').length;
    return`<span style="color:${RK[k].c}"><b>${RK[k].n}</b></span> ${L.length?`${h?`${pxe('stop')} ${h} `:''}${m?`${pxe('warn')} ${m} `:''}${L.length-h-m?`${pxe('info')} ${L.length-h-m}`:''}`:pxe('check')+' none'}`});
  return`<details class="issline"><summary>${pxe('magnifier')} Rotation check: ${s.join(' · ')}</summary>${issuesHTML('cur')}${issuesHTML('prop')}</details>`}

/* ---------- trend arrows: how each score moves across the years (mean of all weather sequences) ---------- */
function trendOf(k,c){const Y=U.sim&&U.sim.E[k].yr&&U.sim.E[k].yr[c];if(!Y)return null;const ys=Y.filter(v=>v!=null);if(ys.length<3)return null;
  const t=Math.max(1,Math.round(ys.length/3));return mean(ys.slice(-t))-mean(ys.slice(0,t))}   /* last third of the years minus first third */
function trendArrow(k,c){const d=trendOf(k,c);if(d==null)return'<span class="tr z" title="No year-by-year trend for this score">–</span>';
  const a=Math.abs(d),[g,cl,w]=a<2?['→','z','steady']:d>0?[a>6?'↑':'↗','up','rising']:[a>6?'↓':'↘','dn','falling'];
  const lab=SCORE_CATS.find(x=>x[0]===c)[2];return`<span class="tr ${cl}" title="${esc(lab)} ${w}: ${d>0?'+':''}${d.toFixed(1)} points, early years → late years" aria-label="${w}">${g}</span>`}

/* ---------- NASA evidence for the recommendation (small) ---------- */
function nasaEvidence(){const rec=U.rec,f=nasaFacts(rec);if(!f||!U.sim)return'';const E=U.sim.base||U.sim.E,A=ACRES(),live=rec.status==='available';
  const d=c=>E.prop.cat[c].med-E.cur.cat[c].med,dw=(E.prop.num.water.med-E.cur.num.water.med)*A,cov=k=>U.rots[k].filter(s=>s.cover).length;
  const heatLim=['cur','prop'].some(k=>U.sim.E[k].first.some(r=>r.rows[0].limits&&r.rows[0].limits[0]&&r.rows[0].limits[0][0]==='Heat'));
  const items=[
   [pxe('rain'),'Rain',`${fmt(f.mP)} mm/yr · ${f.dry} of ${f.n} years under 75% of normal${Math.abs(f.rainTrend)>=5?` · ${f.rainTrend>0?'+':''}${fmt(f.rainTrend)}% per decade`:''}`,'PRECTOTCORR',
     dw<-1?`Proposed uses ${fmt(-dw)} AF/yr less irrigation — it matters in dry years.`:dw>1?`Proposed uses ${fmt(dw)} AF/yr more irrigation — a risk in dry years.`:'Both rotations use about the same water.'],
   [pxe('drops'),'Crop water demand',`${fmt(f.et0)} mm/yr evaporation demand vs ${fmt(f.mP)} mm rain`,'T2M, T2M_RANGE (Hargreaves ET₀)',
     f.et0>f.mP*2?'Demand far exceeds rain — irrigation decides yields here.':'Rain covers a good share of crop demand.'],
   [pxe('thermo'),'Heat',f.hotDays!=null?`~${fmt(f.hotDays)} days/yr above 35 °C${f.hotTrend!=null&&Math.abs(f.hotTrend)>=1?` · ${f.hotTrend>0?'+':''}${fmt(f.hotTrend)} per decade`:''}`:`${MON3[f.hotM]} highs ${f.hot.toFixed(0)} °C · ${f.warm>=0?'+':''}${f.warm.toFixed(1)} °C per decade`,f.hotDays!=null?'T2M_MAX (daily)':'T2M, T2M_RANGE',
     heatLim?'Heat is a top yield limit in these runs — favour heat-tolerant summer crops.':'Heat is not the main yield limit for these crops here.'],
   ...(f.wetDays!=null?[[pxe('storm'),'Extreme rain',`~${f.wetDays.toFixed(1)} days/yr with 25 mm+ · wettest day ${fmt(f.maxDay)} mm`,'PRECTOTCORR (daily)',
     cov('prop')>cov('cur')?'Proposed covers more winters — less soil washed away in storms.':'Bare winters lose the most soil in these storms.']]:[]),
   ...(f.swM!=null?[[pxe('drop'),'Soil moisture',`Root zone ${f.swM.toFixed(2)} in March${f.topWet!=null?` · topsoil ${f.topWet.toFixed(2)}`:''} · ${f.swTrend!=null?`${f.swTrend>=0?'+':''}${f.swTrend.toFixed(2)} per decade`:`${f.swDry} dry springs`}`,'GWETROOT, GWETTOP',
     `Soil score difference: ${d('soil')>=0?'+':''}${fmt(d('soil'))}.`]]:[]),
   ...((f.frostDays??f.frost)?[[pxe('snow'),'Frost',f.frostDays!=null?`~${fmt(f.frostDays)} frost days/yr`:`${f.frost} of ${f.n} years below 0 °C in Feb–Mar`,f.frostDays!=null?'T2M_MIN (daily)':'T2M_MIN','Frost-tender bloom or transplants face risk.']]:[])];
  return`<details class="nasaev" id="nasaSet" ${U.nasaOpen?'open':''}><summary class="nvh"><b>${pxe('sat')} NASA evidence</b><span>${live?'NASA POWER'+(f.daily?' · monthly + daily':''):pxe('warn')+' illustrative weather, not NASA'} · ${f.y0}–${f.y1}${/km away/.test(rec.source)?' · nearby grid cell':''} · ${items.map(x=>x[0]).join(' ')}</span><i aria-hidden="true">Details ▾</i></summary>
   <div class="nvg">${items.map(([ic,t,v,p,why])=>`<div class="nvi" title="NASA POWER parameter: ${p}"><div><span>${ic}</span> <b>${t}</b></div><div class="nvv">${esc(v)}</div><div class="nvw">→ ${esc(why)}</div></div>`).join('')}</div></details>`}
document.addEventListener('toggle',e=>{if(e.target&&e.target.id==='nasaSet')U.nasaOpen=e.target.open},true);

document.addEventListener('click',e=>{const b=e.target.closest('[data-act="issmore"]');if(!b)return;U.issOpen=U.issOpen||{};U.issOpen[b.dataset.rot]=!U.issOpen[b.dataset.rot];render()});

#!/usr/bin/env python3
"""Fetch NASA POWER monthly point data (2001-2025) for every gazetteer place, keep raw bytes,
and write compact browser assets data/gazetteer.js + data/weather.js.
Source: NASA POWER Monthly API (MERRA-2 reanalysis + satellite-derived inputs), community AG.
Usage: python3 tools/fetch_power.py"""
import json, os, re, time, hashlib, calendar
from concurrent.futures import ThreadPoolExecutor
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GAZ=[("Five Points","Fresno",36.36,-120.10),("Fresno","Fresno",36.74,-119.79),("Kerman","Fresno",36.72,-120.06),("Sanger","Fresno",36.71,-119.56),("Reedley","Fresno",36.60,-119.45),
("Coalinga","Fresno",36.14,-120.36),("Visalia","Tulare",36.33,-119.29),("Tulare","Tulare",36.21,-119.35),("Porterville","Tulare",36.07,-119.02),("Hanford","Kings",36.33,-119.65),
("Bakersfield","Kern",35.37,-119.02),("Shafter","Kern",35.50,-119.27),("Delano","Kern",35.77,-119.25),("Madera","Madera",36.96,-120.06),("Merced","Merced",37.30,-120.48),
("Los Banos","Merced",37.06,-120.85),("Modesto","Stanislaus",37.64,-121.00),("Turlock","Stanislaus",37.49,-120.85),("Stockton","San Joaquin",37.96,-121.29),("Lodi","San Joaquin",38.13,-121.27),
("Salinas","Monterey",36.68,-121.66),("Gonzales","Monterey",36.51,-121.44),("King City","Monterey",36.21,-121.13),("Castroville","Monterey",36.77,-121.76),("Watsonville","Santa Cruz",36.91,-121.76),
("Gilroy","Santa Clara",37.01,-121.57),("Hollister","San Benito",36.85,-121.40),("Paso Robles","San Luis Obispo",35.63,-120.69),("Santa Maria","Santa Barbara",34.95,-120.44),("Lompoc","Santa Barbara",34.64,-120.46),
("Oxnard","Ventura",34.20,-119.18),("Camarillo","Ventura",34.22,-119.04),("Santa Paula","Ventura",34.35,-119.06),("Temecula","Riverside",33.49,-117.15),("Fallbrook","San Diego",33.38,-117.25),("Escondido","San Diego",33.12,-117.09),
("Sacramento","Sacramento",38.58,-121.49),("Davis","Yolo",38.54,-121.74),("Woodland","Yolo",38.68,-121.77),("Colusa","Colusa",39.21,-122.01),("Williams","Colusa",39.15,-122.15),("Yuba City","Sutter",39.14,-121.62),
("Chico","Butte",39.73,-121.84),("Oroville","Butte",39.51,-121.56),("Willows","Glenn",39.52,-122.19),("Red Bluff","Tehama",40.18,-122.24),("Redding","Shasta",40.59,-122.39),
("Napa","Napa",38.30,-122.29),("Sonoma","Sonoma",38.29,-122.46),("Santa Rosa","Sonoma",38.44,-122.71),("Healdsburg","Sonoma",38.61,-122.87),("Ukiah","Mendocino",39.15,-123.21),("Eureka","Humboldt",40.80,-124.16),
("El Centro","Imperial",32.79,-115.56),("Brawley","Imperial",32.98,-115.53),("Calexico","Imperial",32.68,-115.50),("Holtville","Imperial",32.81,-115.38),("Imperial","Imperial",32.85,-115.57),
("Blythe","Riverside",33.61,-114.60),("Coachella","Riverside",33.68,-116.17),("Indio","Riverside",33.72,-116.22),("Alturas","Modoc",41.49,-120.54),("Tulelake","Siskiyou",41.96,-121.48)]
START,END=2001,2025
def slug(n):return re.sub(r'[^a-z0-9]+','-',n.lower()).strip('-')
def get(item):
    n,c,lat,lon=item;path=os.path.join(ROOT,'raw','power',slug(n)+'.v2.json')
    if os.path.exists(path):return item,open(path,'rb').read(),None
    url=("https://power.larc.nasa.gov/api/temporal/monthly/point?parameters=T2M,T2M_RANGE,T2M_MAX,T2M_MIN,PRECTOTCORR,GWETROOT"
         f"&community=AG&longitude={lon}&latitude={lat}&start={START}&end={END}&format=JSON")
    import subprocess
    for a in range(4):
        r=subprocess.run(["curl","-sf","-m","90","-o",path,url])
        if r.returncode==0 and os.path.getsize(path)>1000:return item,open(path,'rb').read(),url
        if os.path.exists(path):os.remove(path)
        time.sleep(3*(a+1))
    return item,None,url
def main():
    with ThreadPoolExecutor(3) as ex:res=list(ex.map(get,GAZ))
    W={};failed=[]
    for (n,c,lat,lon),b,url in res:
        if not b:failed.append(n);continue
        d=json.loads(b);p=d['properties']['parameter'];years=[];rows={k:[] for k in['P','Tm','Tn','Tx','Tl','Sw']}
        for y in range(START,END+1):
            ks=[f"{y}{m:02d}" for m in range(1,13)]
            try:
                t2=[p['T2M'][k] for k in ks];rg=[p['T2M_RANGE'][k] for k in ks];tx=[p['T2M_MAX'][k] for k in ks];tl=[p['T2M_MIN'][k] for k in ks];pr=[p['PRECTOTCORR'][k] for k in ks];sw=[p['GWETROOT'][k] for k in ks]
            except KeyError:continue
            if any(v is None or v<=-990 for v in t2+rg+tx+tl+pr+sw):continue
            rows['Sw'].append([round(v,3) for v in sw])
            dim=[calendar.monthrange(y,m)[1] for m in range(1,13)]
            years.append(y);rows['P'].append([round(pr[i]*dim[i],1) for i in range(12)])
            rows['Tm'].append([round(t2[i]+rg[i]/2,1) for i in range(12)]);rows['Tn'].append([round(t2[i]-rg[i]/2,1) for i in range(12)])
            rows['Tx'].append([round(v,1) for v in tx]);rows['Tl'].append([round(v,1) for v in tl])
        W[slug(n)]={'lat':lat,'lon':lon,'grid':d['geometry']['coordinates'],'years':years,**rows,'sha256':hashlib.sha256(b).hexdigest()[:16]}
    meta={'source':'NASA POWER Monthly API (MERRA-2 reanalysis; community AG)','api':'https://power.larc.nasa.gov/api/temporal/monthly/point','params':'T2M,T2M_RANGE,T2M_MAX,T2M_MIN,PRECTOTCORR,GWETROOT','range':[START,END],'retrieved':time.strftime('%Y-%m-%d'),'note':'Gridded reanalysis, not an on-farm weather station. Tm/Tn = monthly mean daily max/min (T2M +/- T2M_RANGE/2); Tx/Tl = monthly extreme max/min. Years with any missing value are excluded. P = mm per month. Sw = GWETROOT, MERRA-2 root-zone soil WETNESS (unitless 0-1 degree of saturation, NOT volumetric moisture).','failed':failed}
    os.makedirs(os.path.join(ROOT,'data'),exist_ok=True)
    open(os.path.join(ROOT,'data','weather.js'),'w').write('window.WEATHER_META='+json.dumps(meta)+';\nwindow.WEATHER='+json.dumps(W,separators=(',',':'))+';\n')
    open(os.path.join(ROOT,'data','gazetteer.js'),'w').write('window.GAZ='+json.dumps([{'id':slug(n),'name':n,'county':c,'lat':la,'lon':lo} for n,c,la,lo in GAZ])+';\n')
    print('done',len(W),'failed',failed)
main()

#!/usr/bin/env python3
"""Find free-license candidate photos on Wikimedia Commons for every slot, save small thumbnails + metadata for review.
Usage: python3 tools/find_photos.py <out_dir>   (uses curl for TLS; polite rate limit)"""
import json, os, re, subprocess, sys, time, urllib.parse, html, shutil
UA="RotateAndThrive-hackathon/1.0 (educational crop-rotation demo)"
OUT=sys.argv[1]; os.makedirs(OUT,exist_ok=True)
SLOTS={}
def S(k,q): SLOTS[k]=q
crops={'tomato':('Tomato fruits on plant','tomato field rows'),'strawberry':('Strawberry fruit','strawberry field California'),'lettuce':('Lettuce head','lettuce field rows'),
'broccoli':('Broccoli head','broccoli field'),'spinach':('Spinach leaves','spinach field'),'carrot':('Carrots harvested','carrot field'),'garlic':('Garlic bulbs','garlic field'),
'onion':('Onion bulbs','onion field'),'melon':('Cantaloupe melon','melon field'),'artichoke':('Globe artichoke','artichoke field'),'corn':('Corn cob maize','corn field'),
'cotton':('Cotton boll plant','cotton field'),'wheat':('Wheat ears','wheat field'),'safflower':('Safflower flower','safflower field'),'sunflower':('Sunflower flower','sunflower field'),
'garbanzo':('Chickpea Cicer arietinum','chickpea field'),'drybean':('Cowpea Vigna unguiculata','dry bean field'),'sorghum':('Sorghum grain head','sorghum field'),
'rice':('Rice panicle grains','rice paddy field'),'alfalfa':('Alfalfa flowers Medicago sativa','alfalfa field'),'almond':('Almond nuts hull','almond orchard California'),
'walnut':('Walnuts in shell','walnut orchard'),'pistachio':('Pistachio nuts','pistachio orchard'),'peach':('Peaches fruit on tree','peach orchard'),'citrus':('Oranges on tree','orange grove'),
'avocado':('Avocado fruit on tree','avocado orchard'),'olive':('Olives on tree','olive grove'),'pomegranate':('Pomegranate fruit','pomegranate orchard'),'date':('Date palm fruit dates','date palm grove'),
'jojoba':('Jojoba Simmondsia chinensis','jojoba plantation'),'winegrape':('Wine grapes on vine','vineyard rows'),'tablegrape':('Table grapes bunch','grape vineyard trellis'),
'wildflower':('California poppy Eschscholzia','California wildflowers field'),'bunchgrass':('Nassella pulchra purple needlegrass','California grassland'),'elderberry':('Blue elderberry Sambucus','elderberry shrub')}
for k,(c,f) in crops.items(): S('c-'+k,c); S('f-'+k,f)
for k,q in {'rye':'Rye cover crop field','vetch':'Hairy vetch cover crop','mustard':'Mustard cover crop flowers field','clover':'Crimson clover field','nativemix':'California lupine poppy wildflowers'}.items(): S('v-'+k,q)
for k,q in {'drip':'Drip irrigation field','sprinkler':'Sprinkler irrigation field','sensors':'Soil moisture sensor','notill':'No-till seed drill','frost':'Wind machine orchard','compost':'Manure spreader compost'}.items(): S('e-'+k,q)
for k,q in {'water':'Water drop','soil':'Soil profile close-up','n':'Fertilizer granules','pest':'Aphids on leaf','income':'Coins money','resil':'Drought cracked soil'}.items(): S('k-'+k,q)
S('hero','California agriculture farmland landscape'); S('hero2','Central Valley California farm field')
BAD=re.compile(r'\b(map|diagram|drawing|illustration|painting|logo|icon|stamp|poster|herbarium|engraving|plate|page|cartoon|3d|svg|pdf|tif|chart|graph|sketch|watercolor|lithograph|postcard|coin of|banknote|flag|seal)\b',re.I)
OKLIC=re.compile(r'^(CC BY(-SA)? [0-9.]+|CC BY(-SA)?|CC0.*|Public domain.*|PD.*)',re.I)
def curl(url,out=None):
    cmd=['curl','-sfL','-m','60','-A',UA]+(['-o',out] if out else [])+[url]
    r=subprocess.run(cmd,capture_output=True)
    if r.returncode!=0: return None
    return r.stdout if not out else True
def strip(s): return html.unescape(re.sub(r'<[^>]+>','',s or '')).strip()
only=set(sys.argv[2:])
manifest={}
for slot,q in SLOTS.items():
    if only and slot not in only: continue
    d=os.path.join(OUT,slot); 
    if os.path.exists(os.path.join(d,'meta.json')): continue
    os.makedirs(d,exist_ok=True)
    field=slot.startswith('f-') or slot.startswith('hero')
    url="https://commons.wikimedia.org/w/api.php?"+urllib.parse.urlencode({'action':'query','format':'json','generator':'search','gsrsearch':q+' filetype:bitmap','gsrnamespace':'6','gsrlimit':'30',
        'prop':'imageinfo','iiprop':'url|size|mime|extmetadata','iiurlwidth':'400' if not field else '600'})
    raw=None
    for attempt in range(5):
        raw=curl(url); time.sleep(1.5)
        if raw: break
        time.sleep(6*(attempt+1))
    if not raw:
        print(slot,'API-FAILED',flush=True); shutil.rmtree(d,ignore_errors=True); continue
    cands=[]
    if raw:
        pages=json.loads(raw).get('query',{}).get('pages',{})
        for p in pages.values():
            ii=(p.get('imageinfo') or [{}])[0]; title=p.get('title','')
            if ii.get('mime') not in ('image/jpeg',) or BAD.search(title): continue
            w,h=ii.get('width',0),ii.get('height',0)
            if w<(1200 if field else 700) or (field and w<h*1.2) : continue
            md=ii.get('extmetadata',{}); lic=strip(md.get('LicenseShortName',{}).get('value',''))
            if not OKLIC.match(lic): continue
            cands.append({'title':title,'index':p.get('index',99),'thumb':ii.get('thumburl'),'page':ii.get('descriptionurl'),'full':ii.get('url'),'w':w,'h':h,'license':lic,
                'artist':strip(md.get('Artist',{}).get('value','')),'credit':strip(md.get('Credit',{}).get('value','')),'licurl':md.get('LicenseUrl',{}).get('value','')})
    cands.sort(key=lambda c:c['index']); cands=cands[:4]
    for i,c in enumerate(cands):
        if c['thumb']: curl(c['thumb'],os.path.join(d,f'{i}.jpg')); time.sleep(.8)
    json.dump({'query':q,'cands':cands},open(os.path.join(d,'meta.json'),'w'),indent=1)
    print(slot,len(cands),flush=True)

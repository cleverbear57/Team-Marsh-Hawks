// Usage: node cells.js <site-dir>  -> writes cells.json: [{st, lat, lon}] MERRA-2 cell centers per state (CA excluded)
const fs=require('fs'),path=require('path'),site=process.argv[2]||'.';
global.window={};global.self=global;
const topojson=require(path.resolve(site,'vendor/topojson-client.min.js'));
eval(fs.readFileSync(path.join(site,'vendor/counties-10m.js'),'utf8'));
const topo=window.US_ATLAS_TOPO,tj=topojson;
const feats=tj.feature(topo,topo.objects.counties).features.filter(f=>f.geometry);
const DLAT=.5,DLON=.625,cLat=l=>Math.round(l/DLAT)*DLAT,cLon=l=>Math.round(l/DLON)*DLON;
function ringsOf(g){return g.type==='Polygon'?[g.coordinates]:g.coordinates}
function inPoly(polys,x,y){let ins=false;for(const poly of polys)for(const r of poly)for(let i=0,j=r.length-1;i<r.length;j=i++){const[xi,yi]=r[i],[xj,yj]=r[j];if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)ins=!ins}return ins}
const cells={};const add=(st,la,lo)=>{la=+cLat(la).toFixed(3);lo=+cLon(lo).toFixed(4);const k=st+'|'+la+'|'+lo;cells[k]={st,lat:la,lon:lo}};
for(const f of feats){const st=String(f.id).slice(0,2),P=ringsOf(f.geometry);let x0=1e9,x1=-1e9,y0=1e9,y1=-1e9,sx=0,sy=0,n=0;
  for(const poly of P)for(const r of poly)for(const[x,y]of r){if(x>0)continue;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);sx+=x;sy+=y;n++}
  if(!n)continue;
  // every cell whose center is inside this county
  for(let la=cLat(y0);la<=y1+1e-9;la+=DLAT)for(let lo=cLon(x0);lo<=x1+1e-9;lo+=DLON)if(inPoly(P,lo,la))add(st,la,lo);
  // plus the cell at the county's bbox center and vertex mean, so small counties are always covered
  add(st,(y0+y1)/2,(x0+x1)/2);add(st,sy/n,sx/n)}
const out=Object.values(cells);fs.writeFileSync('cells.json',JSON.stringify(out));
const by={};out.forEach(c=>by[c.st]=(by[c.st]||0)+1);console.log('cells',out.length,'unique',new Set(out.map(c=>c.lat+','+c.lon)).size,JSON.stringify(by));

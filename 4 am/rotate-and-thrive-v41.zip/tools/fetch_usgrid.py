"""Download NASA POWER monthly + daily records for every MERRA-2 cell in cells.json.
Resumable: one processed JSON per cell in cache/. Processing mirrors tools/fetch_power.py and nasa.js."""
import json, os, sys, time, hashlib, calendar, urllib.request, concurrent.futures as cf
B='https://power.larc.nasa.gov/api/temporal'
MON='T2M,T2M_RANGE,T2M_MAX,T2M_MIN,PRECTOTCORR,GWETROOT,GWETTOP'
cells={}
for c in json.load(open(sys.argv[1] if len(sys.argv)>1 else 'cells.json')): cells[(c['lat'],c['lon'])]=1
def get(url):
    for a in range(6):
        try:
            with urllib.request.urlopen(url,timeout=120) as r: return r.read()
        except Exception as e:
            err=e; time.sleep(5*(a+1))
    raise err
def one(lat,lon):
    fn=f'cache/{lat}_{lon}.json'
    if os.path.exists(fn): return 'skip'
    q=f'community=AG&longitude={lon}&latitude={lat}&format=JSON'
    b=get(f'{B}/monthly/point?parameters={MON}&{q}&start=2001&end=2025'); d=json.loads(b); p=d['properties']['parameter']
    rows={k:[] for k in ['P','Tm','Tn','Tx','Tl','Sw']}; years=[]
    for y in range(2001,2026):
        ks=[f'{y}{m:02d}' for m in range(1,13)]
        g=lambda n:[p[n].get(k) for k in ks]
        t2,rg,tx,tl,pr,sw=g('T2M'),g('T2M_RANGE'),g('T2M_MAX'),g('T2M_MIN'),g('PRECTOTCORR'),g('GWETROOT')
        if any(v is None or v<=-990 for v in t2+rg+tx+tl+pr+sw): continue
        dim=[calendar.monthrange(y,m)[1] for m in range(1,13)]
        years.append(y); rows['P'].append([round(pr[i]*dim[i],1) for i in range(12)])
        rows['Tm'].append([round(t2[i]+rg[i]/2,1) for i in range(12)]); rows['Tn'].append([round(t2[i]-rg[i]/2,1) for i in range(12)])
        rows['Tx'].append([round(v,1) for v in tx]); rows['Tl'].append([round(v,1) for v in tl]); rows['Sw'].append([round(v,3) for v in sw])
    gt={}
    for k,v in p['GWETTOP'].items():
        if k.endswith('13') or v is None or v<=-900: continue
        gt.setdefault(k[:4],[]).append(v)
    ext={}
    if gt:
        ext['GWETTOP']=[round(sum(a)/len(a),3) for _,a in sorted(gt.items())]; ext['topWet']=round(sum(ext['GWETTOP'])/len(ext['GWETTOP']),3)
    db=get(f'{B}/daily/point?parameters=PRECTOTCORR,T2M_MAX,T2M_MIN&{q}&start=20010101&end=20251231'); dp=json.loads(db)['properties']['parameter']
    Y={}
    for k,v in dp['PRECTOTCORR'].items():
        if v<-900: continue
        y=Y.setdefault(k[:4],{'wet':0,'max':0,'hot':0,'frost':0,'n':0}); y['n']+=1
        if v>=25: y['wet']+=1
        if v>y['max']: y['max']=v
    for k,v in dp['T2M_MAX'].items():
        if v>-900 and k[:4] in Y and v>=35: Y[k[:4]]['hot']+=1
    for k,v in dp['T2M_MIN'].items():
        if v>-900 and k[:4] in Y and v<0: Y[k[:4]]['frost']+=1
    L=sorted((y,v) for y,v in Y.items() if v['n']>300)
    if len(L)>=10:
        ext.update(years=[int(y) for y,_ in L],wetDays=[v['wet'] for _,v in L],maxDay=[round(v['max'],1) for _,v in L],hotDays=[v['hot'] for _,v in L],frostDays=[v['frost'] for _,v in L])
    out={'lat':lat,'lon':lon,'grid':d['geometry']['coordinates'],'years':years,**rows,'ext':ext,'sha256':hashlib.sha256(b).hexdigest()[:16]}
    json.dump(out,open(fn+'.tmp','w')); os.replace(fn+'.tmp',fn); return 'ok'
todo=list(cells); done=0; fails=[]
with cf.ThreadPoolExecutor(6) as ex:
    fut={ex.submit(one,*c):c for c in todo}
    for f in cf.as_completed(fut):
        done+=1
        try: f.result()
        except Exception as e: fails.append((fut[f],str(e)))
        if done%100==0: print(done,'/',len(todo),'fails',len(fails),flush=True)
print('DONE',done,'fails',len(fails),fails[:10],flush=True)

#!/usr/bin/env python3
"""Download the chosen Commons photos at final size into images/ and write images/manifest.js.
Usage: python3 tools/build_photos.py tools/cands tools/picks.json"""
import json, os, re, subprocess, sys, time
UA="RotateAndThrive-hackathon/1.0 (educational crop-rotation demo)"
CANDS,PICKS=sys.argv[1],sys.argv[2]; ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__))); IMG=os.path.join(ROOT,'images'); os.makedirs(IMG,exist_ok=True)
picks=json.load(open(PICKS)); man={}
def width(slot): return 1600 if slot.startswith('hero') else 960 if slot.startswith('f-') else 320
for slot in sorted(os.listdir(CANDS)):
    mp=os.path.join(CANDS,slot,'meta.json')
    if not os.path.exists(mp): continue
    m=json.load(open(mp)); idx=picks.get(slot,0)
    if idx is None or idx>=len(m['cands']): continue
    c=m['cands'][idx]; url=re.sub(r'/\d+px-',f'/{width(slot)}px-',c['thumb']); out=os.path.join(IMG,slot+'.jpg')
    if not os.path.exists(out) or os.path.getsize(out)<3000:
        r=subprocess.run(['curl','-sfL','-m','90','-A',UA,'-o',out,url]); time.sleep(.35)
        if r.returncode!=0 or os.path.getsize(out)<3000: print('FAILED',slot,url); 
        if not os.path.exists(out) or os.path.getsize(out)<3000: continue
    a=re.sub(r'\s+',' ',c['artist']).strip()[:80] or (c['credit'] or 'Wikimedia Commons contributor')[:80]
    man[slot]={'file':'images/'+slot+'.jpg','title':c['title'],'artist':a,'license':c['license'],'page':c['page']}
open(os.path.join(IMG,'manifest.js'),'w').write('window.IMGS='+json.dumps(man,indent=0)+';\n')
print('installed',len(man),'photos;',sum(os.path.getsize(os.path.join(IMG,f)) for f in os.listdir(IMG) if f.endswith('.jpg'))//1024,'KB')

#!/usr/bin/env python3
"""Build images/sat/california.webp: NASA Blue Marble shaded relief (GIBS WMS, public domain) reprojected to Web Mercator,
California only (vivid), transparent outside the state line so it sits on images/sat/us.jpg.
Usage: curl the GIBS GetMap URL below to raw/sat/bm.jpg (source image, kept with the other raw downloads), then
  python3 tools/build_sat.py
GIBS: https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&LAYERS=BlueMarble_ShadedRelief_Bathymetry&STYLES=&SRS=EPSG:4326&BBOX=-125.5,31.5,-113.5,43&WIDTH=2400&HEIGHT=2300&FORMAT=image/jpeg"""
import json,re,math,sys
import numpy as np
from PIL import Image,ImageDraw,ImageFilter,ImageEnhance
import os
root=sys.argv[1] if len(sys.argv)>1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
W0,S0,E0,N0=-125.5,31.5,-113.5,43.0
src=np.asarray(Image.open(root+'/raw/sat/bm.jpg').convert('RGB')).astype(np.float32)/255
H0,Wd=src.shape[:2]
my=lambda lat:math.log(math.tan(math.pi/4+math.radians(lat)/2))
OW=Wd;OH=int(round(OW*(my(N0)-my(S0))/math.radians(E0-W0)))
# reproject rows to Web Mercator
ys=np.arange(OH)+.5;mv=my(N0)-ys/OH*(my(N0)-my(S0));lat=np.degrees(2*np.arctan(np.exp(mv))-math.pi/2)
rows=np.clip(((N0-lat)/(N0-S0)*H0).astype(int),0,H0-1)
img=src[rows]
# California mask from county outlines
s=open(root+'/data/ca_counties.js').read();C=json.loads(s[s.index('{'):s.rindex('}')+1]);MAPK=53.6
def px(x,y):
    la=42.1-y/MAPK;lo=x/(.8*MAPK)-124.6
    return ((lo-W0)/(E0-W0)*OW,(my(N0)-my(la))/(my(N0)-my(S0))*OH)
m=Image.new('L',(OW,OH),0);d=ImageDraw.Draw(m)
for c in C.values():
    for ring in re.findall(r'M([^MZ]+)Z?',c['d']):
        pts=[px(*map(float,p.split(','))) for p in ring.split('L') if p.strip()]
        if len(pts)>2:d.polygon(pts,fill=255)
m=m.filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.MinFilter(3))
mask=np.asarray(m.filter(ImageFilter.GaussianBlur(1.2))).astype(np.float32)[...,None]/255
# ocean detection: blue dominant
r,g,b=img[...,0],img[...,1],img[...,2]
ocean=((b>r+0.08)&(b>g+0.02)).astype(np.float32)
ocean=np.asarray(Image.fromarray((ocean*255).astype(np.uint8)).filter(ImageFilter.MedianFilter(5)).filter(ImageFilter.GaussianBlur(1.5))).astype(np.float32)[...,None]/255
lum=(0.3*r+0.59*g+0.11*b)[...,None]
# California: brighter, more saturated, greener vegetation
ca=np.clip((img-0.5)*1.25+0.5+0.06,0,1);cl=(0.3*ca[...,0]+0.59*ca[...,1]+0.11*ca[...,2])[...,None]
ca=np.clip(cl+(ca-cl)*1.3,0,1)
# shift toward green: vegetation (g>=r*0.8) greener, dry ground stays tan
veg=np.clip((ca[...,1]-ca[...,0]*0.78)*6,0,1)
ca[...,0]=ca[...,0]*(1-0.18*veg)*0.97
ca[...,1]=np.clip(ca[...,1]*(1+0.12*veg),0,1)
ca[...,2]=ca[...,2]*(1+0.05*veg)
# Neighbours: washed-out, pale grey-beige
nb=np.clip(0.55*lum+0.45*img,0,1)*0.55+0.42
nb=nb*np.array([1.0,0.99,0.96])
# Ocean: dark slate grey with a hint of the bathymetry
oc=np.array([0.20,0.23,0.24])+(lum-0.25)*0.25
# California only, transparent everywhere else: laid over images/sat/us.jpg on the U.S. map, so no box or pale band shows around the state
rgba=np.concatenate([np.clip(ca,0,1),mask],axis=2)
Image.fromarray((rgba*255).astype(np.uint8),'RGBA').save(root+'/images/sat/california.webp',quality=86,method=6)
print(OW,OH)

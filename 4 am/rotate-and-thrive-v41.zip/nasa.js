'use strict';
/* NASA data beyond the monthly weather record.
   Extra NASA POWER downloads for the chosen spot (live, in the browser): daily rain and daily highs (2001–2025)
      for extreme-rain, heat-stress and frost days, plus monthly topsoil wetness.
   All of it is optional: if a request fails (offline, blocked) the app keeps working on the cached monthly NASA record.
   Loaded after game.js. */

/* ---------- extra NASA POWER downloads for the chosen spot ---------- */
const POWER='https://power.larc.nasa.gov/api/temporal';
async function powerJSON(url){const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),45000);try{const r=await fetch(url,{signal:ctl.signal});if(!r.ok)throw new Error('HTTP '+r.status);return(await r.json()).properties.parameter}finally{clearTimeout(to)}}
async function fetchNasaExtras(lat,lon){const ext={},q=`community=AG&longitude=${lon}&latitude=${lat}&format=JSON`;
  const daily=powerJSON(`${POWER}/daily/point?parameters=PRECTOTCORR,T2M_MAX,T2M_MIN&${q}&start=20010101&end=20251231`).then(p=>{
    const yrs={};for(const[k,v]of Object.entries(p.PRECTOTCORR)){if(v<-900)continue;const y=k.slice(0,4),Y=yrs[y]=yrs[y]||{wet:0,max:0,hot:0,frost:0,n:0};Y.n++;if(v>=25)Y.wet++;if(v>Y.max)Y.max=v}
    for(const[k,v]of Object.entries(p.T2M_MAX)){if(v<-900)continue;const Y=yrs[k.slice(0,4)];if(Y&&v>=35)Y.hot++}
    for(const[k,v]of Object.entries(p.T2M_MIN)){if(v<-900)continue;const Y=yrs[k.slice(0,4)];if(Y&&v<0)Y.frost++}
    const L=Object.entries(yrs).filter(([,Y])=>Y.n>300).sort();if(L.length<10)return;
    ext.years=L.map(x=>+x[0]);ext.wetDays=L.map(x=>x[1].wet);ext.maxDay=L.map(x=>x[1].max);ext.hotDays=L.map(x=>x[1].hot);ext.frostDays=L.map(x=>x[1].frost)}).catch(e=>console.warn('NASA POWER daily unavailable',e));
  const monthly=(par)=>powerJSON(`${POWER}/monthly/point?parameters=${par}&${q}&start=2001&end=2025`).then(p=>{const v=Object.entries(p[par]).filter(([k,x])=>!k.endsWith('13')&&x>-900);if(!v.length)return;
    const byY={};v.forEach(([k,x])=>{(byY[k.slice(0,4)]=byY[k.slice(0,4)]||[]).push(x)});ext[par]=Object.values(byY).map(a=>mean(a))}).catch(()=>{});
  await Promise.all([daily,monthly('GWETTOP')]);if(ext.GWETTOP)ext.topWet=mean(ext.GWETTOP);
  return Object.keys(ext).length?ext:null}
/* fetch extras once per place, then refresh the page */
const _render=render;
render=function(){_render();
  const r=U.rec;if(!r||!U.loc||r._extTried)return;r._extTried=true;
  fetchNasaExtras(+U.loc.lat.toFixed(3),+U.loc.lon.toFixed(3)).then(ext=>{if(ext&&U.rec===r){r.ext=ext;_render()}})};

'use strict';
/* Titles are transparent comparison thresholds, not agronomic certifications. */
(function(root){
  const metrics={water:'Water',soil:'Soil',n:'Fertilizer',pest:'Pest',income:'Income',resil:'Dry-year resilience'};
  const definitions=[
    ['rain-keeper','Rain Keeper','water',{water:5},'Gain 5 water-score points.'],
    ['root-investor','Root Investor','soil',{soil:5},'Gain 5 soil-score points.'],
    ['nutrient-keeper','Nutrient Keeper','n',{n:5},'Gain 5 fertilizer-score points.'],
    ['cycle-breaker','Cycle Breaker','pest',{pest:5},'Gain 5 pest-score points.'],
    ['margin-maker','Margin Maker','income',{income:5},'Gain 5 income-score points.'],
    ['dry-year-defender','Dry-Year Defender','resil',{resil:5},'Gain 5 dry-year resilience points.'],
    ['deep-roots','Deep Roots','soil',{soil:10,resil:5},'Gain 10 soil points and 5 dry-year resilience points.'],
    ['lean-and-green','Lean & Green','water',{water:5,n:5},'Gain 5 points each in water and fertilizer.'],
    ['groundswell','Groundswell','soil',{soil:5,n:5,pest:5},'Gain 5 points each in soil, fertilizer and pests.'],
    ['rain-or-shine','Rain or Shine','resil',{water:5,resil:5,income:-2},'Gain 5 points each in water and resilience; lose no more than 2 income points.'],
    ['field-all-rounder','Field All-Rounder','all',null,'Gain 5 points in at least four scores; lose no more than 5 in any score.'],
    ['season-steady','Season Steady','overall',null,'Gain 5 median overall points and beat Current in at least 80% of paired weather sequences.'],
    ['water-wise','Water Wise','water',{water:10},'Gain 10 water-score points.'],
    ['soil-builder','Soil Builder','soil',{soil:15},'Gain 15 soil-score points.'],
    ['clean-feeder','Clean Feeder','n',{n:10},'Gain 10 fertilizer-score points.'],
    ['pest-proof','Pest-Proof','pest',{pest:15},'Gain 15 pest-score points.'],
    ['profit-grower','Profit Grower','income',{income:10},'Gain 10 income-score points.'],
    ['drought-ready','Drought Ready','resil',{resil:10},'Gain 10 dry-year resilience points.'],
    ['land-healer','Land Healer','soil',{soil:10,pest:10},'Gain 10 points each in soil and pests.'],
    ['water-and-wallet','Water & Wallet','water',{water:5,income:5},'Gain 5 points each in water and income.'],
    ['steady-earner','Steady Earner','income',{income:5,resil:5},'Gain 5 points each in income and dry-year resilience.'],
    ['low-input-grower','Low-Input Grower','n',{n:5,income:-2},'Gain 5 fertilizer points; lose no more than 2 income points.'],
    ['weather-ready','Weather Ready','resil',{water:5,soil:5,resil:5},'Gain 5 points each in water, soil and dry-year resilience.'],
    ['land-steward','Land Steward','soil',{soil:5,water:5,n:5},'Gain 5 points each in soil, water and fertilizer.'],
    ['nitrogen-fixer','Nitrogen Fixer','n',null,'Gain 5 fertilizer points with a legume (beans, peas, alfalfa, clover) in Proposed.'],
    ['cover-crop-champion','Cover Crop Champion','soil',null,'Gain 5 soil points with at least one winter cover crop in Proposed.'],
    ['clean-sweep','Clean Sweep','all',null,'Gain 5 points in all six scores.'],
    ['big-leap','Big Leap','overall',null,'Gain 15 median overall points.'],
    ['top-scorer','Top Scorer','overall',null,'Reach a median overall score of 80 or more, ahead of Current.'],
    ['small-steps','Small Steps','overall',null,'Gain 2 median overall points, beat Current in at least 60% of paired weather sequences, and lose no more than 5 in any score.']
  ];
  /* which scores each rule-based title is about ([] = the overall score) */
  const KEYS={'field-all-rounder':['water','soil','n','pest','income','resil'],'season-steady':[],'nitrogen-fixer':['n'],'cover-crop-champion':['soil'],
    'clean-sweep':['water','soil','n','pest','income','resil'],'big-leap':[],'top-scorer':[],'small-steps':[]};
  /* how high each rule-based title sets the bar, comparable to the summed point thresholds */
  const TIER={'field-all-rounder':20,'season-steady':10,'nitrogen-fixer':5,'cover-crop-champion':5,'clean-sweep':30,'big-leap':15,'top-scorer':20,'small-steps':2};
  function evaluate(E,options={}){
    const finite=Number.isFinite,d={};
    for(const k of Object.keys(metrics)){const c=E?.cur?.cat?.[k]?.med,p=E?.prop?.cat?.[k]?.med;d[k]=finite(c)&&finite(p)?p-c:null;}
    const current=E?.cur?.ov?.all||[],proposed=E?.prop?.ov?.all||[];
    const pairs=proposed.map((p,i)=>[current[i],p]).filter(([c,p])=>finite(c)&&finite(p));
    const wins=pairs.filter(([c,p])=>p>c).length,rate=pairs.length?wins/pairs.length:null;
    const cOverall=E?.cur?.ov?.med,pOverall=E?.prop?.ov?.med;
    const overall=finite(cOverall)&&finite(pOverall)?pOverall-cOverall:null;
    const unmodeled=['cur','prop'].some(k=>(E?.[k]?.first||[]).some(y=>y.rows?.some(r=>r.unmodeled)));
    const eligible=!!E&&!options.same&&!unmodeled;
    const change=k=>`${metrics[k]} ${d[k]>=0?'+':''}${d[k].toFixed(1)} pts`;
    const titles=definitions.map(([id,name,metric,thresholds,rule])=>{
      let met=false,evidence='';
      if(thresholds){const keys=Object.keys(thresholds);met=keys.every(k=>finite(d[k])&&d[k]>=thresholds[k]);if(met)evidence=keys.map(change).join('; ');}
      else if(id==='field-all-rounder'){const values=Object.values(d);met=values.every(finite)&&values.filter(x=>x>=5).length>=4&&values.every(x=>x>=-5);if(met)evidence=`${values.filter(x=>x>=5).length} scores gain at least 5 points; no score loses more than 5.`;}
      else if(id==='season-steady'){met=finite(overall)&&overall>=5&&pairs.length>=2&&rate>=.8;if(met)evidence=`Overall +${overall.toFixed(1)} pts; ahead in ${wins} of ${pairs.length} weather sequences.`;}
      else if(id==='nitrogen-fixer'){met=finite(d.n)&&d.n>=5&&!!options.legume;if(met)evidence=`${change('n')}; a legume adds nitrogen for the next crop.`;}
      else if(id==='cover-crop-champion'){met=finite(d.soil)&&d.soil>=5&&(options.covers||0)>=1;if(met)evidence=`${change('soil')}; ${options.covers} winter cover crop${options.covers>1?'s':''} in Proposed.`;}
      else if(id==='clean-sweep'){const v=Object.values(d);met=v.every(finite)&&v.every(x=>x>=5);if(met)evidence='All six scores gain at least 5 points.';}
      else if(id==='big-leap'){met=finite(overall)&&overall>=15;if(met)evidence=`Overall +${overall.toFixed(1)} pts.`;}
      else if(id==='top-scorer'){met=finite(pOverall)&&finite(overall)&&pOverall>=80&&overall>0;if(met)evidence=`Proposed overall ${pOverall.toFixed(0)} of 100.`;}
      else if(id==='small-steps'){const v=Object.values(d);met=finite(overall)&&overall>=2&&pairs.length>=2&&rate>=.6&&v.every(finite)&&v.every(x=>x>=-5);if(met)evidence=`Overall +${overall.toFixed(1)} pts; ahead in ${wins} of ${pairs.length} weather sequences.`;}
      const keys=thresholds?Object.keys(thresholds).filter(k=>thresholds[k]>0):(KEYS[id]||[metric]);
      const strength=keys.reduce((a,k)=>a+(finite(d[k])?Math.max(0,Math.min(30,d[k])):0),0)+(KEYS[id]&&KEYS[id].length===0&&finite(overall)?Math.max(0,overall):0);
      const tier=thresholds?Object.values(thresholds).filter(v=>v>0).reduce((a,v)=>a+v,0):(TIER[id]||5);
      return{id,name,metric,rule,keys,strength,tier,earned:eligible&&met,evidence:eligible&&met?evidence:''};
    });
    const note=unmodeled?'Titles are unavailable because this rotation includes crops the model does not score.':options.same?'Both rotations are the same. Try a different sequence to earn comparison titles.':`${options.illustrative?'Illustrative weather. ':''}Titles compare median scores across the weather sequences, not the single sequence shown below. They describe this modeled run, not measured field results.`;
    return{titles,note,basis:'ensemble-median-score-difference',delta:d,overallDelta:overall,pairedWins:wins,pairedCount:pairs.length};
  }
  root.RotationOutcomes={evaluate,definitions};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.RotationOutcomes;
})(typeof window!=='undefined'?window:globalThis);

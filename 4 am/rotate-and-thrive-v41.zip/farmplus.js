'use strict';
/* Farm size, harvest quantities, trade-off explorer and climate what-if.
   Loaded after gamecore.js and before game.js. Everything here reuses the existing model (runRotation, avgScores,
   summarize, ensembleRotations); it adds no new physics. */

/* ---------- typical full-yield per acre (EDUCATIONAL ESTIMATES, rough California magnitudes, not calibrated) ----------
   [tons per acre at 100% modeled yield, what is harvested]. The model's yield fraction (0–1) multiplies this. */
const YIELD_EST={tomato:[50,'fruit'],lettuce:[20,'heads'],broccoli:[8,'heads'],spinach:[10,'leaves'],carrot:[30,'roots'],garlic:[9,'bulbs'],onion:[25,'bulbs'],
  strawberry:[30,'berries'],melon:[15,'melons'],artichoke:[7,'buds'],corn:[28,'silage'],cotton:[.75,'lint'],wheat:[3,'grain'],safflower:[1.1,'seed'],
  sunflower:[1,'seed'],garbanzo:[1,'beans'],drybean:[1.1,'beans'],sorghum:[3,'grain'],rice:[4.3,'grain'],alfalfa:[7.5,'hay'],almond:[1.1,'kernels'],
  walnut:[2,'in-shell nuts'],pistachio:[1.5,'in-shell nuts'],peach:[15,'fruit'],citrus:[15,'fruit'],avocado:[4,'fruit'],olive:[4,'fruit'],
  pomegranate:[10,'fruit'],date:[4,'fruit'],jojoba:[.6,'seed'],winegrape:[7,'grapes'],tablegrape:[9,'grapes'],elderberry:[2,'berries'],
  wildflower:[0,'habitat — no harvest'],bunchgrass:[0,'grazing — no harvest'],
  graincorn:[5.6,'grain'],soybean:[1.5,'beans'],peanut:[2.1,'nuts'],oats:[1.2,'grain'],barley:[2,'grain'],canola:[1,'seed'],potato:[22,'tubers'],
  sugarbeet:[32,'roots'],pecan:[.6,'in-shell nuts'],apple:[20,'fruit']};
const tpa=id=>(YIELD_EST[id]||[0])[0];
const ACRES=()=>U.acres||40;
const fmtT=t=>t==null?'–':t>=100?fmt(t):t>=10?t.toFixed(0):t>=1?t.toFixed(1):t.toFixed(2);
const fmtUsd=x=>x==null?'–':(x<0?'−':'')+'$'+fmt(Math.abs(x));
const fmtD=(d,dig=0,suf='')=>{if(d==null)return'–';const r=+d.toFixed(dig);return r===0?'±0'+suf:(r>0?'+':'−')+Math.abs(r).toFixed(dig)+suf};
const med=a=>qtile(a,.5);

/* ---------- climate what-if: adjusted copy of the NASA weather record ---------- */
const CLIM_PRESETS=[['Today',0,0],['2 °C hotter',2,0],['25% less rain',0,-25],['Hot & dry',3,-30],['Megadrought',1.5,-50],['Wetter',.5,20]];
const climOn=()=>!!(U.clim&&(U.clim.dT||U.clim.dP));
const climLabel=c=>{c=c||U.clim||{dT:0,dP:0};const a=[];if(c.dT)a.push(`${c.dT>0?'+':'−'}${Math.abs(c.dT)} °C`);if(c.dP)a.push(`${c.dP>0?'+':'−'}${Math.abs(c.dP)}% rain`);return a.join(', ')||"today's climate"};
let _simRec={key:null,rec:null};
function simRec(){
  if(!U.rec||!climOn())return U.rec;const{dT,dP}=U.clim,key=dT+'|'+dP;
  if(_simRec.key===key&&_simRec.base===U.rec)return _simRec.rec;
  const R=U.rec,f=1+dP/100,sh=a=>a&&a.map(y=>y.map(v=>+(v+dT).toFixed(2)));
  /* rain scales every month; all temperatures shift; NASA root-zone wetness follows rain (and dries a little with heat) — a rough adjustment */
  const o={status:R.status,source:R.source+` · WHAT-IF ${climLabel()}`,years:R.years,P:R.P.map(y=>y.map(v=>+(v*f).toFixed(1))),Tm:sh(R.Tm),Tn:sh(R.Tn),Tx:sh(R.Tx),Tl:sh(R.Tl),
    Sw:R.Sw?R.Sw.map(y=>y.map(v=>+clamp(v*(1+.6*dP/100)-.012*dT,.02,1).toFixed(3))):null,retrieved:R.retrieved,sha:R.sha};
  const rec=recordFromArrays(o,U.loc?U.loc.lat:R.lat||36.5);
  rec.meanP=R.meanP;   /* keep today's average as the reference, so less rain really means less water available */
  _simRec={key,base:U.rec,rec};return rec}

/* ---------- harvest ---------- */
/* per-year harvest of one rotation-year report on this farm (tons) */
function harvestOf(rep){const w=rep&&rep.rows&&rep.rows[0],id=rep&&rep.slot&&rep.slot.crop;if(!id||!w||w.unmodeled||w.Y==null)return null;return{id,t:w.Y*tpa(id)*ACRES(),Y:w.Y}}
function harvestLine(k,t){const r=U.sim.E[k].first[t-1];
  const h=harvestOf(r),cr=r.slot.crop&&CROPS_G[r.slot.crop];
  if(!cr)return`<div class="hv"><span class="hvi">${pxe('basket')}</span><div><b>No harvest</b> — the field is fallow this year.</div></div>`;
  if(!h)return`<div class="hv"><span class="hvi">${pxe('basket')}</span><div><b>${esc(cr.name)}</b> isn't modeled, so no harvest is estimated.</div></div>`;
  const e=YIELD_EST[h.id]||[0,''];
  if(!e[0])return`<div class="hv"><span class="hvi">${pxe('basket')}</span><div><b>${esc(cr.name)}</b>: ${esc(e[1])} on ${fmt(ACRES())} acres.</div></div>`;
  if(h.Y===0)return`<div class="hv"><span class="hvi">${pxe('basket')}</span><div><b>No harvest yet</b> — young ${esc(cr.name.toLowerCase())} are not bearing.</div></div>`;
  return`<div class="hv" title="${fmt(e[0])} t/acre typical full yield × ${fmt(h.Y*100)}% modeled yield × ${fmt(ACRES())} acres (rough estimate)"><span class="hvi">${pxe('basket')}</span><div><b>${fmtT(h.t)} tons</b> of ${esc(cr.name.toLowerCase())} ${esc(e[1])} this year <span class="tiny">· ${fmt(ACRES())} acres × ${fmtT(e[0]*h.Y)} t/acre</span></div></div>`}

/* whole-run harvest from the ensemble: per crop {med,lo,hi} tons over the horizon on this farm */
function harvestTable(E){const A=ACRES(),H=U.horizon;
  const r2=v=>{if(v==null||!isFinite(v))return'–';const a=Math.abs(v);if(a<10)return v.toFixed(1);const p=Math.pow(10,Math.floor(Math.log10(a))-1);return fmt(Math.round(v/p)*p)};
  const row=k=>{const P=E[k].prod||{},n=E[k].num,crops=Object.keys(P).filter(id=>tpa(id)>0).map(id=>`<span>≈ ${r2(P[id].med*tpa(id)*A/H)} t ${esc(CROPS_G[id].name.split(' /')[0].split(' (')[0].toLowerCase())}</span>`).join('');
    const net=n.netPerAc.med*A;return`<div class="hvr"><b style="color:${RK[k].c}">${RK[k].n}</b>${crops}<span>≈ ${net<0?'−':''}$${r2(Math.abs(net))} net</span><span>≈ ${r2(n.water.med*A)} AF water</span></div>`};
  return`<div class="card hvcard" id="harvest"><div class="hvh"><b>${pxe('basket')} Harvest estimate <span class="tiny">per year</span></b><label class="acrow"><input type="number" class="acresIn" min="1" max="100000" step="1" value="${A}" aria-label="Farm size in acres"> acres</label></div>${row('cur')}${row('prop')}</div>`}

/* ---------- full evaluation of one rotation on a fixed set of weather sequences (for trade-offs) ---------- */
function evalFull(rot,seeds,rec){const st=setup(),ov=[],cat={},net=[],wat=[],ton=[];SCORE_CATS.forEach(([c])=>cat[c]=[]);
  for(const s of seeds){const reps=runRotation(rot,st,rec,s.idx,s.seed,U.mg),sc=avgScores(reps,st.zone);if(!sc)return null;
    ov.push(overallOf(sc,st.priority));SCORE_CATS.forEach(([c])=>cat[c].push(sc[c]));const sm=summarize(reps);net.push(sm.net/PLOT_AC/st.horizon);wat.push(sm.water);
    ton.push(reps.reduce((a,r)=>{const w=r.rows[0];return a+(w&&w.Y!=null&&!w.unmodeled?w.Y*tpa(r.slot.crop):0)},0)/st.horizon)}
  const o={ov:med(ov),cat:{},net:med(net),water:med(wat),tons:med(ton)};SCORE_CATS.forEach(([c])=>o.cat[c]=med(cat[c]));return o}

const TR={};   /* trade-off state: {i, key, list, base, busy} */
function tradeOptions(rot,i){const z=U.zone,s=rot[i],C=id=>CROPS_G[id],L=rot.length,out=[],lc=x=>x.charAt(0).toLowerCase()+x.slice(1),cur=C(s.crop);
  const put=(r,text,kind)=>out.push({rot:r,text,kind});
  [null,...Object.keys(COVERS)].forEach(cv=>{if(cv===s.cover||coverConflict(s.crop,cv,z))return;const r=copy(rot);r[i].cover=cv;
    put(r,cv?`${s.cover?'Switch cover to':'Add'} ${lc(COVERS[cv].name)}${s.cover?'':' winter cover'}`:`Remove the ${lc(COVERS[s.cover].name)} cover`,'cover')});
  const per=!!cur.perennial&&s.crop!=='alfalfa';
  Object.values(CROPS_G).filter(c=>c.id!==s.crop&&!c.unmodeled&&fitOf(c.id,z)!=='poor'&&(!!c.perennial&&c.id!=='alfalfa')===per).forEach(c=>{
    const r=copy(rot);r[i]={crop:c.id,cover:coverConflict(c.id,s.cover,z)?null:s.cover,yrs:s.yrs||1};put(r,`Grow ${c.name} instead of ${cur.name}`,'crop')});
  if(L>1){const r=copy(rot);r.splice(i,1);put(r,`Drop this ${cur.name} year`,'drop')}
  if(!per&&L<20)['garbanzo','drybean','wheat','safflower','sorghum'].filter(id=>CROPS_G[id]&&fitOf(id,z)!=='poor'&&id!==s.crop).slice(0,3).forEach(id=>{
    const r=copy(rot);r.splice(i+1,0,{crop:id,cover:autoCover(id,z)});put(r,`Add a year of ${C(id).name} after ${cur.name}`,'add')});
  return out}
function runTrade(i){const rot=U.rots.prop;if(!rot[i])return;TR.i=i;TR.busy=true;TR.list=null;render();
  setTimeout(()=>{try{const rec=simRec(),seeds=mkSeeds(setup(),rec,6,5000),base=evalFull(rot,seeds,rec);
      const list=tradeOptions(rot,i).map(o=>({...o,e:evalFull(o.rot,seeds,rec)})).filter(o=>o.e&&base);
      list.forEach(o=>{o.d={ov:o.e.ov-base.ov,net:(o.e.net-base.net)*ACRES(),af:(o.e.water-base.water)*ACRES(),tons:(o.e.tons-base.tons)*ACRES()};SCORE_CATS.forEach(([c])=>o.d[c]=(o.e.cat[c]||0)-(base.cat[c]||0))});
      list.sort((a,b)=>b.d.ov-a.d.ov);TR.list=list;TR.base=base;TR.key=JSON.stringify(rot)+climLabel()+U.priority+U.horizon;TR.acres=ACRES()}
    finally{TR.busy=false;render();const c=document.getElementById('tradeoffs');c&&c.scrollIntoView({block:'nearest'})}},30)}
function rescaleTrade(){if(!TR.list||TR.acres===ACRES())return;const f=ACRES()/TR.acres;TR.list.forEach(o=>{o.d.net*=f;o.d.af*=f;o.d.tons*=f});TR.acres=ACRES()}

function tradeCard(){
  const rot=U.rots.prop,pk={soil:'soil',water:'water',output:'income',resil:'resil'}[U.priority],yk=TR.y||(pk==='income'?'soil':pk);
  const stale=TR.list&&TR.key!==JSON.stringify(rot)+climLabel()+U.priority+U.horizon;if(stale){TR.list=null;TR.i=null}rescaleTrade();
  const chips=rot.map((s,i)=>`<button class="trchip ${TR.i===i?'on':''}" data-act="trpick" data-i="${i}" aria-pressed="${TR.i===i}">${cropIco(s.crop,22)}<span><small>${(()=>{const a=rot.slice(0,i).reduce((x,r)=>x+(r.yrs||1),0)+1,b=a+(s.yrs||1)-1;return a===b?`Year ${a}`:`Years ${a}–${b}`})()}</small>${esc(CROPS_G[s.crop].name)}${s.cover?' + '+esc(COVERS[s.cover].name.split(' ')[0].toLowerCase()):''}</span></button>`).join('');
  let body='';
  if(TR.busy)body=`<div class="tiny" style="padding:16px 0">${pxe('hourglass')} Testing every change for year ${TR.i+1} on ${6} weather sequences…</div>`;
  else if(TR.list){const L=TR.list,dc=(v,dig=0,suf='',inv=false)=>{const r=+((v||0).toFixed(dig)),good=inv?r<0:r>0;return`<td class="dv ${r===0?'z':good?'up':'dn'}">${fmtD(v,dig,suf)}</td>`};
    const cats=SCORE_CATS.map(([c,,l])=>[c,l]);
    body=`
    <div class="trtw"><table class="trt"><thead><tr><th>Change (year ${TR.i+1})</th>${cats.map(([c,l])=>`<th title="${esc(l)} score change">${ico('cat',c,18)}<span>${l.replace('Dry-year resilience','Resil.').replace('Fertilizer','Fert.')}</span></th>`).join('')}<th>Overall</th><th title="Harvest change per year, all crops (tons)">${pxe('basket')} t/yr</th><th title="Net income change per year on your farm">${pxe('cash')} /yr</th><th title="Irrigation water change per year on your farm (acre-feet); less is better">${pxe('drop')} AF/yr</th><th></th></tr></thead>
    <tbody>${L.map((o,j)=>j>=8&&!TR.all?'':`<tr class="${TR.sel===j?'sel':''}" data-trrow="${j}"><th>${esc(o.text)}<div class="tiny">${tradeWords(o.d)}</div></th>${cats.map(([c])=>dc(o.d[c])).join('')}${dc(o.d.ov,1)}${dc(o.d.tons,0).replace(/>([+−])(\d+)</,(m,g,n)=>`>${g}${fmt(+n)}<`)}${dc(o.d.net,0,'').replace(/>([+−±])(\d[\d.,]*)</,(m,s,n)=>`>${s==='±'?'±':s}$${fmt(+n)}<`)}${dc(o.d.af,0,'',true)}<td><button class="btn sm alt" data-act="trapply" data-i="${j}">Use</button></td></tr>`).join('')}</tbody></table></div>${L.length>8?`<div style="margin:8px 0"><button class="btn sm alt" data-act="trall">${TR.all?'Show the top 8 only':`Show all ${L.length} changes`}</button></div>`:''}
    <p class="tiny">Each row changes only one thing in your Proposed rotation, then reruns the model on the same 6 weather sequences${climOn()?` under the what-if climate (${esc(climLabel())})`:''}. Green = better, red = worse (for water use, less is better). Harvest tons add all crops together, so a switch between very different crops (e.g. tomatoes vs wheat) changes tons a lot. “Use” puts that change into Proposed and reruns the simulation.</p>`}
  else body=`<p class="tiny" style="padding:8px 0">Pick a year above to see what you gain and give up by changing just that year.</p>`;
  if(!U.trOpen)return`<div class="card trclosed" id="tradeoffs"><div><h2>${pxe('scale')} Trade-offs</h2><p class="tiny" style="margin:2px 0 0">See what you gain and give up by changing one year of your Proposed rotation.</p></div><button class="btn" data-act="tropen">Show trade-offs</button></div>`;
  return`<div class="card" id="tradeoffs"><div class="row" style="align-items:center;justify-content:space-between"><h2>${pxe('scale')} Trade-offs: change one thing</h2><button class="btn sm alt" data-act="trclose">Hide</button></div><p class="tiny" style="margin:2px 0 10px">Choose a year of your <b style="color:${RK.prop.c}">Proposed</b> rotation. You'll see every single change for that year — a different crop, a different or no winter cover, dropping the year, or adding a break crop — and what each one does to every score, the harvest, income and water on your ${fmt(ACRES())} acres.</p>
   <div class="trchips">${chips}</div>${body}</div>`}
function tradeWords(d){const cats=SCORE_CATS.map(([c,,l])=>[l.replace('Dry-year resilience','resilience').toLowerCase(),d[c]]).filter(x=>Math.abs(x[1])>=2).sort((a,b)=>Math.abs(b[1])-Math.abs(a[1]));
  const g=cats.filter(x=>x[1]>0).slice(0,2).map(x=>x[0]),l=cats.filter(x=>x[1]<0).slice(0,2).map(x=>x[0]);
  if(!g.length&&!l.length)return'Little difference.';return(g.length?'Better '+g.join(' & '):'')+(g.length&&l.length?' · ':'')+(l.length?'worse '+l.join(' & '):'')}

/* scatter: x = net income change on your farm, y = chosen score change. Quadrants are labeled (never colour-only). */
function tradeChart(L,yk){const W=640,H=300,m={l:58,r:18,t:28,b:42},iw=W-m.l-m.r,ih=H-m.t-m.b;
  const xs=L.map(o=>o.d.net),ys=L.map(o=>o.d[yk]),xm=Math.max(1,...xs.map(Math.abs))*1.22,ym=Math.max(2,...ys.map(Math.abs))*1.32;
  const X=v=>m.l+(v+xm)/(2*xm)*iw,Y=v=>m.t+(1-(v+ym)/(2*ym))*ih,yl=SCORE_CATS.find(c=>c[0]===yk)[2];
  const col=o=>{const a=o.d.net,b=o.d[yk];return a>=0&&b>=0?'#059669':a<0&&b<0?'#dc2626':'#d97706'};
  const tk=v=>Math.abs(v)>=1000?(v<0?'−':'')+'$'+fmt(Math.abs(v)/1000)+'k':(v<0?'−':'')+'$'+fmt(Math.abs(v));
  const xt=[-xm*.66,-xm*.33,0,xm*.33,xm*.66],yt=[-ym*.66,-ym*.33,0,ym*.33,ym*.66];
  return`<div class="trch"><div class="trax"><label class="tiny">Up/down axis: <select id="tryaxis">${SCORE_CATS.map(([c,,l])=>`<option value="${c}" ${c===yk?'selected':''}>${l}</option>`).join('')}<option value="ov" ${yk==='ov'?'selected':''}>Overall</option></select></label></div>
  <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Trade-off chart: each dot is one change; right = more income, up = better ${esc(yl||'overall')}">
   ${yt.map(v=>`<line x1="${m.l}" x2="${W-m.r}" y1="${Y(v)}" y2="${Y(v)}" stroke="#e2e8f0"/><text x="${m.l-6}" y="${Y(v)+4}" text-anchor="end" font-size="11" fill="#64748b">${fmtD(v,0)}</text>`).join('')}
   ${xt.map(v=>`<text x="${X(v)}" y="${H-m.b+16}" text-anchor="middle" font-size="11" fill="#64748b">${v===0?'$0':tk(v)}</text>`).join('')}
   <line x1="${X(0)}" x2="${X(0)}" y1="${m.t}" y2="${H-m.b}" stroke="#94a3b8"/><line x1="${m.l}" x2="${W-m.r}" y1="${Y(0)}" y2="${Y(0)}" stroke="#94a3b8"/>
   <text x="${W-m.r-4}" y="${m.t+12}" text-anchor="end" font-size="11.5" font-weight="600" fill="#047857">▲ Win-win</text><text x="${m.l+4}" y="${H-m.b-6}" font-size="11.5" font-weight="600" fill="#b91c1c">▼ Lose-lose</text>
   <text x="${m.l+4}" y="${m.t+12}" font-size="11.5" font-weight="600" fill="#b45309">Better ${esc((yl||'overall').toLowerCase())}, less money</text><text x="${W-m.r-4}" y="${H-m.b-6}" text-anchor="end" font-size="11.5" font-weight="600" fill="#b45309">More money, worse ${esc((yl||'overall').toLowerCase())}</text>
   <text x="${m.l+iw/2}" y="${H-6}" text-anchor="middle" font-size="12" fill="#334155">Net income change per year on ${fmt(ACRES())} acres →</text>
   <text transform="translate(14 ${m.t+ih/2}) rotate(-90)" text-anchor="middle" font-size="12" fill="#334155">${esc(yl||'Overall')} score change →</text>
   ${L.map((o,j)=>`<g class="trdot ${TR.sel===j?'sel':''}" data-trrow="${j}" tabindex="0"><circle cx="${X(o.d.net)}" cy="${Y(o.d[yk])}" r="14" fill="transparent"/><circle cx="${X(o.d.net)}" cy="${Y(o.d[yk])}" r="${TR.sel===j?8:6}" fill="${col(o)}" stroke="#fff" stroke-width="2"/><title>${esc(o.text)} — ${esc(yl||'Overall')} ${fmtD(o.d[yk],0)}, income ${fmtD(o.d.net/1,0).replace(/(\d[\d.]*)/,m=>'$'+fmt(+m))}/yr</title></g>`).join('')}
  </svg><div class="trtip" id="trtip" hidden></div></div>`}

/* ---------- what-if panel and comparison ---------- */
function whatIfPanel(){const c=U.cw||U.clim||{dT:0,dP:0};
  return`<div class="wipanel" id="whatif"><div class="row" style="align-items:center;justify-content:space-between"><h3 style="margin:0">${pxe('thermo')} What if the climate changes?</h3><button class="lnk2" data-act="wiclose" aria-label="Close what-if">✕</button></div>
   <p class="tiny" style="margin:4px 0 10px">Shifts every year of the NASA weather: all temperatures move by the amount you choose and every month's rain is scaled. Soil wetness follows the rain. Water allowed from the district follows the drier years. A simple scenario, not a climate projection.</p>
   <div class="wigrid"><div class="sl"><div class="t"><label for="wiT">Temperature change</label><b id="wiTv">${c.dT>0?'+':''}${c.dT} °C</b></div><input type="range" id="wiT" min="-2" max="5" step="0.5" value="${c.dT}" style="width:100%"><div class="tiny wiscale"><span>−2 °C</span><span>+5 °C</span></div></div>
   <div class="sl"><div class="t"><label for="wiP">Rainfall change</label><b id="wiPv">${c.dP>0?'+':''}${c.dP}%</b></div><input type="range" id="wiP" min="-60" max="40" step="5" value="${c.dP}" style="width:100%"><div class="tiny wiscale"><span>−60%</span><span>+40%</span></div></div></div>
   <div class="wipre">${CLIM_PRESETS.map(([n,t,p])=>`<button class="chip ${c.dT===t&&c.dP===p?'on':''}" data-act="wipreset" data-t="${t}" data-p="${p}">${n}</button>`).join('')}</div>
   <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap"><button class="btn" data-act="wirun">${U.page<4?'✔ Use this climate':'▶ Run what-if'}</button>${climOn()?'<button class="btn alt" data-act="wireset">Back to today\'s climate</button>':''}</div></div>`}
function whatIfBar(){return`<div class="wibar">${climOn()?`<span class="wion">${pxe('thermo')} What-if: <b>${esc(climLabel())}</b></span>`:''}<button class="btn sm ${climOn()?'alt':''}" data-act="wiopen">${pxe('thermo')} What if…</button>${climOn()?'<button class="btn sm alt" data-act="wireset">Back to today\'s climate</button>':''}${climOn()&&U.page===4&&U.sim&&U.sim.base?'<button class="lnk2" data-act="goto" data-v="5">Compare with today\'s climate →</button>':''}</div>${U.wiOpen?whatIfPanel():''}`}
/* compare what-if against today's climate (needs U.sim.base) */
function climateCard(){if(!climOn()||!U.sim||!U.sim.base)return'';const B=U.sim.base,E=U.sim.E,A=ACRES(),H=U.horizon;
  const tons=e=>Object.entries(e.prod||{}).reduce((a,[id,p])=>a+p.med*tpa(id)*A,0)/H;
  const cell=(a,b,dig=0,inv=false,f=v=>fmt(v))=>{if(a==null||b==null)return'<td>–</td>';const d=b-a,r=+d.toFixed(dig),good=inv?r<0:r>0;const ds=r===0?'±0':(r>0?'+':'−')+(dig?Math.abs(r).toFixed(dig):f(Math.abs(d)).replace(/^−/,''));return`<td><span class="wiv">${f(a)} → <b>${f(b)}</b></span> <span class="dv ${r===0?'z':good?'up':'dn'}">${ds}</span></td>`};
  const rows=[...SCORE_CATS.map(([c,,l])=>[`${ico('cat',c,18)} ${l}`,k=>cell(B[k].cat[c].med,E[k].cat[c].med)]),
    ['<b>Overall</b>',k=>cell(B[k].ov.med,E[k].ov.med)],
    [pxe('basket')+' Harvest (t/yr)',k=>cell(tons(B[k]),tons(E[k]),0,false,fmtT)],
    [pxe('cash')+' Net income /yr',k=>cell(B[k].num.netPerAc.med*A,E[k].num.netPerAc.med*A,0,false,fmtUsd)],
    [pxe('drop')+' Irrigation (AF/yr)',k=>cell(B[k].num.water.med*A,E[k].num.water.med*A,0,true)]];
  const dov=k=>E[k].ov.med-B[k].ov.med,hold=['cur','prop'].sort((a,b)=>dov(b)-dov(a))[0];
  return`<div class="card" id="climate"><h2>${pxe('thermo')} What-if climate: ${esc(climLabel())}</h2><p class="tiny" style="margin:2px 0 10px">Today's climate → what-if, middle of ${U.N} weather sequences, on ${fmt(A)} acres.
   <b style="color:${RK[hold].c}">${RK[hold].n}</b> holds up better (overall ${fmtD(dov(hold),1)} vs ${fmtD(dov(hold==='cur'?'prop':'cur'),1)}).</p>
   <div class="trtw"><table class="wit"><thead><tr><th></th><th style="color:${RK.cur.c}">Current</th><th style="color:${RK.prop.c}">Proposed</th></tr></thead><tbody>${rows.map(([l,f])=>`<tr><th>${l}</th>${f('cur')}${f('prop')}</tr>`).join('')}</tbody></table></div></div>`}

function runWhatIf(){const c=U.cw||{dT:0,dP:0};U.clim={dT:+c.dT,dP:+c.dP};U.wiOpen=false;TR.list=null;TR.i=null;
  if(!U.rots.cur.length||!U.rots.prop.length||U.page<4){render();return}
  const pg=U.page>=4?U.page:4;runSim();if(pg===5){stop();U.t=U.horizon;U.page=5;render()}
  const el=document.getElementById(U.page===5?'climate':'score');el&&el.scrollIntoView({block:'start'})}

/* ---------- events ---------- */
document.addEventListener('click',e=>{const b=e.target.closest('[data-act]');
  if(!b){const r=e.target.closest('[data-trrow]');if(r){TR.sel=+r.dataset.trrow===TR.sel?null:+r.dataset.trrow;render()}return}
  const a=b.dataset.act;
  if(a==='trpick'){TR.sel=null;runTrade(+b.dataset.i)}
  else if(a==='trapply'){const o=TR.list&&TR.list[+b.dataset.i];if(!o)return;U.rots.prop=copy(o.rot);TR.list=null;TR.i=null;TR.sel=null;runSim();stop();U.t=U.horizon;U.page=5;render();const c=document.getElementById('tradeoffs');c&&c.scrollIntoView({block:'start'})}
  else if(a==='wiopen'){U.wiOpen=!U.wiOpen;U.cw={...(U.clim||{dT:0,dP:0})};stop();render();const p=document.getElementById('whatif');p&&p.scrollIntoView({block:'nearest'})}
  else if(a==='wiclose'){U.wiOpen=false;render()}
  else if(a==='wipreset'){U.cw={dT:+b.dataset.t,dP:+b.dataset.p};render()}
  else if(a==='wirun')runWhatIf();
  else if(a==='trall'){TR.all=!TR.all;render()}
  else if(a==='tropen'){U.trOpen=true;render()}
  else if(a==='trclose'){U.trOpen=false;render()}
  else if(a==='acpre'){U.acres=+b.dataset.v;render()}
  else if(a==='wireset'){U.cw={dT:0,dP:0};runWhatIf()}});
document.addEventListener('input',e=>{const t=e.target;
  if(t.id==='wiT'||t.id==='wiP'){U.cw=U.cw||{dT:0,dP:0};if(t.id==='wiT')U.cw.dT=+t.value;else U.cw.dP=+t.value;
    const v=document.getElementById(t.id+'v');if(v)v.textContent=(t.id==='wiT'?`${U.cw.dT>0?'+':''}${U.cw.dT} °C`:`${U.cw.dP>0?'+':''}${U.cw.dP}%`);
    document.querySelectorAll('.wipre .chip').forEach(c=>c.classList.toggle('on',+c.dataset.t===U.cw.dT&&+c.dataset.p===U.cw.dP))}});
document.addEventListener('change',e=>{const t=e.target;
  if(t.classList&&t.classList.contains('acresIn')){const v=Math.round(+t.value);U.acres=clamp(isFinite(v)&&v>0?v:40,1,100000);render()}
  if(t.id==='tryaxis'){TR.y=t.value;render()}});
/* hover tooltip for the trade-off chart */
document.addEventListener('pointerover',e=>{const g=e.target.closest&&e.target.closest('.trdot'),tip=document.getElementById('trtip');if(!tip)return;
  if(!g){tip.hidden=true;return}const o=TR.list&&TR.list[+g.dataset.trrow];if(!o)return;const yk=document.getElementById('tryaxis').value,yl=yk==='ov'?'Overall':SCORE_CATS.find(c=>c[0]===yk)[2];
  tip.innerHTML=`<b>${esc(o.text)}</b><div>${esc(yl)}: <b>${fmtD(o.d[yk],yk==='ov'?1:0)}</b> · Income: <b>${o.d.net<0?'−':'+'}$${fmt(Math.abs(o.d.net))}</b>/yr</div><div>Harvest ${fmtD(o.d.tons,0)} t/yr · Water ${fmtD(o.d.af,0)} AF/yr</div>`;
  const r=g.getBoundingClientRect(),p=tip.parentElement.getBoundingClientRect();tip.style.left=(r.left-p.left+r.width/2)+'px';tip.style.top=(r.top-p.top)+'px';tip.hidden=false});

/* ---------- crop personality cards (traits come straight from the crop catalog) ---------- */
function cropPersona(c){const marg=c.rev-c.cost,win=c.months.some(m=>m>=11||m<=1);
  if(c.cat==='native')return['The Wild Helper','Feeds pollinators and soil life more than your wallet.'];
  if(c.nFix>0)return['The Soil Feeder','Pulls nitrogen out of the air and leaves some behind for the next crop.'];
  if(c.cat==='orchard'||c.cat==='vine'||c.bear>0)return['The Long-Haul Investor',`Costs money for ${c.bear||2} year${(c.bear||2)>1?'s':''} before it bears — then pays for decades.`];
  if(marg>=3000)return['The High Roller','Big money, big costs, and it needs a lot of care.'];
  if(c.kc>=1.1)return['The Thirsty Star','Earns well but drinks more water than most crops.'];
  if(c.heatThr>=36)return['The Heat Lover','Shrugs off Central Valley summers that stress other crops.'];
  if(win)return['The Winter Worker','Grows through the cool, rainy months when fields usually sit bare.'];
  if(c.res>=2)return['The Soil Builder','Leaves heaps of residue that turns into organic matter.'];
  if(c.heatThr<=27)return['The Cool Customer','Loves mild coastal weather and wilts in a heat wave.'];
  return['The Steady Worker','A dependable crop that does its job without drama.']}
function cropCards(){if(!U.sim)return'';const E=U.sim.E,used={};['cur','prop'].forEach(k=>U.rots[k].forEach(s=>{if(s.crop){(used[s.crop]=used[s.crop]||new Set()).add(k)}}));
  const ids=Object.keys(used);if(!ids.length)return'';
  const dots=(v,lab)=>{const n=Math.round(clamp(v,0,1)*4)+1;return`<div class="ptr"><span>${lab}</span><i aria-label="${n} of 5">${'●'.repeat(n)}<b>${'●'.repeat(5-n)}</b></i></div>`};
  const run=id=>{const ys=[],lims={};['cur','prop'].forEach(k=>E[k].first.forEach(r=>{if(r.slot.crop!==id)return;const w=r.rows[0];if(w&&w.Y!=null&&!w.unmodeled)ys.push(w.Y);if(w&&w.limits&&w.limits[0])lims[w.limits[0][0]]=(lims[w.limits[0][0]]||0)+1}));
    const lim=Object.entries(lims).sort((a,b)=>b[1]-a[1])[0];return{y:ys.length?mean(ys):null,lim:lim&&lim[0]}};
  const card=id=>{const c=CROPS_G[id],[t,tag]=cropPersona(c),r=run(id),marg=c.rev-c.cost,fam=Object.values(CROPS_G).filter(x=>x.fam===c.fam&&x.id!==id).slice(0,3).map(x=>x.name.split(' /')[0].split(' (')[0].toLowerCase());
    return`<div class="pcard"><div class="pch">${cropIco(id,40)}<div><small>${esc(t)}</small><b>${esc(c.name)}</b></div></div><p class="ptag">${esc(tag)}</p>
     <div class="ptraits">${dots(Math.min(1,(c.kc-.4)/.8),'Thirst')}${dots((c.heatThr-24)/14*(1-c.heatSens*.5),'Heat tolerance')}${dots(1-c.frostSens,'Frost toughness')}${c.nFix>0?dots(1,'Feeds the soil'):dots(c.nNeed/200,'Nitrogen hunger')}${dots(clamp(marg/6000,0,1),'Money maker')}${dots((c.res-.6)/1.9,'Soil builder')}</div>
     <div class="pfoot">${r.y!=null?`<span>In your run: <b>${fmt(r.y*100)}%</b> yield${r.lim?` · biggest drag: ${esc(r.lim.toLowerCase())}`:''}</span>`:c.unmodeled?'<span>Not modeled in this app</span>':''}
     <span>Family: ${esc(c.fam)}${fam.length?` — don't follow it with ${esc(fam.join(', '))}`:''}</span>
     <span class="pin">${[...used[id]].map(k=>`<em style="--c:${RK[k].c}">${RK[k].n}</em>`).join('')}</span></div></div>`};
  return`<div class="card" id="crops"><h2>${pxe('mask')} Meet your crops</h2><div class="pgrid">${ids.map(card).join('')}</div></div>`}

/* ---------- data confidence (deliberately low-key) ---------- */
function dataConfidence(){const r=U.rec,src=(r&&r.source)||'',E=U.sim&&U.sim.E,parts=[];
  const w=!r?0:r.status!=='available'?.3:/km away/.test(src)?.8:1;parts.push(['Weather (NASA POWER)',w,.25]);
  parts.push(['Soil moisture (NASA)',r&&r.Sw?1:.4,.1]);parts.push(['Soil texture (regional default)',.5,.1]);
  const ids=[...new Set(['cur','prop'].flatMap(k=>U.rots[k].map(s=>s.crop)).filter(Boolean))],unm=ids.filter(id=>CROPS_G[id].unmodeled).length/Math.max(1,ids.length);
  parts.push(['Crop & price numbers (uncalibrated estimates)',.4*(1-unm),.25]);
  let ag=.5;if(E){const sp=['cur','prop'].map(k=>E[k].ov.hi-E[k].ov.lo).filter(v=>v!=null),pP=E.prop.ov.all.filter((v,i)=>v!=null&&E.cur.ov.all[i]!=null&&v>E.cur.ov.all[i]).length/U.N;
    ag=.5*(1-clamp(mean(sp)/40,0,1))+.5*Math.abs(pP-.5)*2}parts.push(['Agreement across weather sequences',ag,.2]);
  parts.push(["Climate (today's vs what-if)",climOn()?.6:1,.1]);
  return{pct:Math.round(100*parts.reduce((a,[,v,wt])=>a+v*wt,0)),parts}}
function confHTML(){const c=dataConfidence();return`<details class="conf"><summary>Data confidence ${c.pct}%</summary><div>${c.parts.map(([l,v,w])=>`<div><span>${esc(l)}</span><b>${Math.round(v*100)}%</b><small>weight ${Math.round(w*100)}%</small></div>`).join('')}<p>A rough guide to how much to trust these numbers — the NASA weather is real; the crop, cost and soil numbers are educational estimates.</p></div></details>`}

/* ---------- prediction confidence card (summary) ----------
   Level comes from dataConfidence(): data quality + how much the 30 weather sequences agree. The comparison line says how
   often Proposed beat Current; the range is the 10th-90th percentile of Proposed's overall score. */
function confCard(){if(!U.sim)return'';const c=dataConfidence(),E=U.sim.E,r=U.rec,src=(r&&r.source)||'';
  const lvl=c.pct>=70?['High','hi']:c.pct>=45?['Medium','md']:['Low','lo'];
  const pP=E.prop.ov.all.filter((v,i)=>v!=null&&E.cur.ov.all[i]!=null&&v>E.cur.ov.all[i]).length/U.N,pp=Math.round(pP*100);
  const cons=pP>=.8||pP<=.2?'a consistent result':pP>=.65||pP<=.35?'a fairly consistent result':'too close to call';
  const winner=pP>=.5?'Proposed beats Current':'Current beats Proposed',share=pP>=.5?pp:100-pp;
  const up=[],dn=[];
  if(!r||r.status!=='available')dn.push('Weather is illustrative, not NASA data');else if(/km away/.test(src))up.push('Real NASA POWER weather, '+src.replace(/^NASA POWER \(cached for /,'from ').replace(/\)$/,''));else up.push('Real NASA POWER weather for this spot (2001–2025)');
  if(r&&r.Sw)up.push('NASA root-zone soil moisture sets the starting soil water');
  const sp=mean(['cur','prop'].map(k=>E[k].ov.hi-E[k].ov.lo).filter(v=>v!=null));
  (sp<12?up:dn).push(`Overall scores ${sp<12?'stay within':'spread across'} about ${fmt(sp)} point${Math.round(sp)===1?'':'s'} between wet and dry weather sequences`);
  if(pP>=.8||pP<=.2)up.push(`The winner is the same in ${share}% of ${U.N} weather sequences`);else if(pP>.35&&pP<.65)dn.push(`The winner flips between weather sequences (${pp}% / ${100-pp}%)`);
  dn.push('Crop yields, prices and costs are rounded educational estimates, not calibrated to farms');
  dn.push('Soil texture is a regional default, not a soil survey of your field');
  if(climOn())dn.push('A climate what-if is on, so the weather is shifted from the real record');
  if(typeof assumeChanged==='function'&&assumeChanged().length)up.push('Uses your own numbers for: '+assumeChanged().map(f=>f[1].toLowerCase()).join(', '));
  if(typeof liveMode==='function'&&liveMode())dn.push('Proposed was chosen year by year while watching one weather sequence');
  return`<details class="confc ${lvl[1]}" id="confSet" ${U.confOpen?'open':''}><summary class="confh"><h3>Prediction confidence</h3><span class="confpill">${lvl[0]} confidence · ${c.pct}%</span><span class="confmore tiny">Details <i aria-hidden="true">▾</i></span></summary>
  <div class="confbar" role="meter" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${c.pct}" aria-label="Prediction confidence"><i style="width:${c.pct}%"></i><span style="left:45%"></span><span style="left:70%"></span></div>
  <div class="confscale tiny"><span>Low</span><span>Medium</span><span>High</span></div>
  <p class="confcmp"><b>${winner}</b> in <b>${share}%</b> of ${U.N} weather sequences: ${cons}. Proposed's overall score ranges ${fmt(E.prop.ov.lo)}–${fmt(E.prop.ov.hi)} (most likely ${fmt(E.prop.ov.med)}).</p>
  <div class="confcols"><div><div class="tiny"><b>Raises confidence</b></div><ul>${up.map(x=>`<li>✓ ${esc(x)}</li>`).join('')}</ul></div><div><div class="tiny"><b>Lowers confidence</b></div><ul>${dn.map(x=>`<li>! ${esc(x)}</li>`).join('')}</ul></div></div>
  ${confHTML().replace('<summary>Data confidence '+c.pct+'%</summary>','<summary>How the '+c.pct+'% is worked out</summary>')}
  <p class="tiny" style="margin:6px 0 0">Use this to compare rotations, not as a yield or income forecast for your farm.</p></details>`}

/* ---------- What's hurting my crop? (summary) ----------
   Reads the model's own yield-loss factors for every simulated year (the weather sequence shown in the simulation):
   water shortfall (1−wsF), heat (1−heatF), frost (1−frostF), nitrogen (1−nF), pests/disease (1−pestF), young perennials (1−mat).
 */
const HURT=[['water',pxe('drop'),'Water shortfall','wsF','Not enough rain and irrigation for what the crop needs.','Try drip irrigation (More settings → Equipment), a higher water limit, or a crop that needs less water (below).'],
 ['heat',pxe('fire'),'Heat','heatF','Summer heat above what the crop tolerates.','Try a heat-tolerant crop, or one grown in the cooler months (below).'],
 ['frost',pxe('snow'),'Frost','frostF','Freezing nights while the crop is in the field.','Try frost protection (More settings → Equipment), or a crop that is not in the field during frost season.'],
 ['n',pxe('flask'),'Nitrogen','nF','Not enough nitrogen for the crop.','Grow a legume before it (garbanzo, beans, alfalfa), add a legume winter cover such as vetch or clover, or use the Standard/Compost fertilizer setting.'],
 ['pest',pxe('bug'),'Pests & disease','pestF','Pests and disease build up when crops from the same family follow each other.','Rotate to a crop from a different plant family (below).'],
 ['young',pxe('sprout'),'Young trees or vines','mat','Orchards and vineyards bear little or nothing in their first years.','Normal for new plantings; the loss ends once they start bearing.']];
function hurtStats(reps){const yrs=reps.filter(r=>r.rows&&r.rows[0]&&!r.rows[0].unmodeled&&r.rows[0].Y!=null&&r.slot.crop);
  const loss={},hit={},byCrop={};HURT.forEach(([k])=>{loss[k]=0;hit[k]=0});
  yrs.forEach(r=>{const w=r.rows[0],c=r.slot.crop,bc=byCrop[c]=byCrop[c]||{n:0,Y:0,loss:{}};bc.n++;bc.Y+=w.Y;
    HURT.forEach(([k,,,f])=>{const l=Math.max(0,1-(w[f]==null?1:w[f]));loss[k]+=l;if(l>.03)hit[k]++;bc.loss[k]=(bc.loss[k]||0)+l})});
  const n=Math.max(1,yrs.length);HURT.forEach(([k])=>loss[k]/=n);Object.values(byCrop).forEach(b=>{b.Y/=b.n;Object.keys(b.loss).forEach(k=>b.loss[k]/=b.n)});
  return{n:yrs.length,loss,hit,byCrop}}
/* compact card: one summary line, the causes as chips (hover for what it means and what to try), one tip,
   and a button that opens the Trade-offs explorer on the hardest-hit crop's year */
function hurtCard(E){if(!E)return'';const k=U.hurtK||'prop',st=hurtStats(E[k].first);
  const tabs=`<div class="seg one sm" role="group" aria-label="Rotation">${['prop','cur'].map(x=>`<button data-act="hurtk" data-v="${x}" class="${k===x?'on':''}">${RK[x].n}</button>`).join('')}</div>`;
  const head=`<div class="hthead"><h3>${pxe('scope')} What's hurting my crop?</h3>${tabs}</div>`;
  if(!st.n)return`<div class="card htcard" id="hurt">${head}<p class="tiny">No modeled crops in this rotation, so there is nothing to diagnose.</p></div>`;
  const top=HURT.map(h=>({h,l:st.loss[h[0]],hit:st.hit[h[0]]})).filter(x=>x.l>=.01).sort((a,b)=>b.l-a.l).slice(0,4);
  const avgY=mean(Object.values(st.byCrop).map(b=>b.Y)),worst=Object.entries(st.byCrop).sort((a,b)=>a[1].Y-b[1].Y)[0],wc=CROPS_G[worst[0]];
  const slotI=k==='prop'?U.rots.prop.findIndex(s=>s.crop===worst[0]):-1,live=typeof liveMode==='function'&&liveMode();
  return`<div class="card htcard" id="hurt">${head}
  <p class="htlead">${top.length?`Crops reach <b>${fmt(avgY*100)}%</b> of their best yield. Hardest hit: <b>${esc(wc.name.split(' (')[0])}</b> (${fmt(worst[1].Y*100)}%).`:`Nothing is hurting much: crops reach <b>${fmt(avgY*100)}%</b> of their best yield.`}</p>
  ${top.length?`<div class="htchips">${top.map(({h,l,hit})=>`<span class="htchip" title="${esc(h[4])} Try: ${esc(h[5])}">${h[1]} ${h[2]} <b>−${fmt(l*100)}%</b><small>${hit}/${st.n} yrs</small></span>`).join('')}</div>
  <p class="tiny httip"><b>Try:</b> ${esc(top[0].h[5].replace(/ \(below\)/,'').replace(/^Try /,''))}</p>`:''}
  ${top.length&&slotI>=0&&!live?`<button class="btn sm alt" data-act="hurttrade" data-i="${slotI}">${pxe('scale')} See trade-off crops for ${esc(wc.name.split(' (')[0])}</button>`:''}</div>`}
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('[data-act="hurtk"],[data-act="hurttrade"]');if(!b)return;
  if(b.dataset.act==='hurtk'){U.hurtK=b.dataset.v;render();return}
  U.trOpen=true;runTrade(+b.dataset.i)});

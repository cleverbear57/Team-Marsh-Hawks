/* Home-page photographs (Wikimedia Commons, free licenses). Generated. */
window.HOME_IMGS={
"hero": {
"file": "images/home/hero.jpg",
"label": "Salinas Valley",
"title": "File:The Nation's Salad Bowl - Flickr - Malcolm Carlaw.jpg",
"artist": "Malcolm Carlaw from San Luis Obispo, USA",
"license": "CC BY 2.0",
"page": "https://commons.wikimedia.org/wiki/File:The_Nation%27s_Salad_Bowl_-_Flickr_-_Malcolm_Carlaw.jpg"
},
"f-winegrape": {
"file": "images/home/f-winegrape.jpg",
"label": "Vineyard, Arroyo Seco",
"title": "File:J. Lohr Arroyo Seco Vineyard Rows.jpg",
"artist": "Danicox40",
"license": "CC BY-SA 4.0",
"page": "https://commons.wikimedia.org/wiki/File:J._Lohr_Arroyo_Seco_Vineyard_Rows.jpg"
},
"f-almond": {
"file": "images/home/f-almond.jpg",
"label": "Almond orchard",
"title": "File:NRCSCA06014 - California (973)(NRCS Photo Gallery).jpg",
"artist": "Photo courtesy of USDA Natural Resources Conservation Service.",
"license": "Public domain",
"page": "https://commons.wikimedia.org/wiki/File:NRCSCA06014_-_California_(973)(NRCS_Photo_Gallery).jpg"
},
"f-lettuce": {
"file": "images/home/f-lettuce.jpg",
"label": "Lettuce rows",
"title": "File:Starr 070313-5574 Lactuca sativa.jpg",
"artist": "Forest & Kim Starr",
"license": "CC BY 3.0",
"page": "https://commons.wikimedia.org/wiki/File:Starr_070313-5574_Lactuca_sativa.jpg"
},
"f-strawberry": {
"file": "images/home/f-strawberry.jpg",
"label": "Strawberry beds",
"title": "File:Strawberry field with plastic.jpg",
"artist": "Downtowngal",
"license": "CC BY-SA 3.0",
"page": "https://commons.wikimedia.org/wiki/File:Strawberry_field_with_plastic.jpg"
}
};

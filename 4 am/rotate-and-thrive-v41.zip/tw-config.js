/* Shared Tailwind (Play CDN) config — load right after the Tailwind script on every page.
   Design tokens match the CSS variables at the top of game.css. */
tailwind.config={
  corePlugins:{preflight:false},
  theme:{extend:{
    fontFamily:{sans:['Inter','ui-sans-serif','system-ui','-apple-system','Segoe UI','sans-serif'],display:['Inter','ui-sans-serif','system-ui','sans-serif']},
    colors:{
      brand:{50:'#ecfdf5',100:'#d1fae5',200:'#a7f3d0',300:'#6ee7b7',500:'#10b981',600:'#059669',700:'#047857',800:'#065f46',900:'#064e3b'},
      ink:{DEFAULT:'#0f172a',2:'#334155',mute:'#64748b'},
      line:'#e2e8f0'
    },
    boxShadow:{card:'0 1px 2px rgba(15,23,42,.04),0 1px 3px rgba(15,23,42,.06)',lift:'0 10px 30px -12px rgba(15,23,42,.18)'}
  }}
};

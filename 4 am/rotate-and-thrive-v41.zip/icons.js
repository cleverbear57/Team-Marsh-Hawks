'use strict';
/* Illustrated, shaded vector icons (replace emojis). 48×48 viewBox. Gradients are defined once in the page (see injectDefs). */
const GRADS={ /* id: [light, mid, dark] */
 'g-red':['#ff8a7a','#d63b2f','#8f1c14'],'g-orange':['#ffd27a','#f39c1f','#b3640a'],'g-leaf':['#b6e07a','#58a336','#2b6a1c'],'g-dark':['#7fb860','#2f7a2a','#17491a'],
 'g-green':['#c7e88a','#7dbb3d','#3c7a1c'],'g-yellow':['#fff3b0','#f2c230','#b88a10'],'g-brown':['#d9a96e','#8a5a2b','#4a2c12'],'g-purple':['#c79be6','#7a3fa0','#3f1659'],
 'g-cream':['#fffbf0','#efe0b8','#c9b07a'],'g-peach':['#ffd0a8','#f58d6a','#c4533b'],'g-blue':['#a8d8f5','#3d86c0','#1d4f82'],'g-white':['#ffffff','#f1f4f7','#cfd8df'],
 'g-avo':['#8fb84a','#476b22','#1f3010'],'g-olive':['#b5c46a','#6b7f2e','#3a4818'],'g-onion':['#f7d8a8','#c98a45','#8a5420'],'g-melon':['#f1dca4','#cdb072','#9a7d44'],
 'g-tan':['#eacb9a','#c79a5c','#8b6230'],'g-walnut':['#c79a68','#8a6038','#4f321a'],'g-date':['#d9894a','#8f4a1c','#4a2209'],'g-grape-g':['#e4f2a0','#a9cf4a','#64912a'],
 'g-redbrown':['#d98a6a','#a3472b','#5f1f10'],'g-gold':['#fbe9a0','#d9b04a','#a67c1f'],
 /* foliage by plant health: h0 stressed (brown-yellow) → h4 healthy */
 'g-h0':['#d8b878','#a5803c','#5f4518'],'g-h1':['#d9d070','#a8a22e','#5b5a14'],'g-h2':['#bfd864','#7fae35','#44661a'],'g-h3':['#9fd160','#56a232','#2b6a1c'],'g-h4':['#7fc45a','#3a8f2c','#1a5420']};
function injectDefs(){if(document.getElementById('icodefs'))return;
  const d=Object.keys(GRADS).map(id=>{const[a,b,c]=GRADS[id];return`<radialGradient id="${id}" cx=".35" cy=".3" r=".85"><stop offset="0" stop-color="${a}"/><stop offset=".55" stop-color="${b}"/><stop offset="1" stop-color="${c}"/></radialGradient>`}).join('');
  document.body.insertAdjacentHTML('afterbegin',`<svg id="icodefs" width="0" height="0" style="position:absolute" aria-hidden="true"><defs>${d}</defs></svg>`)}
const _c=(x,y,r,f,e='')=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${f}" ${e}/>`;
const _e=(x,y,rx,ry,f,e='')=>`<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${f}" ${e}/>`;
const _p=(d,f,e='')=>`<path d="${d}" fill="${f}" ${e}/>`;
const _hi=(x,y,rx,ry)=>_e(x,y,rx,ry,'#fff',`opacity=".42" transform="rotate(-35 ${x} ${y})"`);
const _sh=_e(24,44,14,2.4,'#000','opacity=".2"');
const _leaf=(x,y,a,s=1)=>`<g transform="translate(${x} ${y}) rotate(${a}) scale(${s})">${_p('M0 0 C6 -6 14 -4 18 0 C14 5 6 6 0 0z','url(#g-leaf)','stroke="#2b6a1c" stroke-width=".6"')}${_p('M1 0 L16 0','none','stroke="#2b6a1c" stroke-width=".6"')}</g>`;
const _berries=(pts,r,f)=>pts.map(([x,y])=>_c(x,y,r,f)+_c(x-r*.3,y-r*.3,r*.3,'#fff','opacity=".45"')).join('');
const _cluster=(f,leaf)=>{const pts=[[16,20],[24,19],[32,20],[19,27],[27,27],[22,34],[30,33],[24,40],[14,27],[34,27]].slice(0,9);return _sh+(leaf?_leaf(22,12,-30,1.1)+_p('M24 8 V18','none','stroke="#5a3d22" stroke-width="2"'):'')+_berries(pts,5.2,f)};

const CROP_ICO={
 tomato:()=>_sh+_c(24,27,15,'url(#g-red)')+_p('M24 13 l-3 4 l-6 -1 l4 5 l-5 3 l7 0 l3 3 l3 -3 l7 0 l-5 -3 l4 -5 l-6 1z','#3f8f2a','stroke="#2a6a1c" stroke-width=".6"')+_p('M23 7 h2 v7 h-2z','#2f6a1f')+_hi(18,22,5,3),
 strawberry:()=>_sh+_p('M24 43 C9 33 7 20 12 15 C17 11 22 14 24 14 C26 14 31 11 36 15 C41 20 39 33 24 43z','url(#g-red)')+[[17,22],[24,20],[31,22],[20,29],[28,29],[24,35],[16,30],[32,30]].map(([x,y])=>_e(x,y,1,1.6,'#f6e27a')).join('')+_leaf(24,14,-150,.9)+_leaf(24,14,-30,.9)+_leaf(24,14,-90,.8)+_hi(17,21,4,2.4),
 lettuce:()=>_sh+_e(24,30,18,12,'#3f8f2a')+[-40,0,40].map(a=>_e(24+a*.45,27,10,13,'url(#g-leaf)','stroke="#2b6a1c" stroke-width=".7" transform="rotate('+a*.6+' '+(24+a*.45)+' 27)"')).join('')+_e(24,26,8,8,'#b9e57f','opacity=".85"')+_p('M24 34 V20 M24 30 L18 24 M24 30 L30 24','none','stroke="#6aa43a" stroke-width=".9"'),
 broccoli:()=>_sh+_p('M19 44 L21 28 H27 L29 44z','#a9cf79')+[[15,24,8],[24,17,10],[33,24,8],[24,26,8]].map(([x,y,r])=>_c(x,y,r,'url(#g-dark)')+_berries([[x-2,y-2],[x+3,y-1],[x,y+3]],2.6,'#5fa03a')).join(''),
 spinach:()=>_sh+_p('M24 44 C7 35 5 17 24 5 C43 17 41 35 24 44z','url(#g-dark)','stroke="#17491a" stroke-width=".8"')+_p('M24 42 V10 M24 30 L14 22 M24 30 L34 22 M24 22 L18 16 M24 22 L30 16','none','stroke="#b9e08a" stroke-width="1.2"')+_hi(17,18,5,3),
 carrot:()=>_sh+_p('M31 15 C33 22 27 38 22 45 C18 38 12 24 15 16 C19 11 28 11 31 15z','url(#g-orange)','stroke="#b3640a" stroke-width=".7"')+_p('M17 22 h9 M18 29 h7 M20 36 h4','none','stroke="#b3640a" stroke-width=".9" opacity=".6"')+_p('M21 13 q-5 -8 -3 -11 q4 3 5 11 M24 12 q0 -9 3 -11 q2 6 -1 11 M27 13 q3 -6 8 -8 q-1 7 -6 10','url(#g-leaf)','stroke="#2b6a1c" stroke-width=".6"'),
 garlic:()=>_sh+_p('M24 10 C30 17 38 21 38 31 C38 40 30 44 24 44 C18 44 10 40 10 31 C10 21 18 17 24 10z','url(#g-cream)','stroke="#b9a273" stroke-width="1"')+_p('M24 15 C19 24 17 34 20 43 M24 15 C29 24 31 34 28 43','none','stroke="#b9a273" stroke-width="1.2"')+_p('M24 10 v-6','none','stroke="#cdb67f" stroke-width="3" stroke-linecap="round"')+_hi(17,26,3,6),
 onion:()=>_sh+_p('M24 9 C28 16 39 20 39 30 C39 40 31 44 24 44 C17 44 9 40 9 30 C9 20 20 16 24 9z','url(#g-onion)','stroke="#8a5420" stroke-width=".8"')+_p('M24 12 C20 22 18 34 21 43 M24 12 C28 22 30 34 27 43','none','stroke="#8a5420" stroke-width=".7" opacity=".6"')+_p('M24 9 q-1 -4 1 -6','none','stroke="#a98a52" stroke-width="2.4" stroke-linecap="round"')+_p('M21 44 l-2 3 M24 44 v3 M27 44 l2 3','none','stroke="#cdb67f" stroke-width="1"')+_hi(17,25,3,6),
 melon:()=>_sh+_c(24,26,16,'url(#g-melon)')+_p('M12 18 C20 24 28 24 36 18 M10 26 C18 32 30 32 38 26 M13 34 C20 38 28 38 35 34 M18 11 C16 22 16 30 19 40 M24 10 V42 M30 11 C32 22 32 30 29 40','none','stroke="#8d7240" stroke-width=".9" opacity=".7"')+_p('M24 10 q2 -5 5 -5','none','stroke="#5f7a2a" stroke-width="2"')+_hi(17,19,5,3),
 artichoke:()=>_sh+_p('M24 44 V34','none','stroke="#4f8a2e" stroke-width="3"')+[[24,32,12,11],[24,26,11,9],[24,20,8,9]].map(([x,y,rx,ry])=>_e(x,y,rx,ry,'url(#g-leaf)','stroke="#2b6a1c" stroke-width=".8"')).join('')+[-9,-4.5,0,4.5,9].map(o=>_p(`M${24+o} 36 Q${24+o*1.2} 26 ${24+o*.5} 14`,'none','stroke="#2b6a1c" stroke-width=".8"')).join('')+_hi(19,20,3,5),
 corn:()=>_sh+_p('M24 5 C30 7 32 20 30 37 C29 42 19 42 18 37 C16 20 18 7 24 5z','url(#g-yellow)','stroke="#b88a10" stroke-width=".7"')+Array.from({length:6},(_,i)=>_p(`M${19} ${12+i*5} h10`,'none','stroke="#b88a10" stroke-width=".5" opacity=".6"')).join('')+Array.from({length:4},(_,i)=>_p(`M${20.5+i*2.6} 8 V40`,'none','stroke="#b88a10" stroke-width=".5" opacity=".6"')).join('')+_p('M18 41 C6 32 6 18 13 9 C14 22 18 31 25 41z','url(#g-leaf)','stroke="#2b6a1c" stroke-width=".7"')+_p('M30 41 C42 32 42 18 35 9 C34 22 30 31 23 41z','url(#g-leaf)','stroke="#2b6a1c" stroke-width=".7"'),
 cotton:()=>_sh+_p('M24 30 l-11 7 l4 -11 l-9 -6 h11 l5 -11 l5 11 h11 l-9 6 l4 11z','url(#g-brown)')+[[17,21,7],[31,21,7],[24,15,8],[24,25,8]].map(([x,y,r])=>_c(x,y,r,'url(#g-white)','stroke="#cfd8df" stroke-width=".6"')).join(''),
 wheat:()=>_sh+_p('M24 46 V12','none','stroke="#a68a3a" stroke-width="2"')+Array.from({length:6},(_,i)=>{const y=14+i*5;return _e(19,y+2,2.2,4.4,'url(#g-gold)',`transform="rotate(-28 19 ${y+2})"`)+_e(29,y+2,2.2,4.4,'url(#g-gold)',`transform="rotate(28 29 ${y+2})"`)}).join('')+_e(24,8,2.4,5,'url(#g-gold)')+_p('M24 4 V-1','none','stroke="#a68a3a"'),
 safflower:()=>_sh+_p('M24 46 V28','none','stroke="#5f8a2e" stroke-width="3"')+_leaf(24,38,-40,1.1)+_leaf(24,34,-140,1.1)+_c(24,22,11,'#4f8a2e')+Array.from({length:16},(_,i)=>{const a=i*22.5;return _e(24,22,2.2,12,'url(#g-orange)',`transform="rotate(${a} 24 22)"`)}).join('')+_c(24,22,5,'#f6a21a'),
 sunflower:()=>_sh+_p('M24 46 V30','none','stroke="#4f8a2e" stroke-width="3"')+_leaf(24,38,-30,1.1)+Array.from({length:14},(_,i)=>_e(24,20,3,10,'#f4c20d',`transform="rotate(${i*25.7} 24 20)" stroke="#c9980a" stroke-width=".4"`)).join('')+_c(24,20,7.5,'url(#g-brown)')+[[22,18],[26,19],[24,22],[21,22],[27,22]].map(([x,y])=>_c(x,y,.9,'#2b1a0a')).join(''),
 garbanzo:()=>_sh+_p('M5 38 Q24 50 43 28','none','stroke="#6aa43a" stroke-width="3.2" stroke-linecap="round"')+_c(18,28,10,'url(#g-cream)','stroke="#c9b07a" stroke-width=".6"')+_p('M12 22 q-3 -3 -1 -5 q4 1 5 4z','url(#g-cream)')+_c(31,22,9,'url(#g-cream)','stroke="#c9b07a" stroke-width=".6"')+_hi(14,24,3,5)+_hi(28,18,3,4),
 drybean:()=>_sh+_p('M6 36 C10 44 34 46 42 28','none','stroke="#6aa43a" stroke-width="3.4" stroke-linecap="round"')+_p('M10 26 C10 14 30 9 38 17 C43 24 36 37 26 38 C17 40 10 34 10 26z','url(#g-cream)','stroke="#c9b07a" stroke-width=".7"')+_e(27,20,4.6,3.4,'#fff')+_e(27,20,3,2.2,'#222')+_hi(17,22,4,3),
 sorghum:()=>_sh+_p('M24 46 V24','none','stroke="#7a8a3a" stroke-width="2.6"')+_leaf(24,40,-30,1.2)+_leaf(24,34,-150,1.2)+_e(24,15,9,14,'url(#g-redbrown)')+Array.from({length:14},(_,i)=>_c(17+(i*7)%14,6+Math.floor(i/3)*5,1.6,'#7d3320','opacity=".8"')).join('')+_hi(20,12,2.5,5),
 rice:()=>_sh+_p('M14 46 C14 24 22 10 38 8','none','stroke="#a9b24a" stroke-width="2.4" stroke-linecap="round"')+Array.from({length:9},(_,i)=>{const t=i/8,x=36-t*14,y=9+t*14;return _e(x,y+3,1.8,4,'url(#g-gold)',`transform="rotate(${-30+t*50} ${x} ${y+3})"`)}).join('')+_leaf(14,44,-70,1.3),
 alfalfa:()=>_sh+_p('M24 46 V26','none','stroke="#4f8a2e" stroke-width="2"')+[0,120,240].map(a=>_e(24,16,5.5,9,'url(#g-leaf)',`transform="rotate(${a} 24 24)" stroke="#2b6a1c" stroke-width=".6"`)).join('')+_berries([[18,10],[24,7],[30,10],[21,13],[27,13]],2.4,'#9a5bc4')+_leaf(24,38,-40,1)+_leaf(24,34,-140,1),
 almond:()=>_sh+_p('M24 4 C34 12 39 28 24 44 C9 28 14 12 24 4z','url(#g-tan)','stroke="#8b6230" stroke-width=".8"')+_p('M24 6 C22 18 22 32 24 42','none','stroke="#8b6230" stroke-width=".9" opacity=".7"')+_p('M17 16 C15 26 18 34 22 40 M31 16 C33 26 30 34 26 40','none','stroke="#8b6230" stroke-width=".6" opacity=".5"')+_hi(19,16,2.4,6),
 walnut:()=>_sh+_c(24,26,16,'url(#g-walnut)','stroke="#4f321a" stroke-width=".8"')+_p('M24 10 C20 20 20 32 24 42 M24 10 C28 20 28 32 24 42','none','stroke="#4f321a" stroke-width="1"')+_p('M14 20 q4 3 6 0 M28 20 q4 3 6 0 M14 32 q4 -3 6 0 M28 32 q4 -3 6 0 M18 26 q2 2 4 0 M26 26 q2 2 4 0','none','stroke="#4f321a" stroke-width=".8" opacity=".6"')+_hi(17,18,4,3),
 pistachio:()=>_sh+_p('M24 6 C36 10 40 28 30 42 C26 46 20 46 16 42 C8 28 12 10 24 6z','url(#g-cream)','stroke="#c9b07a" stroke-width=".8"')+_p('M24 8 C32 20 32 34 26 44','none','stroke="#a98a52" stroke-width="1.4"')+_e(23,24,6,11,'url(#g-green)','stroke="#4f8a2e" stroke-width=".6" transform="rotate(-6 23 24)"')+_p('M24 8 C32 20 32 34 26 44 L22 44 C27 32 26 20 22 9z','url(#g-cream)')+_hi(16,18,2.5,6),
 peach:()=>_sh+_c(24,27,15,'url(#g-peach)')+_p('M24 13 C20 22 20 32 24 41','none','stroke="#b2483a" stroke-width="1.1" opacity=".7"')+_leaf(25,14,-20,1.1)+_p('M24 13 v-5','none','stroke="#5a3d22" stroke-width="2"')+_hi(17,21,5,3),
 citrus:()=>_sh+_c(24,26,16,'url(#g-orange)')+Array.from({length:26},(_,i)=>_c(10+((i*37)%28),12+((i*53)%28),.6,'#b3640a','opacity=".5"')).join('')+_leaf(26,11,-20,1.2)+_c(24,10,2,'#6a8a2a')+_hi(17,19,5,3.4),
 avocado:()=>_sh+_p('M24 4 C30 4 32 14 38 24 C46 40 36 46 24 46 C12 46 2 40 10 24 C16 14 18 4 24 4z','url(#g-avo)','stroke="#1f3010" stroke-width=".9"')+_p('M24 4 v-2','none','stroke="#5a3d22" stroke-width="2"')+_hi(17,28,3,8),
 olive:()=>_sh+_p('M6 12 C16 4 30 6 40 14','none','stroke="#8aa06a" stroke-width="1.4"')+[[14,9,-30],[22,6,-15],[31,8,20],[38,13,35]].map(([x,y,a])=>_e(x,y,6,2.2,'#9fb27a',`transform="rotate(${a} ${x} ${y})"`)).join('')+_e(17,30,8,12,'url(#g-olive)','transform="rotate(14 17 30)"')+_e(31,28,7,11,'url(#g-olive)','transform="rotate(-12 31 28)"')+_hi(14,26,2,5)+_hi(28,24,2,4),
 pomegranate:()=>_sh+_c(24,27,15,'url(#g-red)')+_p('M16 13 l2 -5 l3 4 l3 -5 l3 5 l3 -4 l2 5z','#a8231f')+_p('M12 24 C18 20 30 20 36 24','none','stroke="#7a1410" stroke-width=".7" opacity=".5"')+_hi(17,22,5,3),
 date:()=>_sh+_p('M24 4 V14','none','stroke="#6b4a2a" stroke-width="2.4"')+[[16,22],[24,20],[32,22],[19,31],[28,31],[22,39],[31,39]].map(([x,y])=>_e(x,y,4.4,7,'url(#g-date)','transform="rotate('+((x-24)*3)+' '+x+' '+y+')"')+_e(x-1,y-2,1,2.4,'#fff','opacity=".35"')).join(''),
 jojoba:()=>_sh+_p('M24 46 V20','none','stroke="#7a8a5a" stroke-width="2"')+[[-50,28],[50,28],[-40,18],[40,18],[0,10]].map(([a,y])=>_e(24,y,3.6,8.4,'#93a688',`transform="rotate(${a} 24 ${y+7})" stroke="#6f8266" stroke-width=".6"`)).join('')+_e(24,36,3.4,5,'url(#g-brown)'),
 winegrape:()=>_cluster('url(#g-purple)',true),
 tablegrape:()=>_cluster('url(#g-grape-g)',true),
 wildflower:()=>_sh+_p('M24 46 V26','none','stroke="#4f8a2e" stroke-width="2.4"')+_leaf(24,40,-40,1)+[[-1,-1],[1,-1],[-1,1],[1,1]].map(([x,y])=>_c(24+x*5.5,20+y*5,7,'url(#g-orange)','stroke="#c46d0a" stroke-width=".5" opacity=".95"')).join('')+_c(24,20,3.4,'#3a2412')+[0,1,2,3,4,5].map(i=>_c(24+Math.cos(i)*2,20+Math.sin(i)*2,.5,'#f0c040')).join(''),
 bunchgrass:()=>_sh+[[-16,30],[-9,36],[-3,40],[4,38],[10,34],[16,28]].map(([dx,h],i)=>_p(`M24 46 Q${24+dx*.2} ${46-h*.9} ${24+dx} ${46-h*.8}`,'none',`stroke="${i%2?'#6aa43a':'#4f8a2e'}" stroke-width="2" stroke-linecap="round"`)).join('')+[[-16,30],[16,28],[10,34]].map(([dx,h])=>_e(24+dx,46-h*.8,1.4,3.4,'#d9c46a')).join(''),
 elderberry:()=>_sh+[[-14,-10],[-7,-14],[0,-15],[7,-14],[14,-10]].map(([dx,dy])=>_p(`M24 40 L${24+dx} ${22+dy}`,'none','stroke="#a3472b" stroke-width="1.2"')).join('')+_berries(Array.from({length:30},(_,i)=>[14+((i*13)%20),10+((i*7)%14)+(i%3)]),2.2,'url(#g-purple)')+_p('M24 46 V38','none','stroke="#6b4a2a" stroke-width="2.4"')
};
const COVER_ICO={
 rye:()=>CROP_ICO.wheat().replace(/g-gold/g,'g-green'),
 vetch:()=>_sh+_p('M10 44 C14 30 12 20 22 10 M30 44 C28 30 34 22 38 12','none','stroke="#4f8a2e" stroke-width="2"')+[[14,26,-30],[18,16,-20],[28,34,30],[34,20,25]].map(([x,y,a])=>_leaf(x,y,a,.9)).join('')+_berries([[22,9],[26,11],[24,15],[38,10],[36,15]],2.8,'#8a4fc4'),
 mustard:()=>_sh+_p('M24 46 V20','none','stroke="#4f8a2e" stroke-width="2.4"')+_leaf(24,38,-45,1.1)+_leaf(24,32,-135,1.1)+_berries([[18,14],[24,10],[30,14],[21,19],[27,19],[24,15],[16,20],[32,20]],3.3,'#f6d51c'),
 clover:()=>_sh+_p('M24 46 V28','none','stroke="#4f8a2e" stroke-width="2"')+_c(24,20,11,'url(#g-red)')+Array.from({length:14},(_,i)=>_c(24+Math.cos(i*1.7)*6*(i%2?.7:1),20+Math.sin(i*1.7)*6*(i%2?.7:1),2.2,'#e0607a','opacity=".85"')).join('')+_leaf(24,40,-40,1)+_leaf(24,38,-140,1),
 nativemix:()=>_sh+CROP_ICO.wildflower().replace(/<ellipse cx="24" cy="44"[^>]*\/>/,'')
};
const EQUIP_ICO={
 drip:()=>_p('M4 38 H44','none','stroke="#222" stroke-width="3" stroke-linecap="round"')+[10,19,28,37].map(x=>_p(`M${x} 38 v3`,'none','stroke="#222" stroke-width="1.6"')+_p(`M${x} 44 c-2.4 -3 -3 -4.6 -3 -6 a3 3 0 0 1 6 0 c0 1.4 -.6 3 -3 6z`,'url(#g-blue)')).join('')+_p('M4 38 H44','none','stroke="#555" stroke-width=".8" opacity=".6"'),
 sprinkler:()=>_p('M22 44 V30 H26 V44z','#6c7b86')+_c(24,28,5,'url(#g-blue)')+[[-18,-14],[-9,-18],[0,-19],[9,-18],[18,-14]].map(([dx,dy])=>_p(`M24 26 Q${24+dx*.6} ${26+dy*1.1} ${24+dx*1.4} ${26+dy*.5}`,'none','stroke="#4aa0d8" stroke-width="1.6" stroke-linecap="round" stroke-dasharray="1 3"')).join('')+_e(24,44,10,2,'#000','opacity=".2"'),
 sensors:()=>_p('M8 30 H40 V44 H8z','url(#g-brown)')+_p('M22 8 H26 V34 H22z','#5a6b78')+_c(24,8,3.4,'url(#g-green)')+[8,13,18].map((r,i)=>_p(`M${24-r} ${8-r*.4} A${r} ${r} 0 0 1 ${24+r} ${8-r*.4}`,'none','stroke="#3d86c0" stroke-width="1.6" stroke-linecap="round" opacity="'+(1-i*.25)+'"')).join('')+_p('M22 30 v8 M26 30 v8','none','stroke="#222" stroke-width="1"'),
 notill:()=>_e(24,44,15,2,'#000','opacity=".2"')+_c(24,28,13,'#7a8892','stroke="#3b4650" stroke-width="2"')+_c(24,28,4,'#3b4650')+Array.from({length:8},(_,i)=>_p('M24 28 L'+(24+Math.cos(i*.785)*13).toFixed(1)+' '+(28+Math.sin(i*.785)*13).toFixed(1),'none','stroke="#3b4650" stroke-width="1.2"')).join('')+_p('M24 15 V5','none','stroke="#c0392b" stroke-width="3"')+_berries([[10,43],[18,43],[26,43],[34,43]],1.6,'#d9b04a'),
 frost:()=>_p('M22 44 H26 V16 H22z','#6c7b86')+_c(24,14,3,'#3b4650')+_p('M24 14 C30 6 38 6 40 10 C34 12 28 14 24 14z','url(#g-blue)','stroke="#1d4f82" stroke-width=".7"')+_p('M24 14 C18 22 10 22 8 18 C14 16 20 14 24 14z','url(#g-blue)','stroke="#1d4f82" stroke-width=".7"')+_p('M6 32 q3 -4 6 0 t6 0 M30 36 q3 -4 6 0 t6 0','none','stroke="#8ec8f0" stroke-width="1.6" stroke-linecap="round"')+_e(24,44,10,2,'#000','opacity=".2"'),
 compost:()=>_e(24,44,18,2.4,'#000','opacity=".2"')+_p('M5 42 C8 24 16 16 24 16 C32 16 40 24 43 42z','url(#g-brown)','stroke="#4a2c12" stroke-width=".8"')+_p('M12 38 q4 -3 7 0 M24 30 q4 -3 7 0 M30 38 q4 -3 7 0 M16 28 q3 -2 5 0','none','stroke="#4a2c12" stroke-width=".9" opacity=".6"')+_p('M24 16 V9','none','stroke="#4f8a2e" stroke-width="2"')+_leaf(24,10,-30,.9)+_leaf(24,10,-150,.9)
};
const CAT_ICO={
 water:()=>_p('M24 4 C32 15 38 22 38 30 C38 38 32 44 24 44 C16 44 10 38 10 30 C10 22 16 15 24 4z','url(#g-blue)','stroke="#1d4f82" stroke-width=".8"')+_hi(18,28,3,7),
 soil:()=>_p('M4 28 H44 V44 H4z','url(#g-brown)')+_p('M4 28 H44 V32 H4z','#4a2c12','opacity=".5"')+_p('M24 28 V16','none','stroke="#4f8a2e" stroke-width="2.6"')+_leaf(24,18,-30,1.1)+_leaf(24,18,-150,1.1)+[[10,38],[20,40],[32,37],[40,41]].map(([x,y])=>_c(x,y,1.4,'#c9a06a','opacity=".7"')).join(''),
 n:()=>_p('M19 6 H29 V18 L40 38 C42 42 40 44 36 44 H12 C8 44 6 42 8 38 L19 18z','url(#g-white)','stroke="#8aa0b0" stroke-width="1.2"')+_p('M14 32 H34 L38 40 C39 42 38 43 36 43 H12 C10 43 9 42 10 40z','url(#g-green)')+_c(20,36,1.8,'#fff','opacity=".7"')+_c(27,38,1.2,'#fff','opacity=".7"')+_p('M17 6 H31','none','stroke="#8aa0b0" stroke-width="2.4" stroke-linecap="round"'),
 pest:()=>_e(24,28,11,14,'url(#g-redbrown)','stroke="#3a1409" stroke-width=".9"')+_c(24,12,6,'#2b1a12')+_p('M24 15 V42','none','stroke="#3a1409" stroke-width="1.2"')+[[18,26],[30,26],[19,34],[29,34]].map(([x,y])=>_c(x,y,2.2,'#2b1a12')).join('')+_p('M13 22 L6 18 M13 29 L5 29 M14 36 L7 41 M35 22 L42 18 M35 29 L43 29 M34 36 L41 41 M20 7 L16 2 M28 7 L32 2','none','stroke="#2b1a12" stroke-width="1.4" stroke-linecap="round"'),
 income:()=>_c(24,24,19,'url(#g-yellow)','stroke="#a67c1f" stroke-width="1.6"')+_c(24,24,14.5,'none','stroke="#b88a10" stroke-width="1"')+`<text x="24" y="31" text-anchor="middle" font-size="22" font-weight="800" fill="#8a6410" font-family="Georgia,serif">$</text>`+_hi(16,14,4,2),
 resil:()=>_p('M24 3 L41 9 V24 C41 34 34 41 24 45 C14 41 7 34 7 24 V9z','url(#g-blue)','stroke="#1d4f82" stroke-width="1.2"')+_p('M24 3 L41 9 V24 C41 34 34 41 24 45z','#1d4f82','opacity=".25"')+_p('M15 24 L22 31 L34 17','none','stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"')
};
const UI_ICO={
 logo:()=>_c(24,24,21,'#1b4332')+_e(24,24,21,8,'none','stroke="#74c69d" stroke-width="1.6" transform="rotate(-25 24 24)"')+CROP_ICO.wheat().replace(/<ellipse cx="24" cy="44"[^>]*\/>/,'').replace('viewBox','viewBox')+_c(38,14,2.6,'#f4c20d'),
 pin:()=>_p('M24 46 C14 32 10 26 10 19 A14 14 0 0 1 38 19 C38 26 34 32 24 46z','#d94a38','stroke="#8f1c14" stroke-width="1"')+_c(24,19,5,'#fff'),
 sprout:()=>CAT_ICO.soil(),
 fallow:()=>_e(24,32,18,10,'url(#g-brown)')+_p('M8 30 q8 -4 16 0 t16 0','none','stroke="#4a2c12" stroke-width="1" opacity=".5"'),
 tree:()=>_p('M22 44 V30 H26 V44z','url(#g-brown)')+_c(24,20,14,'url(#g-dark)')+_c(16,24,8,'url(#g-leaf)')+_c(32,24,8,'url(#g-leaf)'),
 chart:()=>_p('M6 6 V42 H44','none','stroke="#4a5a52" stroke-width="2.4"')+_p('M12 34 H18 V40 H12z M22 26 H28 V40 H22z M32 14 H38 V40 H32z','url(#g-green)')
};
/* Real photographs (Wikimedia Commons, free licenses — see images/manifest.js and the credits dialog) are used wherever available;
   the drawn SVG icon is the fallback if a photo is missing. Interface symbols (pin, logo, chart…) stay as vector icons. */
window.IMGS=window.IMGS||{};
const PHOTO_PREFIX={crop:'c-',cover:'v-',equip:'e-',cat:'k-'};
function photo(slot,px,alt){const m=window.IMGS[slot];if(!m)return null;
  return`<img class="pic" src="${m.file}" width="${px}" height="${px}" alt="${(alt||'').replace(/"/g,'')}" loading="lazy" style="width:${px}px;height:${px}px" onerror="this.style.display='none'">`}
function ico(kind,id,px=28){const pre=PHOTO_PREFIX[kind];
  if(pre){const p=photo(pre+id,px,id);if(p)return p}
  const m={crop:CROP_ICO,cover:COVER_ICO,equip:EQUIP_ICO,cat:CAT_ICO,ui:UI_ICO}[kind],f=m&&m[id];
  return`<svg class="ico" viewBox="0 0 48 48" width="${px}" height="${px}" aria-hidden="true">${f?f():UI_ICO.fallow()}</svg>`}
const cropIco=(id,px)=>id?ico('crop',id,px):(photo('k-soil',px,'fallow soil')||ico('ui','fallow',px));

/* Hero banner: decorative landscape (no data) */
function heroSVG(){
  const rn=mulberry(11);let g=`<defs><linearGradient id="hsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4f9fe0"/><stop offset=".7" stop-color="#bfe3f5"/><stop offset="1" stop-color="#f6f1da"/></linearGradient><radialGradient id="hsun"><stop offset="0" stop-color="#fff7c2"/><stop offset=".4" stop-color="#ffe27a" stop-opacity=".6"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient><linearGradient id="hfield" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8a6a43"/><stop offset="1" stop-color="#4d3118"/></linearGradient><filter id="hb"><feGaussianBlur stdDeviation="4"/></filter></defs>
  <rect width="1200" height="300" fill="url(#hsky)"/><circle cx="980" cy="70" r="120" fill="url(#hsun)"/><circle cx="980" cy="70" r="30" fill="#fffbe0"/>
  <ellipse cx="220" cy="60" rx="110" ry="20" fill="#fff" opacity=".9" filter="url(#hb)"/><ellipse cx="300" cy="75" rx="80" ry="15" fill="#fff" opacity=".85" filter="url(#hb)"/><ellipse cx="640" cy="40" rx="90" ry="14" fill="#fff" opacity=".8" filter="url(#hb)"/>
  <path d="M0 170 Q180 100 380 150 T760 130 T1200 160 V220 H0Z" fill="#9db8a8" opacity=".8"/><path d="M0 190 Q220 140 460 180 T900 165 T1200 185 V240 H0Z" fill="#7aa35a"/>
  <polygon points="0,300 1200,300 820,196 380,196" fill="url(#hfield)"/>`;
  for(let i=0;i<=16;i++){const p=i/16,a=380+p*440,b=p*1200;g+=`<polygon points="${a-1},196 ${a+1},196 ${b+10},300 ${b-10},300" fill="#000" opacity=".22"/>`}
  for(let j=0;j<9;j++){const d=Math.pow((j+.5)/9,1.3),y=198+d*100,s=.35+d*1.2;for(let i=0;i<16;i++){const p=(i+.5)/16,x=(380+p*440)+((p*1200)-(380+p*440))*d;
    g+=`<ellipse cx="${x.toFixed(0)}" cy="${(y+1).toFixed(0)}" rx="${(9*s).toFixed(1)}" ry="${(2.4*s).toFixed(1)}" fill="#000" opacity=".25"/><ellipse cx="${x.toFixed(0)}" cy="${(y-5*s).toFixed(0)}" rx="${(8*s).toFixed(1)}" ry="${(6*s).toFixed(1)}" fill="url(#g-h4)" stroke="#1a5420" stroke-width=".6"/><circle cx="${(x-2*s).toFixed(0)}" cy="${(y-7*s).toFixed(0)}" r="${(2.6*s).toFixed(1)}" fill="#fff" opacity=".16"/>`}}
  return`<svg viewBox="0 0 1200 300" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${g}</svg>`}

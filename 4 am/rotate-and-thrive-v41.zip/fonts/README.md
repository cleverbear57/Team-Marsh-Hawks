# Astralaga font files go here

The site is set up to use **Astralaga** (licensed from Masterbundles / SG Type). It is a paid font, so the files are not included.

After you buy it, copy the web font files into this folder with these names (WOFF2 preferred; WOFF, OTF or TTF also work):

| Weight | File name |
|---|---|
| Regular (400) | `Astralaga-Regular.woff2` |
| Medium / SemiBold (500–600) | `Astralaga-Medium.woff2` |
| Bold (700) | `Astralaga-Bold.woff2` |

Reload the site and every page switches to Astralaga automatically (see the `@font-face` rules at the top of `game.css`).
Until the files are here, the site falls back to **Lora**, a free Google font with a similar classic serif look.

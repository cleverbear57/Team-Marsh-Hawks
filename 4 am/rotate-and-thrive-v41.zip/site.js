'use strict';
/* Shared site chrome: header nav + footer for every page. */
/* Site logo: a green leaf with a central vein on a soft green tile. */
function siteLogo(sz){const g='lf'+sz;return`<svg class="ico" width="${sz}" height="${sz}" viewBox="0 0 48 48" aria-hidden="true">
  <defs><linearGradient id="${g}" x1="10" y1="40" x2="40" y2="8" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#047857"/><stop offset="1" stop-color="#34d399"/></linearGradient></defs>
  <rect width="48" height="48" rx="13" fill="#ecfdf5"/><rect x=".5" y=".5" width="47" height="47" rx="12.5" fill="none" stroke="#a7f3d0"/>
  <path d="M11 37C9 22 19 10 38 9c1 19-10 30-27 28Z" fill="url(#${g})"/>
  <path d="M11 37C17 29 23 22 32 15" fill="none" stroke="#ecfdf5" stroke-width="2.2" stroke-linecap="round"/>
  <path d="M18 29.5l-1-6M23 24l-.5-6M27.5 20l7-.5M20.5 27l7 .5" fill="none" stroke="#ecfdf5" stroke-width="1.5" stroke-linecap="round" opacity=".85"/></svg>`}
const SITE_PAGES=[['index.html','Home'],['planner.html','Planner'],['data.html','Data & method']];
function siteHeader(active,opts={}){
  return`<div class="wrap hd"><a class="brand" href="index.html" aria-label="Rotate &amp; Thrive home"><span id="logo">${siteLogo(36)}</span><div><b>Rotate &amp; Thrive</b><small>Crop rotation, grounded in local weather</small></div></a>
  <nav class="sitenav" aria-label="Main">${SITE_PAGES.map(([h,l])=>`<a href="${h}" ${l===active?'aria-current="page"':''}>${l}</a>`).join('')}${opts.planner?'<button id="evBtn" class="lnk">Evidence &amp; model</button>':''}</nav></div>`}
function siteFooter(opts={}){
  return`<div class="wrap ft">
   <div class="ftbrand"><div class="brand">${siteLogo(32)}<b>Rotate &amp; Thrive</b></div><p>Compare U.S. crop rotations on 25 years of NASA weather and soil-moisture data. Built by Team Marsh Hawks for the 2026 NASA Space Apps Challenge.</p></div>
   <div><h4>Explore</h4>${SITE_PAGES.map(([h,l])=>`<a href="${h}">${l}</a>`).join('')}</div>
   <div><h4>Data</h4><span>NASA POWER (MERRA-2)</span><span>Root-zone soil wetness</span><span>USDA NASS Quick Stats</span><a href="data.html#photo-credits">Photo credits</a></div>
  </div>
  <div class="wrap ftlegal flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2"><span>Educational prototype. Crop, cost and yield numbers are unvalidated estimates — confirm decisions with your UC Cooperative Extension advisor.</span><span class="whitespace-nowrap">© 2026 Team Marsh Hawks</span></div>`}
function mountSite(active,opts){const h=document.getElementById('siteheader'),f=document.getElementById('sitefooter');if(h)h.innerHTML=siteHeader(active,opts);if(f)f.innerHTML=siteFooter(opts)}

const test=require('node:test');
const assert=require('node:assert/strict');
const {evaluate,definitions}=require('../outcomes.js');
const keys=['water','soil','n','pest','income','resil'];
function fixture(delta={},wins=0,overall=0){
  const result={};for(const k of ['cur','prop'])result[k]={cat:Object.fromEntries(keys.map(m=>[m,{med:50+(k==='prop'?(delta[m]||0):0)}])),ov:{med:50+(k==='prop'?overall:0),all:Array.from({length:30},(_,i)=>k==='cur'?50:i<wins?60:40)},first:[{rows:[{unmodeled:false}]}]};return result;
}
const earned=(data,options)=>evaluate(data,options).titles.filter(t=>t.earned).map(t=>t.id);
test('30 distinct titles, each with an explicit earning rule',()=>{assert.equal(definitions.length,30);assert.equal(new Set(definitions.map(d=>d[0])).size,30);assert.ok(evaluate(fixture()).titles.every(t=>t.rule));});
for(const [id,,metric] of definitions.slice(0,6)){
  test(`${id}: below threshold does not qualify; exactly 5 does`,()=>{assert.ok(!earned(fixture({[metric]:4.999})).includes(id));assert.ok(earned(fixture({[metric]:5})).includes(id));});
}
test('combined awards require every condition, including the income floor',()=>{assert.ok(earned(fixture({soil:10,resil:5})).includes('deep-roots'));assert.ok(!earned(fixture({soil:9.999,resil:5})).includes('deep-roots'));assert.ok(earned(fixture({water:5,n:5})).includes('lean-and-green'));assert.ok(!earned(fixture({water:5,n:4})).includes('lean-and-green'));assert.ok(earned(fixture({soil:5,n:5,pest:5})).includes('groundswell'));assert.ok(!earned(fixture({soil:5,n:5,pest:4})).includes('groundswell'));assert.ok(earned(fixture({water:5,resil:5,income:-2})).includes('rain-or-shine'));assert.ok(!earned(fixture({water:5,resil:5,income:-2.001})).includes('rain-or-shine'));});
test('all-rounder needs four gains and no material loss',()=>{assert.ok(earned(fixture({water:5,soil:5,n:5,pest:5,income:-5})).includes('field-all-rounder'));assert.ok(!earned(fixture({water:5,soil:5,n:5})).includes('field-all-rounder'));assert.ok(!earned(fixture({water:5,soil:5,n:5,pest:5,income:-6})).includes('field-all-rounder'));});
test('consistency requires 80% paired wins and a median gain',()=>{assert.ok(earned(fixture({},24,5)).includes('season-steady'));assert.ok(!earned(fixture({},23,5)).includes('season-steady'));assert.ok(!earned(fixture({},30,4.99)).includes('season-steady'));});
test('ties are not wins, missing values are not zero, and unavailable data never earns a title',()=>{const f=fixture({water:10});f.prop.cat.water.med=null;assert.ok(!earned(f).includes('rain-keeper'));f.prop.cat.water.med=NaN;assert.ok(!earned(f).includes('rain-keeper'));assert.equal(earned(null).length,0);const g=fixture({},30,5);g.prop.ov.all=g.cur.ov.all.slice();assert.ok(!earned(g).includes('season-steady'));});
test('same or partly unmodeled rotations cannot earn comparison titles',()=>{const f=fixture(Object.fromEntries(keys.map(k=>[k,15])),30,15);assert.equal(earned(f).length,27);assert.equal(earned(f,{same:true}).length,0);f.prop.first[0].rows[0].unmodeled=true;assert.equal(earned(f).length,0);});
test('illustrative weather is labeled and award calculation is deterministic',()=>{const f=fixture({water:5});assert.match(evaluate(f,{illustrative:true}).note,/Illustrative weather/);assert.deepEqual(evaluate(f),evaluate(f));assert.match(evaluate(f).titles[0].evidence,/Water \+5.0 pts/);});

test('new single-score tiers need the higher gain',()=>{assert.ok(earned(fixture({water:10})).includes('water-wise'));assert.ok(!earned(fixture({water:9.999})).includes('water-wise'));assert.ok(earned(fixture({soil:15})).includes('soil-builder'));assert.ok(!earned(fixture({soil:14})).includes('soil-builder'));});
test('nitrogen fixer and cover crop champion need the rotation fact as well as the gain',()=>{assert.ok(!earned(fixture({n:5})).includes('nitrogen-fixer'));assert.ok(earned(fixture({n:5}),{legume:true}).includes('nitrogen-fixer'));assert.ok(!earned(fixture({soil:5})).includes('cover-crop-champion'));assert.ok(earned(fixture({soil:5}),{covers:1}).includes('cover-crop-champion'));});
test('clean sweep needs all six scores up 5; big leap needs overall +15',()=>{const all=Object.fromEntries(keys.map(k=>[k,5]));assert.ok(earned(fixture(all)).includes('clean-sweep'));assert.ok(!earned(fixture({...all,pest:4})).includes('clean-sweep'));assert.ok(earned(fixture({},0,15)).includes('big-leap'));assert.ok(!earned(fixture({},0,14.9)).includes('big-leap'));});
test('every title reports the scores it is about',()=>{for(const t of evaluate(fixture()).titles)assert.ok(Array.isArray(t.keys));});

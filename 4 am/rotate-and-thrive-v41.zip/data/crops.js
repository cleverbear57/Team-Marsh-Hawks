'use strict';
/* Crop catalog for the game. ALL numeric values below are EDUCATIONAL ESTIMATES chosen to be plausible
   for California (rough UC-style sample-cost magnitudes); none is a sourced, calibrated coefficient.
   Confidence is "low" unless stated. See the in-game "How the model works" panel. */
const ZONES={
 sjv:{name:'San Joaquin Valley',gw:.85,alloc:1150,slope:.012,lat:36.5,lon:-119.7,typ:'central'},
 sac:{name:'Sacramento Valley',gw:.5,alloc:1050,slope:.015,lat:39.3,lon:-121.9,typ:'sacramento'},
 coast:{name:'Central Coast',gw:.9,alloc:680,slope:.02,lat:36.7,lon:-121.6,typ:'salinas'},
 south:{name:'South Coast / inland south',gw:.6,alloc:950,slope:.03,lat:34.2,lon:-118.6,typ:'south'},
 desert:{name:'Desert (Imperial / Coachella)',gw:.15,alloc:1800,slope:.004,lat:33.2,lon:-115.8,typ:'imperial'},
 north:{name:'North State / foothills',gw:.4,alloc:950,slope:.03,lat:40.5,lon:-122.3,typ:'north'}
};
const ZONE_TYPICAL={
 south:{precip:[75,80,60,20,5,1,0,0,3,10,25,50],tmax:[19,19,20,22,23,25,27,27,27,25,22,19],tmin:[7,8,9,10,12,14,16,16,15,12,9,7],et0:[50,55,80,100,115,125,135,130,105,80,55,45]},
 north:{precip:[150,120,100,60,35,15,3,5,20,60,130,160],tmax:[12,15,18,22,27,32,36,35,31,24,16,12],tmin:[2,3,5,7,10,13,15,14,12,8,4,2],et0:[20,35,70,105,150,180,200,175,125,75,35,18]}
};
/* categories: veg, field, orchard, vine, forage, native */
const CROP_LIST=[
 // id,name,emoji,cat,family,months[],kc,heatThr,heatSens,frostMonths,frostSens,ky,nNeed,nFix,rev,cost,res,bear,est,good,ok,note
 ['tomato','Processing tomato','🍅','veg','Solanaceae',[4,5,6,7,8,9],1.1,35,.5,[3,4,5],.8,1.0,180,0,5800,3800,1.2,0,0,['sjv','sac'],['coast','south'],'Warm-season transplant; frost-tender early; family shares wilt pathogens with peppers/potatoes.'],
 ['lettuce','Lettuce / leafy greens','🥬','veg','Asteraceae',[3,4,5,6],.95,27,.9,[2,3],.5,1.0,150,0,9000,7500,.8,0,0,['coast'],['south','sjv'],'Cool-season; bolts and tip-burns in heat; desert growers plant in winter.',{desert:[10,11,12,1,2]}],
 ['broccoli','Broccoli','🥦','veg','Brassicaceae',[3,4,5,6],.95,25,.7,[2,3],.4,1.0,200,0,7000,5800,1.2,0,0,['coast'],['south','sjv'],'Cool-season brassica; shares clubroot/Sclerotinia hosts with mustard covers.',{desert:[10,11,12,1,2]}],
 ['spinach','Spinach','🍃','veg','Amaranthaceae',[2,3,4],.9,24,.8,[1,2],.3,1.0,120,0,6200,4800,.7,0,0,['coast'],['sjv','sac'],'Fast cool-season crop.',{desert:[11,12,1,2]}],
 ['carrot','Carrots','🥕','veg','Apiaceae',[3,4,5,6,7],.9,30,.5,[2,3],.4,.9,100,0,6500,5000,.8,0,0,['sjv'],['coast','desert'],'Deep taproot; Kern County is a major producer.',{desert:[10,11,12,1,2,3]}],
 ['garlic','Garlic','🧄','veg','Alliaceae',[10,11,12,1,2,3,4,5,6],.8,30,.4,[],.1,.8,150,0,7500,6000,.9,0,0,['sjv','coast'],['sac'],'Fall-planted bulb crop; occupies the field through winter.'],
 ['onion','Onions','🧅','veg','Alliaceae',[2,3,4,5,6,7],.9,33,.4,[1,2],.4,.9,160,0,6000,4600,.8,0,0,['sjv','desert'],['coast','sac'],'Shallow roots; shares rots/white-rot hosts with garlic.',{desert:[10,11,12,1,2,3,4]}],
 ['strawberry','Strawberries','🍓','veg','Rosaceae',[1,2,3,4,5,6,7,8,9],.85,30,.5,[2,3],.5,.9,200,0,36000,30000,.6,0,0,['coast','south'],[],'High-value, high-input; heavy soil-borne disease management.'],
 ['melon','Cantaloupe / melons','🍈','veg','Cucurbitaceae',[4,5,6,7,8],1.0,38,.3,[3,4],.8,.9,120,0,4800,3600,.9,0,0,['sjv','desert'],['sac'],'Warm-season vine crop.',{desert:[2,3,4,5,6]}],
 ['artichoke','Artichokes','🌱','veg','Asteraceae',[1,2,3,4,5,6,7,8,9,10,11,12],.9,27,.7,[],0,.9,180,0,9500,7500,1.5,1,3000,['coast'],[],'Coastal perennial; Castroville is the classic area.'],
 ['corn','Silage corn','🌽','field','Poaceae',[4,5,6,7,8,9],1.15,33,.5,[3,4],.7,1.2,200,0,2300,1500,2.2,0,0,['sjv','sac'],['south','desert'],'Thirsty summer forage for dairies.'],
 ['cotton','Cotton','🌸','field','Malvaceae',[4,5,6,7,8,9,10],1.1,36,.25,[3,4],.6,.9,130,0,2300,1600,1.6,0,0,['sjv'],['desert'],'Heat-loving; acreage has fallen with water costs.'],
 ['wheat','Winter wheat','🌾','field','Poaceae',[11,12,1,2,3,4,5],1.0,28,.4,[],.1,.8,100,0,800,480,2.0,0,0,['sjv','sac','north'],['coast','desert','south'],'Mostly rain-fed in winter; fills the bare window; uses stored soil water.'],
 ['safflower','Safflower','🌼','field','Asteraceae',[3,4,5,6,7],.85,35,.3,[3],.3,.5,80,0,700,430,1.5,0,0,['sjv','sac'],['north'],'Deep taproot, drought-tolerant; modest margins.'],
 ['sunflower','Sunflower','🌻','field','Asteraceae',[4,5,6,7,8],.95,35,.3,[3,4],.4,.7,90,0,900,520,1.6,0,0,['sac','sjv'],['north'],'Shares Sclerotinia hosts with safflower/lettuce.'],
 ['garbanzo','Garbanzo (chickpea)','🫘','field','Fabaceae',[2,3,4,5,6],.9,30,.4,[2],.3,.6,20,50,900,520,1.2,0,0,['sjv','sac'],['coast','north'],'Cool-season legume; legume N credit is not guaranteed.'],
 ['drybean','Dry beans (blackeye)','🫘','field','Fabaceae',[5,6,7,8,9],.95,35,.5,[4,5],.7,.7,30,50,1500,900,1.2,0,0,['sjv'],['sac','desert'],'Warm-season legume; heat at flowering can cause blossom drop.'],
 ['sorghum','Sorghum','🌾','field','Poaceae',[5,6,7,8,9],.9,38,.15,[4,5],.7,.5,110,0,700,480,2.5,0,0,['sjv','desert'],['sac'],'Drought- and heat-tolerant summer grain/forage; heavy residue.'],
 ['rice','Rice','🍚','field','Poaceae',[5,6,7,8,9],1.2,35,.3,[4,5],.5,1.0,150,0,2800,1900,1.5,0,0,['sac'],[],'NOT MODELED: flooded-paddy water management needs its own treatment.',null,true],
 ['alfalfa','Alfalfa','🌿','forage','Fabaceae',[3,4,5,6,7,8,9,10],1.0,35,.3,[],0,1.1,0,150,2100,1100,2.0,0,300,['sjv','sac','desert'],['coast','north'],'Multi-year stand; already covers the soil; largest water user of the field crops.'],
 ['almond','Almonds','🌰','orchard','Rosaceae',[3,4,5,6,7,8,9,10],.95,36,.35,[2,3],.8,.9,200,0,5200,3800,1.0,3,7500,['sjv','sac'],['coast'],'Perennial: establishment cost and years to bearing; bloom frost risk.'],
 ['walnut','Walnuts','🌳','orchard','Juglandaceae',[4,5,6,7,8,9,10],1.05,35,.4,[3,4],.6,.9,180,0,5000,3500,1.0,5,7000,['sac','sjv'],['north'],'Perennial; sensitive to heat and to water stress during nut fill. (Northern California black walnut is a native used as rootstock.)'],
 ['pistachio','Pistachios','🥜','orchard','Anacardiaceae',[4,5,6,7,8,9],.9,38,.25,[3,4],.5,.6,160,0,4600,2900,1.0,5,7000,['sjv'],['desert','sac'],'Perennial; tolerant of heat and moderate salinity.'],
 ['peach','Peaches / plums','🍑','orchard','Rosaceae',[3,4,5,6,7,8,9],.95,35,.4,[2,3],.9,.9,150,0,6500,5200,.9,3,10000,['sjv'],['sac'],'Perennial; very bloom-frost sensitive.'],
 ['citrus','Oranges / citrus','🍊','orchard','Rutaceae',[1,2,3,4,5,6,7,8,9,10,11,12],.7,36,.3,[12,1,2],.9,.7,180,0,7000,5000,.9,3,9000,['sjv','south'],['desert'],'Evergreen perennial; frost is the main hazard.'],
 ['avocado','Avocados','🥑','orchard','Lauraceae',[1,2,3,4,5,6,7,8,9,10,11,12],.75,33,.6,[12,1,2],.9,.9,150,0,9000,6500,1.0,4,14000,['south'],['coast'],'Evergreen perennial; salt- and heat-sensitive.'],
 ['olive','Olives','🫒','orchard','Oleaceae',[3,4,5,6,7,8,9,10],.6,38,.2,[2,3],.5,.5,100,0,3000,2000,.8,4,5000,['sjv','sac','south'],['north','coast'],'Perennial; drought-tolerant; low-input.'],
 ['pomegranate','Pomegranates','🔴','orchard','Lythraceae',[4,5,6,7,8,9,10],.85,38,.25,[3],.4,.6,120,0,5500,3800,.9,3,6000,['sjv'],['desert'],'Perennial; heat-tolerant.'],
 ['date','Date palms','🌴','orchard','Arecaceae',[1,2,3,4,5,6,7,8,9,10,11,12],.9,45,.05,[],.1,.6,150,0,9000,6500,.8,6,12000,['desert'],[],'Perennial; thrives in desert heat but takes years to bear.'],
 ['jojoba','Jojoba (CA-native desert shrub)','🌿','native','Simmondsiaceae',[1,2,3,4,5,6,7,8,9,10,11,12],.4,45,0,[],.1,.3,40,0,1800,900,.8,5,3500,['desert'],['sjv'],'Native to the Sonoran/Mojave deserts; very low water use; slow to bear.'],
 ['winegrape','Wine grapes','🍇','vine','Vitaceae',[3,4,5,6,7,8,9,10],.65,35,.35,[3,4],.7,.6,40,0,5400,4100,.9,3,9000,['coast','sac','north'],['sjv'],'Perennial vine; frost at budbreak; deficit irrigation is normal practice.'],
 ['tablegrape','Table / raisin grapes','🍇','vine','Vitaceae',[3,4,5,6,7,8,9],.8,38,.3,[3,4],.7,.7,100,0,11000,8500,.9,3,14000,['sjv','desert'],['sac'],'Perennial; labor-intensive.'],
 ['wildflower','CA native wildflower / pollinator strip','🌼','native','Mixed natives',[11,12,1,2,3,4,5],.4,32,.1,[],0,.3,0,0,0,250,1.5,0,500,['coast','sac','sjv','north','south'],['desert'],'California poppy, lupine, phacelia, etc.; conservation value (pollinators) is not priced here.'],
 ['bunchgrass','Native bunchgrass pasture + grazing','🐑','native','Poaceae',[11,12,1,2,3,4,5],.5,32,.1,[],0,.4,0,0,400,150,1.5,1,600,['north','coast','sac'],['sjv','south'],'Purple needlegrass / California fescue; cool-season native grasses; grazing lease income is illustrative.'],
 ['elderberry','Blue elderberry (CA-native shrub)','🫐','native','Adoxaceae',[3,4,5,6,7,8,9],.7,35,.2,[3],.4,.5,60,0,1500,900,1.0,3,3000,['sac','north'],['sjv','coast'],'Native riparian shrub; small specialty market; also hedgerow habitat.']
];
const CROPS_G={};
for(const r of CROP_LIST){
  const[id,name,emoji,cat,fam,months,kc,heatThr,heatSens,frostMonths,frostSens,ky,nNeed,nFix,rev,cost,res,bear,est,good,ok,note,zm,unmodeled]=r;
  CROPS_G[id]={id,name,emoji,cat,fam,months,kc,heatThr,heatSens,frostMonths,frostSens,ky,nNeed,nFix,rev,cost,res,bear,est,good,ok,note,zm:zm||{},unmodeled:!!unmodeled,perennial:bear>0||cat==='orchard'||cat==='vine'||id==='alfalfa'||id==='artichoke'};
}
const CAT_LABEL={veg:'Vegetables & berries',field:'Field crops',forage:'Forage',orchard:'Orchards & nuts',vine:'Vines',native:'California-native options'};
/* winter cover crops (Oct–Mar). water = mm drawn from stored soil water; nominal N fixation is NOT assumed to be realised in full */
const COVERS={
 rye:{name:'Cereal rye',emoji:'🌾',cost:80,om:2.0,nFix:0,scav:.35,water:60,fam:'Poaceae',note:'Scavenges nitrate; heavy residue; can tie up N and use spring water.'},
 vetch:{name:'Hairy / common vetch',emoji:'🌱',cost:110,om:1.2,nFix:80,scav:.1,water:55,fam:'Fabaceae',note:'Legume: nominal N credit varies a lot with growth and termination.'},
 mustard:{name:'Mustard / brassica',emoji:'🌼',cost:90,om:1.0,nFix:0,scav:.2,water:50,fam:'Brassicaceae',note:'Deep taproot; same family as broccoli/cabbage, so shares their pathogens.'},
 clover:{name:'Crimson clover',emoji:'☘️',cost:95,om:1.0,nFix:70,scav:.05,water:45,fam:'Fabaceae',note:'Legume, good orchard/vineyard floor cover; flowers feed pollinators.'},
 nativemix:{name:'Native wildflower mix',emoji:'🌼',cost:140,om:1.3,nFix:0,scav:.1,water:40,fam:'Mixed natives',note:'Poppy/lupine/phacelia; pollinator habitat; slow to establish.'}
};
const COVER_MONTHS=[10,11,12,1,2,3];
/* equipment */
const EQUIP={
 drip:{name:'Drip irrigation',emoji:'💧',price:45000,maint:.05,desc:'Raises field water-delivery efficiency (typical mixed furrow/flood≈0.72 → drip≈0.90 delivered per unit pumped).'},
 sprinkler:{name:'Sprinkler / pivot',emoji:'🚿',price:25000,maint:.06,desc:'Efficiency ≈0.80 delivered per unit pumped.'},
 sensors:{name:'Soil-moisture sensors',emoji:'📟',price:6000,maint:.1,desc:'Better scheduling: +0.04 irrigation efficiency; helps avoid over/under-watering.'},
 notill:{name:'No-till drill',emoji:'🚜',price:30000,maint:.05,desc:'Cuts cover-crop seeding cost 40% and slows soil-carbon loss from tillage.'},
 frost:{name:'Frost protection (wind machines / sprinklers)',emoji:'🌬️',price:22000,maint:.06,desc:'Cuts modelled frost damage ~70% for frost-sensitive crops.'},
 compost:{name:'Compost spreader',emoji:'🧺',price:12000,maint:.05,desc:'Halves compost application cost.'}
};
const FERT={ /* synthetic N as a fraction of each crop's N need (legumes / low-N crops skip it); ≈$0.90 per lb N + $15 application */
 none:{name:'None',frac:0,costPerAc:0,om:0},
 low:{name:'Low (≈50% of crop N need)',frac:.5,costPerAc:0,om:0},
 standard:{name:'Standard (≈90% of crop N need)',frac:.9,costPerAc:0,om:0},
 high:{name:'High (≈120% of crop N need)',frac:1.2,costPerAc:0,om:0},
 compost:{name:'Compost (≈40 lb plant-available N + carbon)',lb:40,costPerAc:140,om:1.5}
};

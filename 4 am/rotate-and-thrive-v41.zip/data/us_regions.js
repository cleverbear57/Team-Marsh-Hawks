'use strict';
/* Planning outside California: U.S. farming regions, extra crops and regional crop fit.
   Load AFTER data/crops.js and gamecore.js (it extends ZONES, CROPS_G, SOILG, ZONE_SOIL and DEFAULT_CROP).
   Like the California catalog, every number here is a rounded EDUCATIONAL ESTIMATE (U.S.-average magnitudes),
   not a calibrated coefficient. Weather is still each pin's own NASA POWER record. */

/* gw = share of irrigation from groundwater · alloc = typical irrigation allowance (mm/season; small where farming is
   mostly rain-fed) · slope drives erosion · spring = first month a spring crop can go in (later where winters are cold) */
const US_ZONES={
 cornbelt: {name:'Corn Belt (Midwest)',gw:.5,alloc:150,slope:.03,spring:5,soil:'silt loam',crop:'graincorn'},
 plains_n: {name:'Northern & Central Plains',gw:.9,alloc:350,slope:.02,spring:5,soil:'silt loam',crop:'wheat'},
 plains_s: {name:'Southern Plains (TX / OK)',gw:.85,alloc:400,slope:.015,spring:3,soil:'clay loam',crop:'cotton'},
 delta:    {name:'Mississippi Delta',gw:.95,alloc:450,slope:.005,spring:4,soil:'silty clay',crop:'soybean'},
 southeast:{name:'Southeast',gw:.7,alloc:200,slope:.04,spring:3,soil:'sandy loam',crop:'cotton'},
 northeast:{name:'Northeast & Mid-Atlantic',gw:.5,alloc:100,slope:.05,spring:5,soil:'loam',crop:'graincorn'},
 mountain: {name:'Mountain West',gw:.35,alloc:750,slope:.02,spring:5,soil:'loam',crop:'alfalfa'},
 swdesert: {name:'Southwest desert (AZ)',gw:.4,alloc:1500,slope:.005,spring:2,soil:'sandy loam',crop:'alfalfa'},
 pnw:      {name:'Pacific Northwest',gw:.4,alloc:600,slope:.03,spring:4,soil:'silt loam',crop:'wheat'},
 hawaii:   {name:'Hawaii',gw:.5,alloc:500,slope:.05,spring:1,soil:'clay loam',crop:'citrus'},
 alaska:   {name:'Alaska',gw:.3,alloc:100,slope:.03,spring:6,soil:'loam',crop:'barley'}
};
/* state FIPS → region */
const US_STATE_ZONE={};
Object.entries({cornbelt:'19 17 18 39 29 27 55 26',plains_n:'38 46 31 20',plains_s:'48 40',delta:'05 28 22',
  southeast:'01 13 12 45 37 47 21 51',northeast:'36 42 34 09 25 44 50 33 23 24 10 54 11',mountain:'30 56 08 49 16 32 35',
  swdesert:'04',pnw:'53 41',hawaii:'15',alaska:'02'}).forEach(([z,s])=>s.split(' ').forEach(f=>US_STATE_ZONE[f]=z));
const US_STATE_ABBR={'01':'AL','02':'AK','04':'AZ','05':'AR','08':'CO','09':'CT','10':'DE','11':'DC','12':'FL','13':'GA','15':'HI','16':'ID','17':'IL','18':'IN','19':'IA','20':'KS','21':'KY','22':'LA','23':'ME','24':'MD','25':'MA','26':'MI','27':'MN','28':'MS','29':'MO','30':'MT','31':'NE','32':'NV','33':'NH','34':'NJ','35':'NM','36':'NY','37':'NC','38':'ND','39':'OH','40':'OK','41':'OR','42':'PA','44':'RI','45':'SC','46':'SD','47':'TN','48':'TX','49':'UT','50':'VT','51':'VA','53':'WA','54':'WV','55':'WI','56':'WY'};

/* Midwest/Plains prairie soils */
SOILG['silt loam']={awc:200,leach:.9,om0:45};

/* crops that matter outside California (same columns as CROP_LIST in data/crops.js) */
const US_CROP_LIST=[
 ['graincorn','Corn (grain)','🌽','field','Poaceae',[5,6,7,8,9],1.15,35,.45,[5],.6,1.25,180,0,850,600,2.2,0,0,['cornbelt','plains_n','northeast'],['delta','southeast','plains_s','mountain','pnw','sjv','sac'],'Rain-fed grain corn; the Corn Belt staple. Needs nitrogen; benefits from a soybean or legume year before it.'],
 ['soybean','Soybeans','🫛','field','Fabaceae',[5,6,7,8,9],1.0,35,.3,[5],.5,.85,20,40,600,380,1.0,0,0,['cornbelt','delta','plains_n','northeast','southeast'],['plains_s'],'Legume; the classic corn–soybean rotation partner. Low residue leaves soil exposed without a cover.'],
 ['peanut','Peanuts','🥜','field','Fabaceae',[5,6,7,8,9],1.0,37,.3,[5],.5,.7,20,40,1000,750,.8,0,0,['southeast','plains_s'],['delta'],'Southern legume; digging leaves little residue. Rotation cuts its soil diseases.'],
 ['oats','Oats','🌾','field','Poaceae',[4,5,6,7],.95,30,.5,[4],.3,.8,70,0,350,220,1.6,0,0,['plains_n','cornbelt'],['northeast','pnw','mountain','alaska'],'Cool-season small grain; easy rotation break and nurse crop.'],
 ['barley','Barley','🌾','field','Poaceae',[4,5,6,7,8],.95,30,.5,[4],.3,.8,90,0,450,300,1.8,0,0,['plains_n','mountain','pnw','alaska'],['northeast','cornbelt','sac','north'],'Spring small grain (feed / malting); short season fits cool climates.'],
 ['canola','Canola','🌼','field','Brassicaceae',[4,5,6,7,8],.95,30,.5,[4],.4,.8,120,0,500,330,1.3,0,0,['plains_n','pnw'],['mountain'],'Oilseed brassica; shares clubroot and Sclerotinia hosts with mustard covers.'],
 ['potato','Potatoes','🥔','veg','Solanaceae',[5,6,7,8,9],1.1,30,.6,[5],.6,1.1,220,0,5000,3800,.6,0,0,['pnw','mountain','plains_n','northeast'],['cornbelt','alaska','north'],'High-value, high-input; same family as tomatoes, so their diseases build up together.'],
 ['sugarbeet','Sugar beets','🫜','field','Amaranthaceae',[4,5,6,7,8,9],1.1,32,.4,[4],.4,1.0,140,0,1800,1200,.7,0,0,['plains_n','mountain'],['cornbelt','pnw','desert'],'Long-season root crop grown on contract; deep roots.'],
 ['pecan','Pecans','🌰','orchard','Juglandaceae',[4,5,6,7,8,9,10],1.0,38,.3,[3,4],.6,.9,120,0,2500,1600,1.0,7,5000,['southeast','plains_s'],['delta','swdesert'],'Native U.S. nut tree; slow to bear.'],
 ['apple','Apples','🍎','orchard','Rosaceae',[4,5,6,7,8,9,10],.95,33,.4,[4,5],.9,.9,80,0,9000,7000,1.0,4,12000,['pnw','northeast'],['cornbelt','mountain'],'Perennial; bloom frost is the main weather risk.']
];
for(const r of US_CROP_LIST){
  const[id,name,emoji,cat,fam,months,kc,heatThr,heatSens,frostMonths,frostSens,ky,nNeed,nFix,rev,cost,res,bear,est,good,ok,note]=r;
  CROPS_G[id]={id,name,emoji,cat,fam,months,kc,heatThr,heatSens,frostMonths,frostSens,ky,nNeed,nFix,rev,cost,res,bear,est,good,ok,note,zm:{},unmodeled:false,perennial:bear>0||cat==='orchard'||cat==='vine'};
}
/* where the California catalog's crops fit in other regions (anything not listed = poor fit there) */
const US_FIT={
 tomato:[[],['cornbelt','northeast','southeast','delta','plains_s','mountain','pnw']],
 lettuce:[['swdesert'],['northeast','pnw']], broccoli:[['swdesert'],['northeast','pnw','southeast']], spinach:[[],['northeast','pnw','plains_s','swdesert']],
 carrot:[[],['northeast','pnw','cornbelt','southeast']], garlic:[[],['pnw','northeast','mountain']], onion:[['pnw','mountain'],['northeast','plains_s','southeast','swdesert']],
 strawberry:[[],['southeast','northeast','pnw']], melon:[['swdesert'],['southeast','plains_s','delta']],
 corn:[['cornbelt','northeast'],['plains_n','mountain','pnw']], cotton:[['plains_s','delta','southeast'],['swdesert']],
 wheat:[['plains_n','plains_s','pnw','mountain'],['cornbelt','northeast','southeast','delta']], safflower:[[],['plains_n','mountain']],
 sunflower:[['plains_n'],['plains_s','mountain']], garbanzo:[['pnw'],['plains_n','mountain']], drybean:[['plains_n','mountain'],['cornbelt','pnw']],
 sorghum:[['plains_s','plains_n'],['delta','southeast']], alfalfa:[['mountain','plains_n','pnw','swdesert'],['cornbelt','northeast','plains_s']],
 pistachio:[[],['swdesert']], peach:[['southeast'],['northeast','delta']], citrus:[['southeast'],['plains_s','swdesert','hawaii']],
 avocado:[['hawaii'],['southeast']], olive:[[],['swdesert']], pomegranate:[[],['swdesert']], date:[[],['swdesert']], jojoba:[[],['swdesert']],
 winegrape:[['pnw'],['northeast','plains_s','mountain']], tablegrape:[[],['swdesert']]
};
for(const[id,[g,o]]of Object.entries(US_FIT)){const c=CROPS_G[id];if(!c)continue;c.good.push(...g);c.ok.push(...o)}

/* regions: season timing. Cold regions push spring/summer crops later (and their frost-risk months with them);
   the Arizona desert reuses the California desert's winter vegetable seasons. */
for(const[z,v]of Object.entries(US_ZONES)){
  ZONES[z]={name:v.name,gw:v.gw,alloc:v.alloc,slope:v.slope,lat:0,lon:0,typ:'north',us:true};
  ZONE_SOIL[z]=v.soil;DEFAULT_CROP[z]=v.crop;
  for(const c of Object.values(CROPS_G)){
    c.zf=c.zf||{};
    if(z==='swdesert'&&c.zm.desert){c.zm[z]=c.zm.desert;continue}
    const m=c.months,wraps=m.some((x,i)=>i&&x<m[i-1]);
    if(c.perennial||wraps||m.length>=12)continue;
    const shift=Math.max(0,v.spring-m[0]);if(!shift)continue;
    c.zm[z]=m.map(x=>Math.min(11,x+shift)).filter((x,i,a)=>a.indexOf(x)===i);
    c.zf[z]=c.frostMonths.map(x=>Math.min(11,x+shift));
  }
}
const usZoneOf=fips=>US_STATE_ZONE[String(fips).slice(0,2)]||null;

/* ---------- real data for a pin outside California (data/us_econ.js + live USDA soil survey) ----------
   Revenue = the state's NASS average yield x price received; cost = USDA ERS regional cost per acre (without land
   rent, fertilizer and irrigation water, which the model adds itself); crops with no ERS cost keep their catalog
   profit margin scaled to the real revenue. Water: the field can get the state's typical irrigation per irrigated
   acre x the share of this county's cropland that is irrigated. Returns a list of what was applied, for the page. */
/* USDA yields are state AVERAGES (typical years). The model's yield factor averages ≈0.89 in a normal rotation
   (measured across 10 state/crop pairs), so the reference "perfect year" revenue is the USDA average ÷ 0.89 —
   an average modelled year then earns about the real average revenue. */
const US_TYPICAL_Y=.89;
function applyUSData(zone,st,fips){
  const E=window.US_ECON,base=US_ZONES[zone],Z=ZONES[zone],used=[];
  Object.assign(Z,{alloc:base.alloc,gw:base.gw,ref:undefined});Object.values(CROPS_G).forEach(c=>{if(c.zr)delete c.zr[zone]});
  if(!E)return used;
  const S=E.states[st],share=E.irrShare[fips];
  if(S&&S.waterAf!=null){const typ=S.waterAf*304.8,sh=share!=null?share:.2;Z.ref=Math.max(100,typ);Z.alloc=Math.max(1,typ*sh);
    used.push({k:'water',t:`Irrigation: ${st} irrigated fields get ${S.waterAf.toFixed(1)} acre-ft/acre (USDA 2023 survey); ${share!=null?Math.round(share*100)+'% of this county’s cropland is irrigated (2022 Census)':'county share unknown, 20% assumed'}.`})}
  if(S){const ers=E.costs[S.ers]||{},sub=Object.entries(E.costs).filter(([k])=>k.startsWith(S.ers+' (')&&k.includes(st)).map(([,v])=>v)[0]||{},us=E.costs['U.S. total']||{};let nReal=0,nCost=0;
    for(const[id,d]of Object.entries(S.crops)){const c=CROPS_G[id];if(!c)continue;const ersCost=ers[id]??sub[id]??us[id];
      c.zr=c.zr||{};c.zr[zone]={rev:Math.round(d.rev/US_TYPICAL_Y),cost:ersCost!=null?ersCost:Math.round(d.rev*c.cost/Math.max(1,c.rev)),src:ersCost!=null?'ers':'scaled'};nReal++;if(ersCost!=null)nCost++}
    if(nReal)used.push({k:'money',t:`Revenue for ${nReal} crops from ${st}’s 2020–24 USDA yields × prices; costs for ${nCost} of them from USDA ERS (${S.ers}).`})}
  return used}
/* USDA NRCS soil survey (SSURGO) via Soil Data Access: dominant soil at the point → water-holding capacity,
   surface organic matter and texture. Returns null if the service is unreachable (the region default is used). */
async function fetchSoil(lat,lon){
  const q=`SELECT TOP 1 m.muname, a.aws0100wta, c.compname, c.comppct_r, h.om_r, h.sandtotal_r, h.silttotal_r, h.claytotal_r
   FROM SDA_Get_Mukey_from_intersection_with_WktWgs84('point(${(+lon).toFixed(5)} ${(+lat).toFixed(5)})') k
   JOIN mapunit m ON m.mukey=k.mukey LEFT JOIN muaggatt a ON a.mukey=k.mukey
   JOIN component c ON c.mukey=k.mukey AND c.majcompflag='Yes' JOIN chorizon h ON h.cokey=c.cokey AND h.hzdept_r=0
   ORDER BY c.comppct_r DESC`;
  const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),15000);
  try{const r=await fetch('https://SDMDataAccess.sc.egov.usda.gov/Tabular/post.rest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({format:'JSON+COLUMNNAME',query:q}),signal:ctl.signal});
    if(!r.ok)return null;const t=(await r.json()).Table;if(!t||t.length<2)return null;
    const o=Object.fromEntries(t[0].map((k,i)=>[k,t[1][i]])),n=k=>o[k]==null||o[k]===''?null:+o[k];
    const sand=n('sandtotal_r'),silt=n('silttotal_r'),clay=n('claytotal_r'),om=n('om_r'),aws=n('aws0100wta');
    const tex=clay==null?null:clay>=40?'clay':clay>=27?'clay loam':silt>=50?'silt loam':sand>=52?'sandy loam':'loam';
    return{name:o.muname,comp:o.compname,tex,sand,silt,clay,om,
      awc:aws!=null?clamp(aws*10,40,260):(SOILG[tex==='clay'?'silty clay':tex]||SOILG.loam).awc,
      leach:clamp(.7+(sand!=null?sand:40)/100*.8,.7,1.4),om0:Math.round(clamp(18+(om!=null?om:2)*7,20,65))}}
  catch(e){return null}finally{clearTimeout(to)}}

if(typeof syncBearing==='function')syncBearing();

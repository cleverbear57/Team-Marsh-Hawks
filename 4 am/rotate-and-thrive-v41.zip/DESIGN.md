# Rotate & Thrive design

The home page and planner share the existing emerald leaf identity. This is a restyle of the supplied app. The page order and five planning steps stay in place.

## System

- Genre: modern-minimal, with practical agricultural photography.
- Theme: existing brand, refined with garden-grey surfaces and dark green ink.
- Display: Plus Jakarta Sans; body and controls: Inter. System sans-serif fallbacks remain.
- Signature: the crop sequence and year-by-year comparison.
- Main container: 1200px; planner content: 960px; simulation retains its wider layout.
- Keep the existing local photos, crop sprites, maps and visual model.

## Tokens

`tokens.css` holds colours, fonts and motion values. Existing token names remain compatible with the planner.

| Role | Token | Value |
| --- | --- | --- |
| Page | `--bg` | `#f7f9f6` |
| Surface | `--card` | `#ffffff` |
| Main text | `--ink` | `#1c3028` |
| Supporting text | `--mute` | `#5b6c61` |
| Primary action | `--btn` | `#176447` |
| Selected surface | `--b50` | `#e5f0e6` |
| Field edge | `--field-edge` | `#82978a` |
| Focus | `--focus` | `#1c714e` |

## Controls and motion

- Primary buttons use green with light text; secondary actions use an outline or text.
- Press feedback: 120ms scale. Menus: 180ms opacity and transform, anchored above or below their trigger.
- Dropdowns keep the native select as their data source. Support arrows, Home, End, typeahead, Enter, Escape and Tab.
- Range values follow the pointer without replacing the input during a drag.
- Reduced motion removes spatial transitions. Reduced transparency uses solid surfaces.
- Keep step names visible on mobile; each step gives one short instruction.
- Earned titles show four previews, with the full set and exact rules in a disclosure.

## Exports

`tokens.css`, shared `game.css`, and `interactions.js`. No additional runtime library was introduced.

'use strict';
/* Field picture: a farm scene drawn only from the model's outputs for one rotation-year.
   Sky = that year's rain; soil colour = soil score; plant shape = crop; plant size/colour = yield & stress;
   gaps = pest/disease loss; cracks = water shortage; green strips = winter cover; cutaway = roots + NASA soil wetness.
   Shading, shadows, furrows, haze and soil grain are cosmetic only — they carry no extra information. */
const GLYPH={tomato:'bush',lettuce:'rosette',broccoli:'rosette',spinach:'rosette',artichoke:'rosette',carrot:'tops',garlic:'tops',onion:'tops',strawberry:'low',melon:'low',garbanzo:'low',drybean:'low',jojoba:'low',elderberry:'low',
  corn:'stalk',safflower:'stalk',sunflower:'sun',cotton:'cotton',wheat:'grain',sorghum:'grain',rice:'grain',alfalfa:'blades',bunchgrass:'blades',wildflower:'flower',
  almond:'tree',walnut:'tree',pistachio:'tree',peach:'tree',citrus:'tree',avocado:'tree',olive:'tree',pomegranate:'tree',date:'palm',winegrape:'vine',tablegrape:'vine'};
const FRUITG={tomato:'url(#g-red)',citrus:'url(#g-orange)',peach:'url(#g-peach)',pomegranate:'url(#g-red)',avocado:'url(#g-avo)',olive:'url(#g-olive)',strawberry:'url(#g-red)',melon:'url(#g-melon)',date:'url(#g-date)',tablegrape:'url(#g-grape-g)',winegrape:'url(#g-purple)',elderberry:'url(#g-purple)'};
const ROOTM={veg:.6,field:1,forage:1.5,orchard:1.5,vine:1.5,native:1};
const mixRGB=(a,b,t)=>`rgb(${a.map((v,i)=>Math.round(v+(b[i]-v)*t)).join(',')})`;
const DENS={veg:[7,9,9],field:[9,13,7],forage:[10,15,6],orchard:[4,5,15],vine:[5,8,9],native:[7,9,7]};
const OUTL=['#5f4518','#5b5a14','#44661a','#2b6a1c','#1a5420'];

function glyph(type,id,x,y,s,fg,dark,Y,rng,bearing,far){
  const f=FRUITG[id],n=Math.round(clamp(Y,0,1)*5),f1=v=>+v.toFixed(1);let o='';
  const fruit=(cx,cy,r,count,g)=>{let d='';for(let i=0;i<count;i++){const px=f1(cx+(rng()-.5)*r*2),py=f1(cy+(rng()-.2)*r*1.4);d+=`<circle cx="${px}" cy="${py}" r="${f1(1.7*s)}" fill="${g}"/><circle cx="${f1(px-.5*s)}" cy="${f1(py-.5*s)}" r="${f1(.5*s)}" fill="#fff" opacity=".5"/>`}return d};
  const leaf=(cx,cy,rx,ry,a)=>`<ellipse cx="${f1(cx)}" cy="${f1(cy)}" rx="${f1(rx)}" ry="${f1(ry)}" fill="${fg}" stroke="${dark}" stroke-width=".35" transform="rotate(${a} ${f1(cx)} ${f1(cy)})"/>`;
  o+=`<ellipse cx="${x}" cy="${f1(y+.4)}" rx="${f1(6.5*s)}" ry="${f1(1.9*s)}" fill="#1a0f05" opacity=".28"/>`;
  if(far&&type!=='tree'&&type!=='palm'&&type!=='vine')return o+`<ellipse cx="${x}" cy="${f1(y-3*s)}" rx="${f1(5*s)}" ry="${f1(4*s)}" fill="${fg}" stroke="${dark}" stroke-width=".3"/>`;
  switch(type){
    case'bush':for(let a=0;a<7;a++){const an=a*51.4+rng()*20;o+=leaf(x+Math.cos(an*Math.PI/180)*4*s,y-5*s+Math.sin(an*Math.PI/180)*3*s,4.6*s,2.3*s,an)}o+=`<ellipse cx="${x}" cy="${f1(y-6*s)}" rx="${f1(4.4*s)}" ry="${f1(3.6*s)}" fill="${fg}" stroke="${dark}" stroke-width=".4"/>`+(bearing?fruit(x,y-4*s,5.4*s,n,f):'');break;
    case'rosette':for(let r=0;r<3;r++){const cnt=8-r*2,rad=(5-r*1.6)*s;for(let a=0;a<cnt;a++){const an=a*360/cnt+r*18;o+=leaf(x+Math.cos(an*Math.PI/180)*rad*.8,y-3*s-r*1.2*s+Math.sin(an*Math.PI/180)*rad*.45,(4.2-r*.8)*s,(2.8-r*.5)*s,an)}}o+=`<ellipse cx="${x}" cy="${f1(y-5*s)}" rx="${f1(2*s)}" ry="${f1(1.4*s)}" fill="#fff" opacity=".18"/>`;break;
    case'tops':for(let a=-3;a<=3;a++)o+=leaf(x+a*1.4*s,y-5*s,1.5*s,5.2*s,a*11);break;
    case'low':for(let a=0;a<4;a++)o+=`<circle cx="${f1(x+(a-1.5)*3*s)}" cy="${f1(y-3*s-(a%2)*1.2*s)}" r="${f1(3.4*s)}" fill="${fg}" stroke="${dark}" stroke-width=".4"/>`;o+=bearing&&f?fruit(x,y-3*s,5*s,Math.min(n,3),f):'';break;
    case'stalk':o+=`<line x1="${x}" y1="${y}" x2="${x}" y2="${f1(y-16*s)}" stroke="${dark}" stroke-width="${f1(1.7*s)}"/>`;for(let a=0;a<3;a++){const yy=y-(5+a*4.2)*s;o+=`<path d="M${x} ${f1(yy)} q${f1(8*s)} ${f1(-4*s)} ${f1(10*s)} ${f1(2*s)}" stroke="${dark}" stroke-width="${f1(2.4*s)}" fill="none" stroke-linecap="round"/><path d="M${x} ${f1(yy)} q${f1(8*s)} ${f1(-4*s)} ${f1(10*s)} ${f1(2*s)}" stroke="${fg}" stroke-width="${f1(1.6*s)}" fill="none" stroke-linecap="round"/><path d="M${x} ${f1(yy-2*s)} q${f1(-8*s)} ${f1(-4*s)} ${f1(-10*s)} ${f1(2*s)}" stroke="${fg}" stroke-width="${f1(1.6*s)}" fill="none" stroke-linecap="round"/>`}o+=bearing?`<ellipse cx="${f1(x+2*s)}" cy="${f1(y-9*s)}" rx="${f1(1.5*s)}" ry="${f1(3.4*s)}" fill="#e8c34a"/>`:'';break;
    case'sun':o+=`<line x1="${x}" y1="${y}" x2="${x}" y2="${f1(y-14*s)}" stroke="${dark}" stroke-width="${f1(1.7*s)}"/>`+leaf(x-4*s,y-6*s,4.4*s,2*s,-20)+leaf(x+4*s,y-8*s,4.4*s,2*s,20);for(let a=0;a<10;a++)o+=`<ellipse cx="${f1(x+Math.cos(a*.628)*4.6*s)}" cy="${f1(y-16*s+Math.sin(a*.628)*4.6*s)}" rx="${f1(2.6*s)}" ry="${f1(1.2*s)}" fill="${Y>.45?'#f4c20d':fg}" stroke="#c9980a" stroke-width=".2" transform="rotate(${a*36} ${f1(x+Math.cos(a*.628)*4.6*s)} ${f1(y-16*s+Math.sin(a*.628)*4.6*s)})"/>`;o+=`<circle cx="${x}" cy="${f1(y-16*s)}" r="${f1(3.2*s)}" fill="url(#g-brown)"/>`;break;
    case'cotton':for(let a=0;a<5;a++)o+=leaf(x+Math.cos(a*1.26)*3.6*s,y-6*s+Math.sin(a*1.26)*2.6*s,4*s,2.2*s,a*72);if(bearing)for(let i=0;i<n;i++)o+=`<circle cx="${f1(x+(rng()-.5)*9*s)}" cy="${f1(y-(3+rng()*7)*s)}" r="${f1(1.9*s)}" fill="#fff" stroke="#cfd8df" stroke-width=".25"/>`;break;
    case'grain':{const ripe=Y>.5;for(let a=-3;a<=3;a++){const hx=x+a*1.9*s,top=y-(11+rng()*2.5)*s;o+=`<line x1="${f1(hx)}" y1="${y}" x2="${f1(hx+a*.5*s)}" y2="${f1(top)}" stroke="${ripe?'#b79a3c':dark}" stroke-width="${f1(.9*s)}"/>`;for(let g=0;g<4;g++)o+=`<ellipse cx="${f1(hx+a*.5*s+(g%2?1:-1)*.9*s)}" cy="${f1(top+g*1.6*s-2*s)}" rx="${f1(.9*s)}" ry="${f1(1.9*s)}" fill="${ripe?'url(#g-gold)':fg}" transform="rotate(${g%2?18:-18} ${f1(hx)} ${f1(top)})"/>`;o+=`<line x1="${f1(hx+a*.5*s)}" y1="${f1(top-1.5*s)}" x2="${f1(hx+a*.8*s)}" y2="${f1(top-5*s)}" stroke="${ripe?'#d9b04a':fg}" stroke-width="${f1(.4*s)}"/>`}break}
    case'blades':for(let a=-4;a<=4;a++)o+=`<path d="M${f1(x+a*1.1*s)} ${y} q${f1(a*.7*s)} ${f1(-5*s)} ${f1(a*1.7*s)} ${f1(-(8+rng()*3)*s)}" stroke="${fg}" stroke-width="${f1(1.2*s)}" fill="none" stroke-linecap="round"/>`;break;
    case'flower':for(let a=0;a<3;a++)o+=leaf(x+(a-1)*3*s,y-2*s,3*s,1.6*s,(a-1)*30);for(let i=0;i<3;i++)o+=`<circle cx="${f1(x+(i-1)*3.4*s)}" cy="${f1(y-(5+i%2*2)*s)}" r="${f1(1.9*s)}" fill="${['#f39c12','#9b59b6','#f4d03f'][(i+Math.floor(rng()*3))%3]}"/>`;break;
    case'tree':{const c=bearing?1:.45,th=8*s*c,cr=(bearing?11:5)*s;o+=`<path d="M${f1(x-1.8*s)} ${y} L${f1(x-1*s)} ${f1(y-th)} L${f1(x+1*s)} ${f1(y-th)} L${f1(x+1.8*s)} ${y}z" fill="url(#g-brown)"/>`;
      if(bearing){const cy=y-(8+7)*s;o+=`<ellipse cx="${x}" cy="${f1(cy+cr*.55)}" rx="${f1(cr*1.05)}" ry="${f1(cr*.45)}" fill="#0e2a0c" opacity=".35"/>`+[[-.55,.15],[.55,.15],[0,-.3],[-.3,.45],[.3,.45]].map(([dx,dy])=>`<circle cx="${f1(x+dx*cr)}" cy="${f1(cy+dy*cr)}" r="${f1(cr*.62)}" fill="${fg}" stroke="${dark}" stroke-width=".4"/>`).join('')+`<circle cx="${f1(x-cr*.3)}" cy="${f1(cy-cr*.35)}" r="${f1(cr*.32)}" fill="#fff" opacity=".13"/>`+(f?fruit(x,cy,cr*.9,n+2,f):'')}
      else o+=`<circle cx="${x}" cy="${f1(y-th-cr*.6)}" r="${f1(cr)}" fill="${fg}" stroke="${dark}" stroke-width=".4"/>`;break}
    case'palm':{const h=(bearing?16:6)*s;o+=`<path d="M${f1(x-1.6*s)} ${y} L${f1(x-1*s)} ${f1(y-h)} L${f1(x+1*s)} ${f1(y-h)} L${f1(x+1.6*s)} ${y}z" fill="#7a5a36"/>`+[-3,-1.5,0,1.5,3].map(a=>`<path d="M${x} ${f1(y-h)} q${f1(a*4*s)} ${f1(-8*s)} ${f1(a*8*s)} ${f1(-2*s)}" stroke="${fg}" stroke-width="${f1(1.7*s)}" fill="none" stroke-linecap="round"/>`).join('')+(bearing&&f?fruit(x,y-h+2*s,3*s,3,f):'');break}
    case'vine':o+=`<line x1="${f1(x-9*s)}" y1="${y}" x2="${f1(x-9*s)}" y2="${f1(y-11*s)}" stroke="#6b4a2a" stroke-width="${f1(1.2*s)}"/><line x1="${f1(x+9*s)}" y1="${y}" x2="${f1(x+9*s)}" y2="${f1(y-11*s)}" stroke="#6b4a2a" stroke-width="${f1(1.2*s)}"/><line x1="${f1(x-9*s)}" y1="${f1(y-10*s)}" x2="${f1(x+9*s)}" y2="${f1(y-10*s)}" stroke="#8a8a8a" stroke-width="${f1(.5*s)}"/>`+[-5,0,5].map(dx=>`<ellipse cx="${f1(x+dx*s)}" cy="${f1(y-8.5*s)}" rx="${f1(5*s)}" ry="${f1(3.8*s)}" fill="${fg}" stroke="${dark}" stroke-width=".4"/>`).join('')+(bearing&&f?[-4,1,5].map(dx=>fruit(x+dx*s,y-4*s,1.6*s,2,f)).join(''):'');break;
    default:o+=`<circle cx="${x}" cy="${f1(y-4*s)}" r="${f1(5*s)}" fill="${fg}"/>`}
  return o}

function fieldSVGDrawn(k,Sk,E,t){
  const r=E[k].first[t-1],row=r.rows[0],slot=r.slot,cr=slot.crop&&CROPS_G[slot.crop],W=360,H=262,u=k+'_'+t,rng=mulberry(k.charCodeAt(0)*977+t*131+(slot.crop||'x').length*17);
  const soilT=Sk?clamp(Sk.soil/100,0,1):.4,soilRGB=[214,178,124],soilDk=[74,44,21],soil=mixRGB(soilRGB,soilDk,soilT),soilFar=mixRGB(soilRGB,[236,228,208],.35+(1-soilT)*.15),subTop=mixRGB([196,160,110],[110,80,48],soilT*.6),subBot=mixRGB([160,126,84],[76,52,30],soilT*.6);
  const pidx=r.pidx,wet=pidx>1.3,dry=pidx<.75,skyC=wet?['#6f8191','#a3b2bf','#d3dbe2']:dry?['#e0a45a','#f1cf98','#f9ebcf']:['#5aa9e6','#a9d8f3','#e9f6fc'];
  const grassC=wet?['#86a86a','#5f8a48']:dry?['#cdb97e','#a79256']:['#a5cb80','#6f9d4c'];
  let g=`<defs><linearGradient id="sky-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${skyC[0]}"/><stop offset=".6" stop-color="${skyC[1]}"/><stop offset="1" stop-color="${skyC[2]}"/></linearGradient>
   <radialGradient id="sun-${u}"><stop offset="0" stop-color="${dry?'#ffb347':'#fff7c2'}" stop-opacity=".95"/><stop offset=".35" stop-color="${dry?'#ff9a2e':'#ffe27a'}" stop-opacity=".5"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
   <linearGradient id="gr-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${grassC[0]}"/><stop offset="1" stop-color="${grassC[1]}"/></linearGradient>
   <linearGradient id="soil-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${soilFar}"/><stop offset=".35" stop-color="${soil}"/><stop offset="1" stop-color="${mixRGB(soilRGB,soilDk,Math.min(1,soilT+.3))}"/></linearGradient>
   <linearGradient id="haze-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".5"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
   <linearGradient id="sub-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${subTop}"/><stop offset="1" stop-color="${subBot}"/></linearGradient>
   <linearGradient id="wetg-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a7fb5" stop-opacity="0"/><stop offset="1" stop-color="#2d6aa3" stop-opacity=".42"/></linearGradient>
   <filter id="blur-${u}"><feGaussianBlur stdDeviation="2.4"/></filter>
   <filter id="grain-${u}" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".85" numOctaves="2" seed="${(t*7+k.charCodeAt(0))%50}"/><feColorMatrix values="0 0 0 0 .12  0 0 0 0 .07  0 0 0 0 .03  0 0 0 .75 -.18"/><feComposite in2="SourceGraphic" operator="in"/></filter></defs>`;
  // sky, sun, clouds
  g+=`<rect width="${W}" height="84" fill="url(#sky-${u})"/>`;
  if(wet){for(const [cx,cy,rx,ry] of [[70,22,56,14],[150,34,60,14],[250,22,62,16],[320,36,46,12]])g+=`<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="#7c8d9c" filter="url(#blur-${u})" opacity=".9"/>`;for(let i=0;i<30;i++){const x=rng()*W,y=34+rng()*40;g+=`<line x1="${x.toFixed(0)}" y1="${y.toFixed(0)}" x2="${(x-3).toFixed(0)}" y2="${(y+10).toFixed(0)}" stroke="#4d6a85" stroke-width="1.2" opacity=".7"/>`}}
  else{const sx=W-52,sy=30;g+=`<circle cx="${sx}" cy="${sy}" r="${dry?42:34}" fill="url(#sun-${u})"/><circle cx="${sx}" cy="${sy}" r="${dry?15:11}" fill="${dry?'#ffcf7a':'#fffbe0'}"/>`;
    if(!dry)for(const [cx,cy,rx,ry,o] of [[80,24,34,9,.95],[104,28,28,8,.9],[62,29,24,7,.9],[190,18,26,6,.8]])g+=`<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="#fff" filter="url(#blur-${u})" opacity="${o}"/>`;
    else for(let i=0;i<5;i++)g+=`<path d="M${24+i*66} 70 q8 -7 16 0 t16 0" stroke="#d9822b" fill="none" opacity=".45"/>`}
  // hills, tree line, pasture
  g+=`<path d="M0 78 Q50 52 120 70 T250 60 T360 74 V90 H0Z" fill="${wet?'#7d9a8c':dry?'#c2b07c':'#8fb0a0'}" opacity=".75"/><path d="M0 82 Q70 62 150 76 T290 68 T360 80 V92 H0Z" fill="${wet?'#6c8d62':dry?'#b9a56a':'#78a456'}"/>`;
  for(let i=0;i<46;i++){const x=i*8+rng()*5,y=80+rng()*3;g+=`<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${(2+rng()*2.4).toFixed(1)}" fill="${wet?'#3f5f3a':dry?'#7d7040':'#44692f'}" opacity=".75"/>`}
  g+=`<rect x="0" y="82" width="${W}" height="104" fill="url(#gr-${u})"/>`;
  // field
  const FP='4,182 356,182 270,84 90,84';
  if(!cr||row.unmodeled){g+=`<polygon points="${FP}" fill="${soil}"/><polygon points="${FP}" fill="#000" filter="url(#grain-${u})"/><text x="${W/2}" y="140" text-anchor="middle" fill="#fff" font-size="15" stroke="#0006" stroke-width=".6">${cr?'Crop not modeled — no picture':'Fallow (bare soil)'}</text>`;
    return`<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="${cr?'Not modeled':'Fallow'}">${g}</svg>`}
  const Y=row.Y,bearing=!!(Y>0||!cr.bear),Yeff=bearing?Y:.55,type=GLYPH[cr.id]||'bush',[nR,nP,sz]=DENS[cr.cat]||DENS.veg;
  const bucket=Math.min(4,Math.floor(clamp(Yeff,0,1)*4.99)),fg=`url(#g-h${bucket})`,dark=OUTL[bucket];
  g+=`<polygon points="${FP}" fill="url(#soil-${u})"/><polygon points="${FP}" fill="${soil}" opacity=".55"/><polygon points="${FP}" fill="#000" filter="url(#grain-${u})" opacity=".55"/>`;
  const rowX=(i,d)=>{const tb=4+(i+.5)/nR*352,tt=90+(i+.5)/nR*180;return tt+(tb-tt)*d},yAt=d=>84+98*d;
  // furrows (dark) and ridge highlights, winter cover strips
  for(let i=0;i<=nR;i++){const p=i/nR,a=90+p*180,b=4+p*352;g+=`<polygon points="${(a-.7).toFixed(1)},84 ${(a+.7).toFixed(1)},84 ${(b+7).toFixed(1)},182 ${(b-7).toFixed(1)},182" fill="#000" opacity=".2"/>`;
    if(slot.cover)g+=`<polygon points="${(a-1.2).toFixed(1)},84 ${(a+1.2).toFixed(1)},84 ${(b+11).toFixed(1)},182 ${(b-11).toFixed(1)},182" fill="#5fae3f" opacity=".62"/><polygon points="${(a-.4).toFixed(1)},84 ${(a+.4).toFixed(1)},84 ${(b+3).toFixed(1)},182 ${(b-3).toFixed(1)},182" fill="#a8e07a" opacity=".5"/>`}
  for(let i=0;i<nR;i++){const p=(i+.5)/nR,a=90+p*180,b=4+p*352;g+=`<polygon points="${(a-.5).toFixed(1)},84 ${(a+.5).toFixed(1)},84 ${(b+6).toFixed(1)},182 ${(b-6).toFixed(1)},182" fill="#fff" opacity=".07"/>`}
  g+=`<polygon points="${FP}" fill="url(#haze-${u})" opacity=".55"/>`;
  // cracks, puddles, erosion streaks
  const nCr=Math.round((1-(row.wsF==null?1:row.wsF))*50);for(let c=0;c<nCr;c++){const d=rng(),x=rowX(Math.floor(rng()*nR),d),y=yAt(d),m=.4+d;g+=`<path d="M${x.toFixed(0)} ${y.toFixed(0)} l${(5*m).toFixed(1)} ${(-8*m).toFixed(1)} l${(-3*m).toFixed(1)} ${(-7*m).toFixed(1)} M${(x+2*m).toFixed(0)} ${(y-4*m).toFixed(0)} l${(6*m).toFixed(1)} ${(-2*m).toFixed(1)}" stroke="#241408" stroke-width="${(.6+m*.7).toFixed(1)}" fill="none" opacity=".62"/>`}
  if(wet)for(let c=0;c<3;c++){const d=.5+rng()*.5,cx=50+rng()*260;g+=`<ellipse cx="${cx.toFixed(0)}" cy="${yAt(d).toFixed(0)}" rx="${(10+d*16).toFixed(0)}" ry="${(2+d*3).toFixed(0)}" fill="#7db3dc" opacity=".6"/><ellipse cx="${(cx-4).toFixed(0)}" cy="${(yAt(d)-1).toFixed(0)}" rx="${(5+d*6).toFixed(0)}" ry="${(1+d).toFixed(0)}" fill="#fff" opacity=".35"/>`}
  if(Sk&&Sk.soil<45)for(let c=0;c<Math.round((45-Sk.soil)/5);c++){const x=20+rng()*320;g+=`<path d="M${x.toFixed(0)} 160 q6 12 -2 20 q-4 6 1 12" stroke="#6b3d17" stroke-width="3" fill="none" opacity=".5"/>`}
  // plants, far → near
  const miss=clamp((1-(row.pestF==null?1:row.pestF))*1.5+(1-Yeff)*.12,0,.5);
  for(let j=0;j<nP;j++){const d=Math.pow((j+.5)/nP,1.25),y=yAt(d),s=(.28+.8*d)*sz/7;
    for(let i=0;i<nR;i++){const x=rowX(i,d)+(rng()-.5)*6*s;
      if(rng()<miss){g+=`<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="${(3.4*s).toFixed(1)}" ry="${(1.6*s).toFixed(1)}" fill="#3b2412" opacity=".62"/><path d="M${(x-1.5*s).toFixed(1)} ${y.toFixed(1)} l${(1.5*s).toFixed(1)} ${(-2.4*s).toFixed(1)} l${(1.5*s).toFixed(1)} ${(2.4*s).toFixed(1)}" stroke="#7a5a2a" stroke-width=".6" fill="none"/>`;continue}
      const sc=s*(.55+.6*clamp(Yeff,0,1.1))*(.9+.2*rng());
      g+=glyph(type,cr.id,+x.toFixed(1),+y.toFixed(1),+sc.toFixed(2),fg,dark,Y||0,rng,bearing,sc<.42)}}
  g+=`<rect x="0" y="82" width="${W}" height="14" fill="url(#haze-${u})" opacity=".4"/>`;
  // soil cutaway
  const root=ROOTM[cr.cat]||1,wetv=row.wet!=null?row.wet:null,top=190,bot=H-6,hgt=bot-top;
  g+=`<rect x="4" y="${top}" width="352" height="${hgt}" rx="3" fill="url(#sub-${u})" stroke="#5a3d22" stroke-width="1.5"/><rect x="4" y="${top}" width="352" height="16" rx="3" fill="${soil}"/><rect x="4" y="${top}" width="352" height="16" rx="3" fill="#000" filter="url(#grain-${u})" opacity=".5"/>`;
  for(let i=0;i<40;i++)g+=`<circle cx="${(8+rng()*344).toFixed(0)}" cy="${(top+18+rng()*(hgt-20)).toFixed(0)}" r="${(.6+rng()*1.3).toFixed(1)}" fill="${rng()<.5?'#d9bf8c':'#4a3220'}" opacity=".45"/>`;
  if(wetv!=null)g+=`<rect x="4" y="${(bot-wetv*hgt).toFixed(1)}" width="352" height="${(wetv*hgt).toFixed(1)}" fill="url(#wetg-${u})"/>`;
  const rl=Math.min(hgt-6,root*hgt*.62*clamp(Yeff+.25,.4,1));for(let i=0;i<10;i++){const x=20+i*34+(rng()-.5)*10,dx=(rng()-.5)*16;g+=`<path d="M${x.toFixed(0)} ${top} q${(dx*.5).toFixed(0)} ${(rl*.5).toFixed(0)} ${dx.toFixed(0)} ${rl.toFixed(0)}" stroke="#f3e8cc" stroke-width="1.7" fill="none" opacity=".9" stroke-linecap="round"/><path d="M${(x+dx*.4).toFixed(0)} ${(top+rl*.4).toFixed(0)} l${(6+rng()*6).toFixed(0)} ${(5+rng()*5).toFixed(0)}" stroke="#f3e8cc" stroke-width=".8" fill="none" opacity=".7"/>`}
  g+=`<text x="10" y="${top+11}" font-size="9.5" fill="#fff" stroke="#0005" stroke-width=".4" paint-order="stroke">topsoil ${Sk?'· soil score '+Math.round(Sk.soil):''}</text><text x="${W-8}" y="${bot-4}" font-size="9.5" text-anchor="end" fill="#fff" stroke="#0006" stroke-width=".4" paint-order="stroke">${wetv!=null?'NASA soil wetness '+wetv.toFixed(2):'roots'}</text>`;
  return`<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Field picture for ${esc(cr.name)}, yield ${Y==null?'n/a':fmt(Y*100)+'%'}">${g}</svg>`}


/* ===== Photo version: a real photograph of the crop's field, with the model's outputs drawn on top =====
   Photo = what the crop/field looks like in general (Wikimedia Commons, free licenses). The model's results for THIS year are
   shown by: colour grading (stress), weather tint/rain, cracks, puddles, gaps, cover strips, erosion marks, badges and the soil cutaway. */
function fieldSVG(k,Sk,E,t){
  const r=E[k].first[t-1],row=r.rows[0],slot=r.slot,cr=slot.crop&&CROPS_G[slot.crop],ph=cr&&!row.unmodeled&&window.IMGS&&window.IMGS['f-'+cr.id];
  if(!ph)return fieldSVGDrawn(k,Sk,E,t);
  const Y=row.Y,bearing=!!(Y>0||!cr.bear),Yeff=bearing?Y:.55,pidx=r.pidx,wet=pidx>1.3,dry=pidx<.75,u=k+'_'+t,rng=mulberry(k.charCodeAt(0)*977+t*131+cr.id.length*17);
  const filt=`saturate(${clamp(.5+.6*Yeff,.45,1.15).toFixed(2)}) brightness(${clamp(.82+.22*Yeff,.8,1.05).toFixed(2)}) sepia(${clamp((.65-Yeff)*1.1,0,.6).toFixed(2)})`;
  const miss=clamp((1-(row.pestF==null?1:row.pestF))*1.5+(1-Yeff)*.12,0,.5),nCr=Math.round((1-(row.wsF==null?1:row.wsF))*46);
  let o=`<defs><filter id="bl-${u}"><feGaussianBlur stdDeviation="3.2"/></filter><linearGradient id="cv-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4f9a35" stop-opacity="0"/><stop offset="1" stop-color="#4f9a35" stop-opacity=".85"/></linearGradient></defs>`;
  if(wet){o+=`<rect width="360" height="200" fill="#5d7183" opacity=".3"/>`;for(let i=0;i<46;i++){const x=rng()*360,y=rng()*190;o+=`<line x1="${x.toFixed(0)}" y1="${y.toFixed(0)}" x2="${(x-4).toFixed(0)}" y2="${(y+12).toFixed(0)}" stroke="#dfe9f2" stroke-width="1" opacity=".55"/>`}}
  if(dry)o+=`<rect width="360" height="200" fill="#e59a3a" opacity=".24"/>`;
  if(miss>.03)for(let i=0;i<Math.round(miss*46);i++){const x=20+rng()*320,y=112+rng()*80;o+=`<ellipse cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" rx="${(6+rng()*10).toFixed(0)}" ry="${(3+rng()*4).toFixed(0)}" fill="#2e1c0c" opacity=".42" filter="url(#bl-${u})"/>`}
  if(slot.cover){o+=`<rect x="0" y="140" width="360" height="60" fill="url(#cv-${u})"/>`;for(let i=0;i<70;i++){const x=rng()*360,y=150+rng()*48;o+=`<path d="M${x.toFixed(0)} ${y.toFixed(0)} l${((rng()-.5)*4).toFixed(1)} ${(-7-rng()*6).toFixed(0)}" stroke="#7bc65a" stroke-width="1.4" opacity=".8"/>`}}
  for(let c=0;c<nCr;c++){const x=rng()*340,y=130+rng()*62,m=.6+rng();o+=`<path d="M${x.toFixed(0)} ${y.toFixed(0)} l${(7*m).toFixed(1)} ${(-9*m).toFixed(1)} l${(-4*m).toFixed(1)} ${(-8*m).toFixed(1)} M${(x+3*m).toFixed(0)} ${(y-5*m).toFixed(0)} l${(8*m).toFixed(1)} ${(-2*m).toFixed(1)}" stroke="#241408" stroke-width="1.5" fill="none" opacity=".7"/>`}
  if(wet)for(let c=0;c<3;c++){const x=40+rng()*280,y=165+rng()*26;o+=`<ellipse cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" rx="${(16+rng()*14).toFixed(0)}" ry="${(3+rng()*2).toFixed(0)}" fill="#8fbfe4" opacity=".65"/><ellipse cx="${(x-5).toFixed(0)}" cy="${(y-1).toFixed(0)}" rx="8" ry="1.4" fill="#fff" opacity=".5"/>`}
  if(Sk&&Sk.soil<45)for(let c=0;c<Math.round((45-Sk.soil)/6);c++){const x=15+rng()*330;o+=`<path d="M${x.toFixed(0)} 160 q7 12 -2 22 q-4 7 1 14" stroke="#6b3d17" stroke-width="3.2" fill="none" opacity=".6"/>`}
  const sw=window.IMGS['f-'+cr.id],tags=[];
  tags.push(wet?'<span class="fpt wet">Wet year</span>':dry?'<span class="fpt dry">Dry year</span>':'<span class="fpt">Typical rain</span>');
  if(row.wsF<.92)tags.push('<span class="fpt dry">Water short</span>');if(row.heatF<.93)tags.push('<span class="fpt dry">Heat stress</span>');if(row.frostF<.95)tags.push('<span class="fpt wet">Frost</span>');if(miss>.08)tags.push('<span class="fpt bad">Pest gaps</span>');if(slot.cover)tags.push('<span class="fpt ok">Winter cover</span>');
  const yp=Y==null?'–':Y===0?'not bearing':fmt(Y*100)+'%',ycol=Y==null?'#888':scol(Y*100);
  const author=(sw.artist||'').replace(/\s+/g,' ').slice(0,30);
  // soil cutaway (drawn: roots + NASA soil wetness)
  const soilT=Sk?clamp(Sk.soil/100,0,1):.4,soil=mixRGB([214,178,124],[74,44,21],soilT),subTop=mixRGB([196,160,110],[110,80,48],soilT*.6),subBot=mixRGB([160,126,84],[76,52,30],soilT*.6),root=ROOTM[cr.cat]||1,wetv=row.wet!=null?row.wet:null,W=360,H=84,top=2,hgt=H-top-2;
  let c=`<defs><linearGradient id="sb-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${subTop}"/><stop offset="1" stop-color="${subBot}"/></linearGradient><linearGradient id="wg-${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a7fb5" stop-opacity="0"/><stop offset="1" stop-color="#2d6aa3" stop-opacity=".45"/></linearGradient></defs><rect x="0" y="${top}" width="${W}" height="${hgt}" fill="url(#sb-${u})"/><rect x="0" y="${top}" width="${W}" height="14" fill="${soil}"/>`;
  for(let i=0;i<34;i++)c+=`<circle cx="${(4+rng()*352).toFixed(0)}" cy="${(top+16+rng()*(hgt-18)).toFixed(0)}" r="${(.6+rng()*1.2).toFixed(1)}" fill="${rng()<.5?'#d9bf8c':'#4a3220'}" opacity=".45"/>`;
  if(wetv!=null)c+=`<rect x="0" y="${(top+hgt-wetv*hgt).toFixed(1)}" width="${W}" height="${(wetv*hgt).toFixed(1)}" fill="url(#wg-${u})"/>`;
  const rl=Math.min(hgt-4,root*hgt*.75*clamp(Yeff+.25,.4,1));for(let i=0;i<10;i++){const x=18+i*35+(rng()-.5)*10,dx=(rng()-.5)*14;c+=`<path d="M${x.toFixed(0)} ${top} q${(dx*.5).toFixed(0)} ${(rl*.5).toFixed(0)} ${dx.toFixed(0)} ${rl.toFixed(0)}" stroke="#f3e8cc" stroke-width="1.5" fill="none" opacity=".9" stroke-linecap="round"/>`}
  c+=`<text x="8" y="${top+11}" font-size="9" fill="#fff" stroke="#0005" stroke-width=".4" paint-order="stroke">topsoil${Sk?' · soil score '+Math.round(Sk.soil):''}</text><text x="${W-8}" y="${H-5}" font-size="9" text-anchor="end" fill="#fff" stroke="#0006" stroke-width=".4" paint-order="stroke">${wetv!=null?'NASA soil wetness '+wetv.toFixed(2):'roots'}</text>`;
  return`<div class="fieldwrap"><div class="fieldpic"><img src="${sw.file}" alt="Photo of a ${esc(cr.name)} field" style="filter:${filt}"><svg class="fpov" viewBox="0 0 360 200" preserveAspectRatio="none" aria-hidden="true">${o}</svg>
   <div class="fpb tl">${cropIco(cr.id,22)} ${esc(cr.name)}</div><div class="fpb tr" style="--c:${ycol}">Yield <b>${yp}</b></div><div class="fpb bl">${tags.join('')}</div>
   <div class="fpcred" title="${esc(sw.title||'')} — ${esc(sw.artist||'')} (${esc(sw.license||'')})">Photo: ${esc(author)} · ${esc(sw.license||'')}</div></div>
   <svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Soil cutaway">${c}</svg></div>`}

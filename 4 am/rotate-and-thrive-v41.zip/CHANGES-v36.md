# Rotate & Thrive v36

A redesign of v35 with Hallmark (redesign, full depth, app scope) and the frontend-design guide. The white-and-green brand stays. No features, links, form fields, handlers or data changed.

## Look

- New type: Bricolage Grotesque for headings, Public Sans for body text.
- Palette: white paper, leaf-wash highlights (`#eef5ef`), canopy green actions (`#1e6b47`), deep canopy headings and footer (`#0f3d2a`). Current and Proposed keep amber and teal.
- New `redesign.css`, loaded after `game.css`. Every colour it uses is a token.
- Home: wider two-line headline, and a new "One field, eight seasons" ribbon: eight years of the planner's example rotation (tomato, garbanzo, wheat) drawn with the crop sprites.
- Header: solid white, the current page underlined in green.
- Planner: the five steps are a numbered rail. On phones only the current step is named on screen; the others keep their names for screen readers.
- Settings: "Fine-tune your field" and "Use your own numbers" are highlighted green panels, and their select menus have a green edge.

## Emoji

Every interface emoji is now a small pixel-art icon in the crop sprites' style. There are 25 new sprites in `pixelicons.js`, used through `pxe(name)`: drop, drops, rain, storm, sat, warn, stop, check, info, cycle, calendar, bulb, bug, basket, hourglass, cash, scale, thermo, mask, fire, snow, flask, sprout, scope and magnifier.

## Summary

The Summary shows one title. A combined title wins first (Field All-Rounder, Groundswell, Deep Roots, Rain or Shine, Lean & Green, Season Steady). Next comes the title for the chosen priority, then the title for the biggest gain. The four-title grid and the 12-title catalog are gone. The JSON export still includes every title result.

## Changed lines

| Before | After |
| --- | --- |
| `OVERALL` (score tables) | `Overall` |
| `Data & method — Rotate & Thrive` (page title) | `Data & method \| Rotate & Thrive` |
| "…how scores are computed — and what to treat with caution." | "…how scores are computed, and what to treat with caution." |

## Checks

- `tests.html`: 25/25 passed. `node --test tests/outcomes.test.cjs`: 13/13 passed.
- Hallmark sloplint across index, planner, data and the stylesheets: 2 FAIL, both kept on purpose. One is the en dash in the year range "2001–2025". The other is the NASA mission names "GRACE-FO, ECOSTRESS", which are written in capitals officially.

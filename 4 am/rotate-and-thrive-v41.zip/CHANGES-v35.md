# Rotate & Thrive v35

This version keeps the Home / Planner / Data & method structure and the same Place → Settings → Rotations → Simulation → Summary process.

## Changes

- Restyled the home page with the supplied farm photographs, a single clear primary action, shorter captions, quieter surfaces and fewer boxes.
- Added plain next-step guidance, visible field labels and mobile step names.
- Centered the Settings year slider and kept it responsive throughout dragging and keyboard changes.
- Added animated dropdowns with keyboard support, selected marks, disabled-option handling, outside dismissal and viewport-aware placement. All native select values and event handlers remain connected.
- Added restrained button, slider and disclosure feedback, plus reduced-motion/transparency and high-contrast support.
- Added 12 metric-based titles. Four earned titles appear upfront; the full catalog includes earning rules and evidence for earned titles. The JSON export includes the title results.
- Fixed the Summary score table for narrow screens.

## Title rules

All gains are Proposed minus Current, using median scores across the weather sequences. Points are score points, not percentages of measured farm savings. Thresholds are transparent product rules, not validated agronomic standards.

| Title | Rule |
| --- | --- |
| Rain Keeper | Water +5 points |
| Root Investor | Soil +5 points |
| Nutrient Keeper | Fertilizer +5 points |
| Cycle Breaker | Pests +5 points |
| Margin Maker | Income +5 points |
| Dry-Year Defender | Dry-year resilience +5 points |
| Deep Roots | Soil +10 and resilience +5 |
| Lean & Green | Water +5 and fertilizer +5 |
| Groundswell | Soil, fertilizer and pests each +5 |
| Rain or Shine | Water and resilience each +5; income no worse than −2 |
| Field All-Rounder | At least four scores +5; none worse than −5 |
| Season Steady | Median overall +5; Proposed wins at least 80% of paired sequences |

Same rotations and runs containing unmodeled crops earn no comparison titles. Missing/non-finite values cannot qualify. Illustrative weather is labeled. The summary still shows trade-offs and the existing model limitations.

## Copy changes

| Before | After |
| --- | --- |
| Plan a smarter crop rotation. (Home) | Your next rotation, before you plant. |
| Long NASA/weather/trade-off introduction | Compare crop sequences using your local NASA weather record. |
| Start planning | Plan my rotation |
| Three steps, about two minutes | From your field to a comparison. |
| Every rotation is run against the same resampled weather, so the comparison is fair. | Both rotations face the same weather. See what changes. |
| Pick your place | Find your field |
| Build two rotations | Choose what follows what |
| Watch it play out | Compare the seasons |
| Plan a smarter crop rotation. (Planner) | Start with the field you know. |
| Long planner introduction | Choose a place, build two rotations, then compare the seasons. |
| More settings | Fine-tune your field |
| Years | How many years ahead? |
| Priority | What matters most? |
| Improve my current rotation | Improve my rotation |
| Run simulation | Run comparison |
| Override assumptions | Use your own numbers |
| Plan the whole rotation now | Plan all years now |
| Generic priority-based outcome badge | A comparison statement plus independently earned metric titles |

Search placeholders now give examples. Navigation and export labels omit decorative arrows. Existing disclosures, limits and photo licenses remain. The hero credit is now a static link to the same photo source. The unsupported two-minute completion claim was removed.

## Verification

- Existing `tests.html`: **25/25 passed**, unchanged.
- New `node --test tests/outcomes.test.cjs`: **13/13 passed**. Covers each individual threshold, combined requirements, ties, missing values, identical and unmodeled rotations, consistency and determinism.
- Browser walkthrough: location search; settings and slider keyboard interaction; custom dropdown selection and Escape; full-plan run; summary; JSON export; live decisions and summary gating; reduced motion. No browser JavaScript errors.
- Desktop and phone screenshots inspected. At 375px the Summary table fits within x=33–342, and document width is 375px.
- Hallmark sweep of Home, Planner and shared CSS: **0 FAIL, 0 open REFLEX**. One spacing waiver covers 223 existing/optical spacing instances, preserving map geometry and compact planner controls. Nineteen nonblocking warnings were reviewed; see `.hallmark/review.md`.
- Fresh-context visual review: **ship** after fixing photo-grid overflow, mobile table clipping, and captures taken during disclosure animation.

The simulation engine, crop and weather datasets, maps, formulas and original functional tests were not changed. Vendor Leaflet CSS was only adapted to shared colour/font tokens and accessible styling; the vendor JavaScript is unchanged.

## Run

Open `index.html`, or serve this folder using the original command:

```sh
python -m http.server 8765
```

Open `http://localhost:8765`. The supplied app's external font, Tailwind and optional live-data dependencies remain. No build step or new runtime dependency is required.

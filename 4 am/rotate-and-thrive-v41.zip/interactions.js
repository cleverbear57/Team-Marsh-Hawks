'use strict';
/* Native select elements remain the source of truth and the no-script fallback. */
(function(){
  document.documentElement.classList.add('js');
  let active=null,serial=0,lastDisclosure=null;
  document.addEventListener('click',e=>{const summary=e.target.closest('summary');if(summary)lastDisclosure=summary.parentElement;},true);
  const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
  function close(focus=false){if(!active)return;const {button,panel}=active;button.setAttribute('aria-expanded','false');button.removeAttribute('aria-activedescendant');panel.remove();active=null;if(focus&&button.isConnected)button.focus({preventScroll:true});}
  function enhance(container){
    close();
    const heading=container.querySelector('h2');if(heading)heading.tabIndex=-1;
    container.querySelectorAll('select:not([multiple]):not([size])').forEach((select,index)=>{
      if(select.dataset.enhanced)return;
      const key=select.id||select.getAttribute('data-cv')||select.getAttribute('data-preset')||`select-${index}`;
      const label=select.getAttribute('aria-label')||Array.from(select.labels||[]).map(l=>l.textContent).join(' ')||'Choose an option';
      const wrapper=document.createElement('div');wrapper.className='select-control';
      select.before(wrapper);wrapper.append(select);select.dataset.enhanced='true';
      const button=document.createElement('button');button.type='button';button.className='select-trigger';button.dataset.selectKey=key;button.disabled=select.disabled;
      button.setAttribute('role','combobox');button.setAttribute('aria-label',label);button.setAttribute('aria-haspopup','listbox');button.setAttribute('aria-expanded','false');
      const value=document.createElement('span');value.textContent=select.selectedOptions[0]?.textContent||'Choose…';button.append(value);
      const caret=document.createElement('span');caret.className='select-chevron';caret.setAttribute('aria-hidden','true');button.append(caret);wrapper.append(button);
      select.tabIndex=-1;select.setAttribute('aria-hidden','true');
      select.labels?.forEach(l=>l.addEventListener('click',e=>{e.preventDefault();button.focus()}));
      const options=Array.from(select.options);
      function open(){
        if(active?.button===button){close();return;}close();
        const panel=document.createElement('div');panel.className='select-menu';panel.id=`select-menu-${++serial}`;panel.setAttribute('role','listbox');panel.setAttribute('aria-label',label);document.body.append(panel);
        button.setAttribute('aria-controls',panel.id);button.setAttribute('aria-expanded','true');
        let selected=Math.max(0,select.selectedIndex);
        const items=options.map((option,i)=>{const item=document.createElement('div');item.className='select-option';item.id=`${panel.id}-${i}`;item.setAttribute('role','option');item.setAttribute('aria-selected',String(option.selected));item.setAttribute('aria-disabled',String(option.disabled));item.textContent=option.textContent;item.addEventListener('pointerdown',e=>e.preventDefault());item.addEventListener('click',e=>{e.stopPropagation();choose(i)});panel.append(item);return item;});
        function highlight(i){selected=i;items.forEach((item,j)=>item.classList.toggle('is-highlighted',i===j));button.setAttribute('aria-activedescendant',items[i].id);items[i].scrollIntoView({block:'nearest'});}
        function choose(i){if(options[i].disabled)return;const changed=select.selectedIndex!==i;select.selectedIndex=i;value.textContent=options[i].textContent;close();if(changed){select.dispatchEvent(new Event('input',{bubbles:true}));if(select.isConnected)select.dispatchEvent(new Event('change',{bubbles:true}));}const replacement=Array.from(document.querySelectorAll('.select-trigger')).find(b=>b.dataset.selectKey===key);(replacement||button).focus({preventScroll:true});}
        const rect=button.getBoundingClientRect(),margin=12;
        panel.style.minWidth=Math.min(rect.width,innerWidth-margin*2)+'px';panel.style.maxWidth=(innerWidth-margin*2)+'px';
        const below=innerHeight-rect.bottom-margin,above=rect.top-margin,up=below<180&&above>below;
        panel.style.maxHeight=Math.min(320,Math.max(100,up?above-8:below-8))+'px';panel.style.left=Math.max(margin,Math.min(rect.left,innerWidth-panel.offsetWidth-margin))+'px';
        if(up){panel.style.bottom=(innerHeight-rect.top+8)+'px';panel.style.transformOrigin='bottom left';}else{panel.style.top=(rect.bottom+8)+'px';panel.style.transformOrigin='top left';}
        active={button,panel,highlight,choose,get index(){return selected},options};highlight(selected);
        if(!reduced())panel.animate([{opacity:0,transform:`translateY(${up?4:-4}px) scale(.985)`},{opacity:1,transform:'none'}],{duration:180,easing:'cubic-bezier(.16,1,.3,1)'});
      }
      button.addEventListener('click',e=>{e.stopPropagation();open()});
      let search='',lastKey=0;
      button.addEventListener('keydown',e=>{
        if(['ArrowDown','ArrowUp','Home','End','Enter',' ','Escape'].includes(e.key)){e.preventDefault();e.stopPropagation();}
        if(e.key==='Escape'){close(true);return;}if(e.key==='Tab'){close();return;}
        if(!active||active.button!==button){if(['ArrowDown','ArrowUp','Enter',' '].includes(e.key)){open();return;}else if(e.key.length!==1)return;else open();}
        if(!active)return;
        if(e.key==='Enter'||e.key===' '){active.choose(active.index);return;}
        const enabled=options.map((o,i)=>o.disabled?-1:i).filter(i=>i>=0);if(!enabled.length)return;
        if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){const at=enabled.indexOf(active.index);const next=e.key==='Home'?enabled[0]:e.key==='End'?enabled.at(-1):enabled[Math.max(0,Math.min(enabled.length-1,at+(e.key==='ArrowDown'?1:-1)))];active.highlight(next);}
        else if(e.key.length===1&&!e.ctrlKey&&!e.metaKey){e.preventDefault();search=Date.now()-lastKey>700?e.key:search+e.key;lastKey=Date.now();const match=enabled.find(i=>options[i].textContent.toLowerCase().startsWith(search.toLowerCase()));if(match!==undefined)active.highlight(match);}
      });
    });
    container.querySelectorAll('input[type=range]').forEach(input=>{const update=()=>{const fraction=(input.value-input.min)/(input.max-input.min);input.style.setProperty('--range-fill',(fraction*100)+'%')};update();input.addEventListener('input',update);});
  }
  document.addEventListener('pointerdown',e=>{if(active&&!active.panel.contains(e.target)&&!active.button.contains(e.target))close()});
  addEventListener('resize',()=>close());addEventListener('scroll',e=>{if(active&&e.target!==active.panel)close()},true);
  document.addEventListener('toggle',e=>{if(e.target instanceof HTMLDetailsElement&&e.target===lastDisclosure&&e.target.open&&!reduced()){const content=Array.from(e.target.children).filter(x=>x.tagName!=='SUMMARY');content.forEach(x=>x.animate([{opacity:.55,transform:'translateY(-3px)'},{opacity:1,transform:'none'}],{duration:180,easing:'ease-out'}));}},true);
  window.RTUI={enhance,close};
})();

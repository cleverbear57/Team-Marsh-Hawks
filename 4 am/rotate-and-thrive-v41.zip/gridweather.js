'use strict';
/* Cached NASA POWER weather for every U.S. state, one record per MERRA-2 grid cell (0.5° lat × 0.625° lon).
   NASA POWER returns the same values for every point inside a cell, so the cached cell is the same record a live
   request for the pin would return — it just works offline and inside sandboxes that block outside hosts.
   Files: data/usgrid/<state FIPS>.js, loaded on demand (built by tools/build_usgrid.py). Each also carries the
   daily-derived extras (extreme-rain, heat and frost days, topsoil wetness) that nasa.js would otherwise download.
   Load after gamecore.js and before game.js. */
window.USGRID=window.USGRID||{};
const _gridLoads={};
function loadGridState(fips){
  if(window.USGRID[fips])return Promise.resolve(window.USGRID[fips]);
  if(!_gridLoads[fips])_gridLoads[fips]=new Promise((ok,no)=>{const t=document.createElement('script');t.src='data/usgrid/'+fips+'.js?v=1';
    t.onload=()=>ok(window.USGRID[fips]||null);t.onerror=()=>{delete _gridLoads[fips];no(new Error('no cached grid for '+fips))};document.head.appendChild(t)});
  return _gridLoads[fips]}
/* nearest cached cell to (lat, lon); null if the state has none within maxKm */
function nearestGridCell(G,lat,lon,maxKm=80){let b=null,bd=1e9;
  for(const c of G.cells){const d=Math.hypot(c.lat-lat,(c.lon-lon)*Math.cos(lat*Math.PI/180))*111;if(d<bd){bd=d;b=c}}
  return b&&bd<=maxKm?{c:b,d:bd}:null}
async function gridRecord(fips,lat,lon){
  const G=await loadGridState(fips);if(!G)return null;const n=nearestGridCell(G,lat,lon);if(!n)return null;const c=n.c;
  const inCell=Math.abs(c.lat-lat)<=.25+1e-9&&Math.abs(c.lon-lon)<=.3125+1e-9;
  const rec=recordFromArrays({status:'available',
    source:inCell?`NASA POWER (cached for this spot's MERRA-2 grid cell, ${c.lat}°, ${c.lon}°)`:`NASA POWER (cached, nearest MERRA-2 grid cell ${c.lat}°, ${c.lon}°, ${Math.round(n.d)} km away)`,
    years:c.years,P:c.P,Tm:c.Tm,Tn:c.Tn,Tx:c.Tx,Tl:c.Tl,Sw:c.Sw,retrieved:G.retrieved,sha:c.sha256},lat);
  if(c.ext&&Object.keys(c.ext).length)rec.ext=c.ext;
  rec._extTried=true;   // extras already cached with the cell — nasa.js skips its live download
  return rec}

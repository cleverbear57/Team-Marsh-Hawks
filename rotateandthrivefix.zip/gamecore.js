'use strict';
/* California Rotation Lab — pure game/simulation core (no DOM). Educational model; see ASSUMPTIONS. */
const SOILG={'sandy loam':{awc:110,leach:1.25,om0:30},'loam':{awc:160,leach:1.0,om0:40},'clay loam':{awc:175,leach:.85,om0:48},'silty clay':{awc:165,leach:.75,om0:50}};
const ZONE_SOIL={sjv:'sandy loam',sac:'loam',coast:'clay loam',south:'loam',desert:'silty clay',north:'loam'};
const MD=[31,28,31,30,31,30,31,31,30,31,30,31],JM=[15,46,74,105,135,166,196,227,258,288,319,349];
const ET0_SCALE=.82,PLOT_AC=40,NPLOTS=1,START_CASH=250000; /* one representative 40-acre field */
const ASSUMPTIONS=[
 ['Climate input','NASA POWER monthly values (2001–2025): mean daily max/min temperature, extreme max/min, precipitation. MERRA-2 reanalysis grid cell (~50 km), not an on-farm station.'],
 ['Reference ET','Hargreaves–Samani (FAO-56 form) from monthly mean max/min temperature and latitude, multiplied by 0.82 because uncorrected Hargreaves overshoots CIMIS-type values in the Central Valley (an unverified rough calibration).'],
 ['Crop water demand','Σ over growing months of Kc × ET0 (Kc ramp for annuals: 45%, 80%, 100%…, 85%, 60% of mid-season Kc). Kc values are rough educational numbers, not local crop-coefficient tables.'],
 ['Water balance (per plot, seasonal)','Irrigation need = demand − 0.75×growing-season rain − stored winter water. Starting soil water = soil capacity (texture × root depth) × clamp((NASA MERRA-2 root-zone soil wetness in the crop’s first month − 0.2)/0.6, 0–1), +5% of capacity under a cover crop, − the cover crop’s water use. Wetness is a 0–1 degree of saturation from a land-surface model (not volumetric moisture); the 0.2–0.8 mapping to plant-available water is an assumption. Without wetness data it falls back to 0.5×Oct–Mar rain. Only in-season rain is added on top, so rain is not counted twice. Delivered water = pumped × efficiency. Farm-wide supply limit scales every plot equally when exceeded.'],
 ['Water stress','Yield factor = 1 − Ky × max(0, 1 − (rain + stored + delivered)/demand). Ky are rough educational values.'],
 ['Heat','Index from monthly MEAN daily max above a crop threshold (understates real heat waves). Factor = 1 − min(0.5, sensitivity × Σ°C-months above threshold / 60). Reanalysis monthly highs run warm in inland valleys, so the divisor is deliberately forgiving.'],
 ['Frost','Index from the monthly extreme minimum in frost-sensitive months; frost protection cuts it 70%.'],
 ['Nitrogen','Supply = fertilizer + 0.6 × soil-carbon-proxy + prior legume/cover credit (assumed 50% of nominal fixation — highly uncertain). Yield factor loses up to 45% at zero supply. Leaching index scales with surplus N, wet winters and soil texture.'],
 ['Soil carbon proxy','A 0–100 INDEX, not % organic matter. Change = residue/cover/compost inputs − decay (decay rises with the index and with tillage). No tonnes of carbon are claimed.'],
 ['Pests / disease','Pressure rises 0.25 per consecutive year of the same crop family and decays ×0.6 otherwise; up to 20% yield loss. Magnitudes are assumptions; the family-host idea comes from UC IPM-type guidance but no numbers are sourced.'],
 ['Bare periods','Calendar-based estimate: months without a crop growing or planted cover. Residue and weeds are not counted; NDVI is not used in the game.'],
 ['Economics','Reference revenue/cost per acre are rounded educational magnitudes (not current budgets). Price noise ±~12% seeded per crop-year, identical for all compared plans. Water cost $70/AF surface, $180/AF pumped.'],
 ['Financing','No loans or interest are modeled, so rotations are compared on field economics only (orchard establishment cost is charged in the planting year).'],
 ['Known under-estimate','Irrigation for stand establishment and frost/heat protection sprinklers on cool coastal vegetables is not modeled, so coastal water use is understated.'],
 ['Not modeled','Rice, salinity, drainage, disease outbreaks, markets/contracts, labor, insurance, cover-crop termination timing, groundwater table decline, SSURGO soil retrieval.']
];
/* ---------- weather ---------- */
function raMonth(lat,m){const phi=lat*Math.PI/180,J=JM[m],dr=1+.033*Math.cos(2*Math.PI*J/365),d=.409*Math.sin(2*Math.PI*J/365-1.39),ws=Math.acos(clamp(-Math.tan(phi)*Math.tan(d),-1,1));return 24*60/Math.PI*.082*dr*(ws*Math.sin(phi)*Math.sin(d)+Math.cos(phi)*Math.cos(d)*Math.sin(ws))}
function et0Month(lat,m,tm,tn){return Math.max(0,.0023*((tm+tn)/2+17.8)*Math.sqrt(Math.max(0,tm-tn))*raMonth(lat,m)*.408)*MD[m]}
function zoneOf(lat,lon){let b=null,bd=1e9;for(const k in ZONES){const z=ZONES[k];if(z.us)continue;const d=Math.hypot(z.lat-lat,(z.lon-lon)*.8);if(d<bd){bd=d;b=k}}return b}
function inCalifornia(lat,lon){let inside=false;const P=CA_OUTLINE;for(let i=0,j=P.length-1;i<P.length;j=i++){const[xi,yi]=P[i],[xj,yj]=P[j];if((yi>lat)!==(yj>lat)&&lon<(xj-xi)*(lat-yi)/(yj-yi)+xi)inside=!inside}return inside}
/* record: {status,source,years[],P,Tm,Tn,Tx,Tl,et0,note} */
function recordFromArrays(o,lat){const rec={...o};rec.et0=o.P.map((_,k)=>o.Tm[k].map((tm,m)=>ET0_SCALE*et0Month(lat,m,tm,o.Tn[k][m])));rec.n=o.years.length;rec.annualP=o.P.map(sum);rec.meanP=mean(rec.annualP);return rec}
function cachedRecord(id,lat){const w=window.WEATHER&&WEATHER[id];if(!w)return null;return recordFromArrays({status:'available',source:'NASA POWER (cached)',years:w.years,P:w.P,Tm:w.Tm,Tn:w.Tn,Tx:w.Tx,Tl:w.Tl,Sw:w.Sw,retrieved:(window.WEATHER_META||{}).retrieved,sha:w.sha256},lat)}
async function liveRecord(lat,lon){
  const url=`https://power.larc.nasa.gov/api/temporal/monthly/point?parameters=T2M,T2M_RANGE,T2M_MAX,T2M_MIN,PRECTOTCORR,GWETROOT&community=AG&longitude=${lon}&latitude=${lat}&start=2001&end=2025&format=JSON`;
  const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),20000);
  try{const r=await fetch(url,{signal:ctl.signal});if(!r.ok)throw new Error('HTTP '+r.status);const p=(await r.json()).properties.parameter,years=[],A={P:[],Tm:[],Tn:[],Tx:[],Tl:[],Sw:[]};
    for(let y=2001;y<=2025;y++){const ks=Array.from({length:12},(_,m)=>y+String(m+1).padStart(2,'0'));const g=n=>ks.map(k=>p[n][k]);const t2=g('T2M'),rg=g('T2M_RANGE'),tx=g('T2M_MAX'),tl=g('T2M_MIN'),pr=g('PRECTOTCORR'),sw=g('GWETROOT');
      if([...t2,...rg,...tx,...tl,...pr,...sw].some(v=>v==null||v<=-990))continue;A.Sw.push(sw.map(v=>+v.toFixed(3)));const leap=(y%4===0&&y%100!==0)||y%400===0;
      years.push(y);A.P.push(pr.map((v,m)=>+(v*(m===1&&leap?29:MD[m])).toFixed(1)));A.Tm.push(t2.map((v,m)=>+(v+rg[m]/2).toFixed(1)));A.Tn.push(t2.map((v,m)=>+(v-rg[m]/2).toFixed(1)));A.Tx.push(tx);A.Tl.push(tl)}
    if(years.length<10)throw new Error('too few complete years');
    return recordFromArrays({status:'available',source:'NASA POWER (live request)',years,...A,retrieved:new Date().toISOString().slice(0,10)},lat)}
  finally{clearTimeout(to)}}
/* Illustrative generated years — clearly NOT observations */
function syntheticRecord(zone,lat,seed){
  const t=ZONE_TYPICAL[zone]||REGIONS[ZONES[zone].typ],rng=mulberry(seed*7+3),years=[],A={P:[],Tm:[],Tn:[],Tx:[],Tl:[]};let z=randn(rng);
  for(let k=0;k<25;k++){z=.35*z+Math.sqrt(1-.1225)*randn(rng);const f=clamp(Math.exp(.4*z-.08),.25,2.2),dt=randn(rng)*.8;years.push(2001+k);
    A.P.push(t.precip.map(v=>+(v*f).toFixed(1)));A.Tm.push(t.tmax.map(v=>+(v+dt-.5*(f-1)).toFixed(1)));A.Tn.push(t.tmin.map(v=>+(v+dt*.6).toFixed(1)));A.Tx.push(t.tmax.map(v=>+(v+dt+6).toFixed(1)));A.Tl.push(t.tmin.map(v=>+(v+dt-4).toFixed(1)))}
  const r=recordFromArrays({status:'unavailable',source:'ILLUSTRATIVE generated years — not NASA observations',years,...A},lat);return r}
function sampleYears(rec,n,seed){const rng=mulberry(seed*104729+17),idx=[];while(idx.length<n){const len=2+Math.floor(rng()*3),st=Math.floor(rng()*rec.n);for(let k=0;k<len&&idx.length<n;k++)idx.push((st+k)%rec.n)}return idx}
function yearW(rec,i){return{Sw:rec.Sw?rec.Sw[i]:null,P:rec.P[i],Tm:rec.Tm[i],Tn:rec.Tn[i],Tx:rec.Tx[i],Tl:rec.Tl[i],et0:rec.et0[i],src:rec.years[i],annualP:rec.annualP[i]}}
function priceIdx(seed,yearIdx,cropId){let h=0;for(const c of cropId)h=(h*31+c.charCodeAt(0))%100003;const r=mulberry(seed*131+yearIdx*977+h);return clamp(1+.12*randn(r),.78,1.25)}
/* ---------- suitability ---------- */
function fitOf(cropId,zone){const c=CROPS_G[cropId];if(c.unmodeled)return'unmodeled';if(c.good.includes(zone))return'good';if(c.ok.includes(zone))return'ok';return'poor'}
const FIT_LABEL={good:'Good local fit',ok:'Possible / marginal',poor:'Poor local fit',unmodeled:'Not modeled'};
/* ---------- farm ---------- */
function newFarm(soilKey){const om0=SOILG[soilKey].om0;return{year:0,cash:START_CASH,equip:{},fert:'standard',irrig:'full',plots:Array.from({length:NPLOTS},()=>({crop:null,cover:null,age:0,om:om0,pest:{},lastFam:null,nCredit:0,justPlanted:false}))}}
const clone=o=>JSON.parse(JSON.stringify(o));
function coverConflict(cropId,coverId,zone){if(!coverId)return null;const c=cropId&&CROPS_G[cropId];if(!c)return null;if(c.id==='alfalfa'||c.cat==='native')return c.name+' already covers the soil.';if(c.perennial)return null;const m=c.zm[zone]||c.months;const ov=m.filter(x=>COVER_MONTHS.includes(x));return ov.length?`${c.name} is growing in ${ov.map(x=>MONTHS[x-1]).join(', ')} — a winter cover would overlap on the same field.`:null}
/* plan = {crops[],covers[],fert,irrig,buy[]}; mutates farm. returns messages */
function applyPlan(farm,plan,zone){
  const msgs=[];
  (plan.buy||[]).forEach(id=>{if(!farm.equip[id]&&EQUIP[id]){farm.equip[id]=1;farm.cash-=EQUIP[id].price;msgs.push(`Bought ${EQUIP[id].name} (−$${fmt(EQUIP[id].price)})`)}});
  farm.plots.forEach((p,i)=>{const nc=plan.crops[i]||null,old=p.crop;
    if(nc!==old){const oc=old&&CROPS_G[old];if(oc&&oc.perennial&&p.age>0){farm.cash-=1200*PLOT_AC;msgs.push(`Plot ${i+1}: removed ${oc.name} (−$${fmt(1200*PLOT_AC)})`)}p.crop=nc;p.age=0;p.justPlanted=!!nc}
    let cv=plan.covers[i]||null;const cf=coverConflict(p.crop,cv,zone);if(cf){msgs.push(`Plot ${i+1}: cover dropped — ${cf}`);cv=null}p.cover=cv});
  farm.fert=plan.fert||farm.fert;farm.irrig=plan.irrig||farm.irrig;return msgs}
function planOf(farm){return{crops:farm.plots.map(p=>p.crop),covers:farm.plots.map(p=>p.cover),fert:farm.fert,irrig:farm.irrig,buy:[]}}
/* ---------- one season ---------- */
function kcAt(cr,k,n){if(cr.perennial||n>=9||n<=2)return cr.kc;return cr.kc*(k===0?.45:k===1?.8:k===n-1?.6:k===n-2?.85:1)}
function playYear(farm,W,Wp,ctx){
  const eq=farm.equip,zone=ZONES[ctx.zone],soil=SOILG[ctx.soil],eff=clamp((eq.drip?.90:eq.sprinkler?.80:.72)+(eq.sensors?.04:0),.4,.95),
    mul={full:1,deficit:.8,drought:.6}[farm.irrig]||1;let fert=FERT[farm.fert]||FERT.standard;
  const pidx=W.annualP/ctx.meanP,avail=(1-zone.gw)*clamp(.35+.65*pidx,.2,1)+zone.gw,capAc=zone.alloc*(ctx.allocPct/100)*avail;
  const rows=[];let tot=0;
  farm.plots.forEach((pl,i)=>{const cr=pl.crop&&CROPS_G[pl.crop],r={i,crop:pl.crop,limits:[]};rows.push(r);
    if(!cr||cr.unmodeled){r.fallow=!cr;r.unmodeled=!!(cr&&cr.unmodeled);return}
    const ms=(cr.zm[ctx.zone]||cr.months).map(m=>m-1);r.ms=ms;let D=0;ms.forEach((m,k)=>D+=kcAt(cr,k,ms.length)*W.et0[m]);r.D=D;
    const Pg=sum(ms.map(m=>W.P[m]))*.75;let Pw=0;[9,10,11].forEach(m=>{if(!ms.includes(m))Pw+=Wp.P[m]});[0,1,2].forEach(m=>{if(!ms.includes(m))Pw+=W.P[m]});
    const cv=pl.cover&&COVERS[pl.cover],root=({veg:.6,field:1,forage:1.5,orchard:1.5,vine:1.5,native:1}[cr.cat]||1),awc=soil.awc/1000*root*1000*(1+.004*(pl.om-40));
    const spring=ms[0]>=2||cr.perennial;let store;
    if(W.Sw){const wet=W.Sw[cr.perennial?2:ms[0]];r.wet=wet;store=clamp(awc*clamp((wet-.2)/.6,0,1)+(cv?.05*awc:0)-(cv&&spring?cv.water:0),0,awc)}   /* start-of-season soil water from NASA/MERRA-2 root-zone wetness */
    else store=clamp((cv?.6:.5)*Pw-(cv&&spring?cv.water:0),0,awc);   /* fallback when no soil-wetness data: winter-rain estimate */
    r.Pg=Pg;r.store=store;r.Pw=Pw;
    r.need=Math.max(0,D-Pg-store);r.pullD=r.need/eff*mul;tot+=r.pullD});
  const scale=tot>0?Math.min(1,capAc*NPLOTS/tot):1;let farmRev=0,farmCost=0,waterMm=0,nMod=0,ySum=0,leachSum=0,bareSum=0,erSum=0,omSum=0,wsSum=0,nfSum=0,pestSum=0,refSum=0;const rain=sum(W.P);
  farm.plots.forEach((pl,i)=>{const r=rows[i],cr=pl.crop&&CROPS_G[pl.crop];
    if(!cr||cr.unmodeled){r.rev=0;r.cost=cr?0:50*PLOT_AC;r.net=-r.cost;r.Y=null;r.bare=12;r.er=1;r.leach=0;pl.om=clamp(pl.om-1.6*(pl.om/50),5,95);farmCost+=r.cost;bareSum+=12;erSum+=1;omSum+=pl.om;pl.age=0;pl.lastFam=null;return}
    const cv=pl.cover&&COVERS[pl.cover],ms=r.ms,pull=r.pullD*scale,deliv=pull*eff,ratio=Math.min(1.05,(r.Pg+r.store+deliv)/Math.max(1,r.D));
    const wsF=1-cr.ky*Math.max(0,1-ratio);let HX=0;ms.forEach(m=>HX+=Math.max(0,W.Tm[m]-cr.heatThr));const heatF=1-Math.min(.5,cr.heatSens*HX/100);
    const fms=(cr.zf&&cr.zf[ctx.zone])||cr.frostMonths;let fp=0;if(fms.length){fp=mean(fms.map(m=>Math.max(0,.5-W.Tl[m-1])/5));if(eq.frost)fp*=.3}const frostF=1-.5*cr.frostSens*Math.min(1,fp);
    const fLb=farm.fert==='compost'?40:(cr.nNeed>=60?Math.round(fert.frac*cr.nNeed):0),nSup=fLb+.6*pl.om+pl.nCredit,nF=cr.nNeed>0?1-.45*Math.max(0,1-nSup/cr.nNeed):1;
    const soilF=.92+.16*pl.om/100,pest=pl.pest[cr.fam]||0,pestF=1-.2*pest;const mat=cr.bear===0?1:(pl.age<cr.bear?0:pl.age===cr.bear?.5:1);
    const Y=wsF*heatF*frostF*nF*soilF*pestF*mat,price=ctx.price(cr.id),rev=cr.rev*Y*price*PLOT_AC;
    const fertCost=(farm.fert==='compost'?FERT.compost.costPerAc*(eq.compost?.5:1):(fLb>0?fLb*.9+15:0))*PLOT_AC,wCost=pull/304.8*(zone.gw*180+(1-zone.gw)*70)*PLOT_AC,
      cvCost=cv?cv.cost*(eq.notill?.6:1)*PLOT_AC:0,base=cr.cost*(pl.age<cr.bear?.6:1)*PLOT_AC,est=(pl.justPlanted?cr.est:0)*PLOT_AC,cost=base+est+fertCost+wCost+cvCost;
    Object.assign(r,{Y,rev,cost,net:rev-cost,deliv,pull,ratio,wsF,heatF,frostF,nF,pestF,mat,price,fertCost,wCost,cvCost,est,nSup,HX,fp});
    const lim=[['Water shortfall',1-wsF],['Heat',1-heatF],['Frost',1-frostF],['Nitrogen supply',1-nF],['Disease/pest build-up',1-pestF],['Young perennial (not yet bearing)',1-mat]].filter(x=>x[1]>.02).sort((a,b)=>b[1]-a[1]);r.limits=lim;
    const set=new Set(ms);if(cv)COVER_MONTHS.forEach(m=>set.add(m-1));let bare=cr.cat==='native'||cr.id==='alfalfa'||cr.id==='artichoke'?0:cr.perennial?(cv?6:12):12-set.size;if(cr.perennial&&cr.cat!=='native'&&cr.id!=='alfalfa'&&cr.id!=='artichoke'&&!cv)bare=12;
    const bareMs=[];for(let m=0;m<12;m++){const cov=(cr.cat==='native'||cr.id==='alfalfa'||cr.id==='artichoke')||(cr.perennial?false:set.has(m))||(cv&&COVER_MONTHS.includes(m+1));if(!cov)bareMs.push(m)}
    r.bare=bareMs.length;r.er=rain>0?sum(bareMs.map(m=>W.P[m]))/rain:0;
    r.leach=(Math.max(0,nSup-cr.nNeed)*.5+.08*nSup)*clamp(r.Pw/300,.2,1.8)*soil.leach*(1-(cv?cv.scav:0));
    const inp=cr.res*(cr.perennial&&pl.age<cr.bear?.6:1)*1.2+(cv?cv.om*1.2:0)+(farm.fert==='compost'?FERT.compost.om:0),dec=1.6*(pl.om/50)*(1+(cr.perennial||cr.cat==='native'?0:.4*(eq.notill?.4:1)));r.dOM=inp-dec;pl.om=clamp(pl.om+r.dOM,5,95);
    const fams=Object.keys(pl.pest);fams.forEach(f=>{pl.pest[f]*=f===cr.fam?1:.6});if(pl.lastFam===cr.fam)pl.pest[cr.fam]=Math.min(1,(pl.pest[cr.fam]||0)+.25);else pl.pest[cr.fam]=(pl.pest[cr.fam]||0)*.6;
    if(cv&&cv.fam==='Brassicaceae'&&cr.fam==='Brassicaceae')pl.pest.Brassicaceae=Math.min(1,(pl.pest.Brassicaceae||0)+.1);
    pl.nCredit=.5*(cr.nFix+(cv?cv.nFix:0));pl.lastFam=cr.fam;pl.age++;pl.justPlanted=false;
    wsSum+=wsF;nfSum+=nF;pestSum+=pest;refSum+=cr.rev*PLOT_AC;farmRev+=rev;farmCost+=cost;waterMm+=pull;nMod++;ySum+=Y;leachSum+=r.leach;bareSum+=r.bare;erSum+=r.er;omSum+=pl.om});
  const maint=sum(Object.keys(eq).map(k=>EQUIP[k].price*EQUIP[k].maint)),interest=0;farmCost+=maint;const net=farmRev-farmCost;farm.cash+=net;farm.year++;
  const waterAF=waterMm/304.8*PLOT_AC;
  return{wsF:nMod?wsSum/nMod:null,nF:nMod?nfSum/nMod:null,pest:nMod?pestSum/nMod:null,refRev:refSum,year:farm.year,rows,rev:farmRev,cost:farmCost,maint,interest,net,cash:farm.cash,waterAF,waterAFac:waterAF/(NPLOTS*PLOT_AC),yield:nMod?ySum/nMod:null,leach:nMod?leachSum/nMod:null,bare:(bareSum)/NPLOTS,erosion:erSum/NPLOTS,om:omSum/NPLOTS,scale,pidx,nModeled:nMod,nUnmodeled:rows.filter(r=>r.unmodeled).length,capAc}}
/* ---------- baseline policies (same weather & prices) ---------- */
function policyPlan(kind,farm,yearIdx,day1,zone){
  const plan=planOf(farm);plan.fert='standard';plan.irrig='full';
  if(kind==='A'){plan.crops=day1.crops.slice();plan.covers=day1.crops.map(()=>null);return plan}
  if(kind==='B'){plan.crops=day1.crops.slice();plan.covers=day1.crops.map(c=>{if(!c)return null;const cr=CROPS_G[c];if(cr.unmodeled||cr.cat==='native'||c==='alfalfa')return null;const want=cr.perennial?'clover':(cr.fam==='Fabaceae'?'rye':'vetch');return coverConflict(c,want,zone)?null:want});return plan}
  plan.crops=day1.crops.map(c=>{if(!c)return null;const cr=CROPS_G[c];if(cr.perennial||cr.unmodeled)return c;const alt=['garbanzo','wheat','safflower'].filter(x=>x!==c&&fitOf(x,zone)!=='poor'&&CROPS_G[x].fam!==cr.fam);const seq=[c,alt[0]||'wheat',alt[1]||alt[0]||'wheat'];return seq[yearIdx%3]});
  plan.covers=plan.crops.map(c=>{if(!c)return null;const cr=CROPS_G[c];if(cr.unmodeled||cr.cat==='native'||c==='alfalfa')return null;const want=cr.perennial?'nativemix':'rye';return coverConflict(c,want,zone)?null:want});return plan}
/* analog-year outlook: apply this plan to current state across every historical year (neutral prices) */
function outlook(farm,plan,ctx,rec){const res=[];for(let k=0;k<rec.n;k++){const f=clone(farm);applyPlan(f,plan,ctx.zone);const c2={...ctx,price:()=>1};const rep=playYear(f,yearW(rec,k),yearW(rec,Math.max(0,k-1)),c2);res.push({y:rec.years[k],net:rep.net,water:rep.waterAFac,yield:rep.yield,om:rep.om})}
  const q=(a,p)=>{const s=a.slice().sort((x,y)=>x-y);return s[Math.min(s.length-1,Math.max(0,Math.round(p*(s.length-1))))]};
  const st=k=>{const a=res.map(r=>r[k]).filter(v=>v!=null);return a.length?{min:Math.min(...a),p10:q(a,.1),med:q(a,.5),p90:q(a,.9),max:Math.max(...a)}:null};return{n:res.length,net:st('net'),water:st('water'),yield:st('yield'),res}}
/* ---------- run ---------- */
function makeCtx(setup,rec){return{zone:setup.zone,soil:setup.soil,allocPct:setup.allocPct,meanP:rec.meanP,price:()=>1}}
function startRun(setup,rec,day1){
  const idx=sampleYears(rec,setup.horizon,setup.seed),farm=newFarm(setup.soil);applyPlan(farm,day1,setup.zone);
  const run={setup,idx,srcYears:idx.map(i=>rec.years[i]),farm,shadow:{},plans:[clone(day1)],reports:[],sreports:{A:[],B:[],C:[]},day1:clone(day1),done:0};
  for(const k of['A','B','C'])run.shadow[k]=clone(farm);return run}
function stepRun(run,rec,plan){
  const j=run.done,i=run.idx[j],W=yearW(rec,i),Wp=yearW(rec,Math.max(0,i-1)),s=run.setup,msgs=[];
  const mc=k=>({...makeCtx(s,rec),price:id=>priceIdx(s.seed,j,id)});
  if(j>0||plan){const m=applyPlan(run.farm,plan,s.zone);msgs.push(...m);run.plans[j]=clone(plan)}
  const rep=playYear(run.farm,W,Wp,mc());rep.msgs=msgs;rep.W=W;rep.srcYear=rec.years[i];rep.idx=j;
  for(const k of['A','B','C']){const f=run.shadow[k];if(j>0||true){const pp=policyPlan(k,f,j,run.day1,s.zone);applyPlan(f,pp,s.zone)}run.sreports[k].push(playYear(f,W,Wp,mc()))}
  run.reports.push(rep);run.done++;return rep}
/* ---------- results ---------- */
function summarize(rs){return{net:sum(rs.map(r=>r.net)),water:mean(rs.map(r=>r.waterAFac)),yield:mean(rs.filter(r=>r.yield!=null).map(r=>r.yield)),om:rs.length?rs[rs.length-1].om:null,bare:mean(rs.map(r=>r.bare)),erosion:mean(rs.map(r=>r.erosion)),leach:mean(rs.filter(r=>r.leach!=null).map(r=>r.leach)),cash:rs.length?rs[rs.length-1].cash:null}}
function judge(run,rec,ctx){
  const n=run.done;if(n===0)return{cat:'None',text:'No simulated outcome yet.'};
  const you=summarize(run.reports),A=summarize(run.sreports.A),pr=run.setup.priority,early=n<3||n<run.setup.horizon;
  const om0=SOILG[run.setup.soil].om0,dOM=you.om-A.om,wr=A.water>0?you.water/A.water:1,yr=A.yield>0?you.yield/A.yield:1,nr=you.net-A.net;
  const unm=run.reports[n-1].nUnmodeled/NPLOTS;
  let cat='Mixed Tradeoffs',why='';const pre=early?'Early indicator: ':'';
  if(unm>.25||n<1)return{cat:'Insufficient Evidence',text:`${pre}more than a quarter of plots use an unmodeled crop, so key outputs are unavailable.`,you,A};
  if(pr==='soil'){if(dOM>=3&&yr>=.9&&you.erosion<=A.erosion+.02){cat='Soil Builder';why=`soil-carbon proxy ${sgn(dOM,1)} vs Plan A (≥ +3 required), yield ${fmt(yr*100)}% of A (≥ 90%), erosion index not worse.`}else why=`soil-carbon proxy ${sgn(dOM,1)} vs Plan A, yield ${fmt(yr*100)}% of A, erosion ${sgn(you.erosion-A.erosion,2)}. Thresholds for Soil Builder: proxy ≥ +3, yield ≥ 90%, erosion not worse.`}
  if(pr==='water'){if(wr<=.9&&yr>=.9){cat='Water Saver';why=`pumped/applied water ${fmt(wr*100)}% of A (≤ 90% required) with yield ${fmt(yr*100)}% of A (≥ 90%).`}else why=`water use ${fmt(wr*100)}% of A, yield ${fmt(yr*100)}% of A. Water Saver needs ≤ 90% water with ≥ 90% yield (a failed crop that uses less water does not count).`}
  if(pr==='output'){const fy=outlook(run.farm,planOf(run.farm),ctx,rec),fa=outlook(run.shadow.A,planOf(run.shadow.A),ctx,rec);const robust=fy.net&&fa.net&&fy.net.p10>=fa.net.p10;
    if(nr>=0&&robust&&n>=3){cat='Harvest Resilience';why=`net ${usd(nr)} vs Plan A and your current plan's low-end (10th-percentile) analog-year net ${usd(fy.net.p10)} ≥ Plan A's ${usd(fa.net.p10)}.`}else why=`net ${usd(nr)} vs A; low-end analog-year net ${fy.net?usd(fy.net.p10):'n/a'} vs A's ${fa.net?usd(fa.net.p10):'n/a'}. Needs net ≥ A, a stronger low-end than A, and ≥ 3 simulated years.`}
  if(cat==='Mixed Tradeoffs'&&Math.abs(dOM)<1&&Math.abs(wr-1)<.05&&Math.abs(nr)<1000)cat='Insufficient Evidence',why='your plan is almost identical to Plan A, so differences are within model noise. '+why;
  return{cat,text:pre+why,you,A,dOM,wr,yr,nr,early}}

/* ---------- 0–100 scorecard (transparent; every formula is shown on the page) ---------- */
const SCORE_CATS=[['water','💧','Water','Half "crops not water-stressed", half "water thrift" (less used than the region\'s typical allocation).'],
 ['soil','🌱','Soil','45% soil-carbon proxy (60+ = 100) + 55% ground protection (fewer bare months and less rain falling on bare ground).'],
 ['n','🧪','Fertilizer','60% low nitrate-loss index + 40% how well crops got the nitrogen they needed.'],
 ['pest','🐛','Pests','100 minus disease/pest build-up pressure (rises when the same crop family repeats).'],
 ['income','💰','Income','Net income ÷ potential revenue: 50 = break-even, 100 = 20% margin or better, 0 = losing 20% or more.'],
 ['resil','🛡️','Dry-year resilience','Average yield (% of reference) in the driest third of the years of the weather sequence — how well the rotation holds up when rain is short.']];
function scoreOf(rep,zoneKey){
  if(!rep||!rep.nModeled)return null;const alloc=ZONES[zoneKey].alloc/304.8;
  return{water:.5*rep.wsF*100+.5*100*clamp(1-rep.waterAFac/alloc,0,1),
    soil:.45*clamp(rep.om/60*100,0,100)+.55*100*clamp(1-.5*rep.erosion-.5*rep.bare/12,0,1),
    n:.6*100*clamp(1-rep.leach/30,0,1)+.4*100*rep.nF,
    pest:100*clamp(1-rep.pest,0,1),
    income:clamp(50+(rep.net/Math.max(1,rep.refRev))*250,0,100)}}
function weightsFor(priority){const key={soil:'soil',water:'water',output:'income',resil:'resil'}[priority]||'soil',w={};SCORE_CATS.forEach(([k])=>w[k]=k===key?.4:.12);return w}
function overallOf(sc,priority){if(!sc)return null;const w=weightsFor(priority);let t=0,ws=0;SCORE_CATS.forEach(([k])=>{if(sc[k]!=null){t+=sc[k]*w[k];ws+=w[k]}});return ws?t/ws:null}
function avgScores(reports,zoneKey){const L=reports.map(r=>scoreOf(r,zoneKey)).filter(Boolean);if(!L.length)return null;const o={};['water','soil','n','pest','income'].forEach(k=>o[k]=mean(L.map(s=>s[k])));
  const ys=reports.filter(r=>r.yield!=null).sort((a,b)=>a.pidx-b.pidx),dry=ys.slice(0,Math.max(1,Math.ceil(ys.length/3)));o.resil=dry.length?clamp(100*mean(dry.map(r=>r.yield)),0,100):null;return o}
/* preview: median score across all historical analog years for a plan (neutral prices) */
function previewScores(farm,plan,ctx,rec){const L=[];for(let k=0;k<rec.n;k++){const f=clone(farm);applyPlan(f,plan,ctx.zone);const rep=playYear(f,yearW(rec,k),yearW(rec,Math.max(0,k-1)),{...ctx,price:()=>1});const s=scoreOf(rep,ctx.zone);if(s)L.push(s)}
  if(!L.length)return null;const med=a=>{const s=a.slice().sort((x,y)=>x-y);return s[Math.floor((s.length-1)/2)]},o={};SCORE_CATS.forEach(([k])=>o[k]=med(L.map(s=>s[k])));return o}

/* ================= ROTATION MODE (one 40-acre field, rotation of any length) ================= */
/* A rotation is an array of slots [{crop, cover}] — slot j % length is planted in simulation year j. */
const DEFAULT_CROP={sjv:'tomato',sac:'tomato',coast:'lettuce',south:'broccoli',desert:'alfalfa',north:'wheat'};
const ROT_PRESETS={
 mono:['One crop every year (monoculture)',z=>[{crop:DEFAULT_CROP[z],cover:null}]],
 tgw:['Tomato → wheat → garbanzo (3 yr)',z=>[{crop:'tomato',cover:null},{crop:'wheat',cover:null},{crop:'garbanzo',cover:null}]],
 tgwc:['Tomato → wheat → garbanzo + winter covers',z=>[{crop:'tomato',cover:'vetch'},{crop:'wheat',cover:null},{crop:'garbanzo',cover:'rye'}]],
 cotwheat:['Cotton → wheat (2 yr)',z=>[{crop:'cotton',cover:null},{crop:'wheat',cover:null}]],
 veg:['Lettuce → broccoli → spinach',z=>[{crop:'lettuce',cover:null},{crop:'broccoli',cover:'rye'},{crop:'spinach',cover:null}]],
 alf:['Alfalfa ×4 → wheat → safflower (6 yr)',z=>[...Array(4).fill({crop:'alfalfa',cover:null}),{crop:'wheat',cover:null},{crop:'safflower',cover:null}]],
 orch:['Almonds (stand kept all years)',z=>[{crop:'almond',cover:null}]]
};
function rotationFacts(rot,zone){
  const L=rot.length,crops=rot.map(s=>s.crop?CROPS_G[s.crop]:null),fams={};crops.forEach((c,i)=>{if(c){(fams[c.fam]=fams[c.fam]||[]).push(i)}});
  let minGap=null,worst=null;for(const f in fams){const p=fams[f];let g=L;if(p.length>1){g=Infinity;for(let k=0;k<p.length;k++)g=Math.min(g,(p[(k+1)%p.length]-p[k]+L)%L||L)}else g=L;if(minGap==null||g<minGap){minGap=g;worst=f}}
  return{len:L,families:Object.keys(fams).length,legumes:crops.filter(c=>c&&c.nFix>0).length,covers:rot.filter(s=>s.cover).length,minGap,worst,perennial:crops.filter(c=>c&&c.perennial).length,unmodeled:crops.filter(c=>c&&c.unmodeled).length}}
function suggestRotation(cur,zone){
  const crops=cur.map(s=>s.crop).filter(Boolean);if(!crops.length)return[];
  const pick=(ids)=>ids.map(id=>({id,f:FITORD2[fitOf(id,zone)]})).sort((a,b)=>a.f-b.f)[0].id;
  let seq=cur.map(s=>({crop:s.crop,cover:null}));const has=f=>seq.some(s=>CROPS_G[s.crop].fam===f);
  const allPer=seq.every(s=>CROPS_G[s.crop].perennial);
  if(!allPer){
    if(!seq.some(s=>CROPS_G[s.crop].nFix>0&&!CROPS_G[s.crop].perennial))seq.push({crop:pick(['garbanzo','drybean','soybean','peanut'].filter(id=>CROPS_G[id])),cover:null});
    if(seq.length<6&&!seq.some(s=>['wheat','sorghum'].includes(s.crop)))seq.push({crop:pick(['wheat','safflower']),cover:null});
    if(seq.length<3){const extra=['wheat','safflower','garbanzo'].find(c=>!seq.some(s=>s.crop===c));if(extra)seq.push({crop:extra,cover:null})}
    // avoid same-family back-to-back where adjacent
    for(let i=0;i<seq.length-1;i++){if(CROPS_G[seq[i].crop].fam===CROPS_G[seq[i+1].crop].fam&&seq.length>2){const t=seq[i+1];seq.splice(i+1,1);seq.push(t)}}}
  seq=seq.map(s=>{const cr=CROPS_G[s.crop];if(cr.unmodeled||cr.cat==='native'||s.crop==='alfalfa')return s;const want=cr.perennial?'clover':(cr.fam==='Fabaceae'||cr.fam==='Brassicaceae'?'rye':'vetch');return{crop:s.crop,cover:coverConflict(s.crop,want,zone)?null:want}});
  return seq}
const FITORD2={good:0,ok:1,poor:2,unmodeled:3};
function runRotation(rot,setup,rec,idx,seed,mg){
  const farm=newFarm(setup.soil);farm.fert=mg.fert;farm.irrig=mg.irrig;(mg.equip||[]).forEach(id=>{farm.equip[id]=1;farm.cash-=EQUIP[id].price});
  const reports=[];if(!rot.length)return reports;
  for(let j=0;j<idx.length;j++){const slot=rot[j%rot.length],i=idx[j];applyPlan(farm,{crops:[slot.crop],covers:[slot.cover],fert:mg.fert,irrig:mg.irrig,buy:[]},setup.zone);
    const rep=playYear(farm,yearW(rec,i),yearW(rec,Math.max(0,i-1)),{zone:setup.zone,soil:setup.soil,allocPct:setup.allocPct,meanP:rec.meanP,price:id=>priceIdx(seed,j,id)});rep.srcYear=rec.years[i];rep.slot=slot;rep.idx=j;reports.push(rep)}
  return reports}
const qtile=(a,p)=>{const s=a.filter(v=>v!=null&&!isNaN(v)).sort((x,y)=>x-y);return s.length?s[Math.min(s.length-1,Math.max(0,Math.round(p*(s.length-1))))]:null};
/* Run each rotation over N seeded resamplings of the historical weather. All rotations share every sequence. */
function ensembleRotations(rots,setup,rec,mg,N){
  const out={};for(const k in rots)out[k]={sc:[],ov:[],sum:[],first:null};
  for(let s=0;s<N;s++){const seed=setup.seed+s,idx=sampleYears(rec,setup.horizon,seed);
    for(const k in rots){const reps=runRotation(rots[k],setup,rec,idx,seed,mg),sc=avgScores(reps,setup.zone);out[k].sc.push(sc);out[k].ov.push(sc?overallOf(sc,setup.priority):null);const sm=summarize(reps);sm.netPerAc=sm.net/PLOT_AC/setup.horizon;out[k].sum.push(sm);if(s===0){out[k].first=reps;out[k].idx=idx}}}
  const res={};for(const k in rots){const o=out[k],r={first:o.first,idx:o.idx,cat:{}};
    SCORE_CATS.forEach(([c])=>{const v=o.sc.map(x=>x?x[c]:null);r.cat[c]={med:qtile(v,.5),lo:qtile(v,.1),hi:qtile(v,.9)}});
    r.ov={med:qtile(o.ov,.5),lo:qtile(o.ov,.1),hi:qtile(o.ov,.9),all:o.ov};
    r.num={};['netPerAc','water','om','yield','bare','erosion'].forEach(m=>r.num[m]={med:qtile(o.sum.map(x=>x[m]),.5),lo:qtile(o.sum.map(x=>x[m]),.1),hi:qtile(o.sum.map(x=>x[m]),.9)});res[k]=r}
  return res}

/* ================= DATA-DRIVEN ROTATION SEARCH ================= */
function autoCover(crop,zone){const cr=CROPS_G[crop];if(!cr||cr.unmodeled||cr.cat==='native'||crop==='alfalfa')return null;const want=cr.perennial?'clover':(cr.fam==='Fabaceae'||cr.fam==='Brassicaceae'?'rye':'vetch');return coverConflict(crop,want,zone)?null:want}
function evalRot(rot,setup,rec,mg,seeds){
  const ov=[],cat={};SCORE_CATS.forEach(([c])=>cat[c]=[]);
  for(const s of seeds){const sc=avgScores(runRotation(rot,setup,rec,s.idx,s.seed,mg),setup.zone);if(!sc)return null;ov.push(overallOf(sc,setup.priority));SCORE_CATS.forEach(([c])=>cat[c].push(sc[c]))}
  const o={ov:qtile(ov,.5),cat:{}};SCORE_CATS.forEach(([c])=>o.cat[c]=qtile(cat[c],.5));return o}
const mkSeeds=(setup,rec,n,off)=>Array.from({length:n},(_,s)=>{const seed=setup.seed+off+s;return{seed,idx:sampleYears(rec,setup.horizon,seed)}});
/* Tries many rotations built from crops that fit this location, scores each on this location's NASA weather
   (resampled), keeps those whose income is not clearly worse than the current rotation, returns the best few. */
function searchRotations(cur,setup,rec,mg){
  const zone=setup.zone,H=setup.horizon,t0=Date.now(),fast=mkSeeds(setup,rec,4,5000),final=mkSeeds(setup,rec,12,7000);
  const curFast=evalRot(cur,setup,rec,mg,fast),curFinal=evalRot(cur,setup,rec,mg,final);
  if(!curFinal)return{list:[],tested:0,ms:0};
  const curInc=curFast.cat.income,ok=e=>e&&e.cat.income>=curInc-10;
  let cands=[],tested=0;
  const curCrops=cur.map(s=>s.crop).filter(Boolean),allPer=curCrops.length&&curCrops.every(c=>CROPS_G[c].perennial&&c!=='alfalfa');
  if(allPer){const c=curCrops[0];for(const cv of [null,...Object.keys(COVERS)]){if(cv&&coverConflict(c,cv,zone))continue;cands.push([{crop:c,cover:cv}])}}
  else{
    const all=Object.values(CROPS_G).filter(c=>!c.unmodeled&&!c.perennial&&c.cat!=='native'&&fitOf(c.id,zone)!=='poor');
    const scored=all.map(c=>({c,e:evalRot([{crop:c.id,cover:autoCover(c.id,zone)}],setup,rec,mg,fast.slice(0,3))})).filter(x=>x.e).sort((a,b)=>b.e.ov-a.e.ov);
    const pool=scored.slice(0,7).map(x=>x.c.id);
    const add=id=>{if(id&&!pool.includes(id)&&CROPS_G[id]&&!CROPS_G[id].unmodeled&&(!CROPS_G[id].perennial||id==='alfalfa'))pool.push(id)};
    [scored.find(x=>x.c.nFix>0),scored.find(x=>['wheat','safflower','sorghum'].includes(x.c.id))].forEach(x=>x&&add(x.c.id));curCrops.forEach(add);
    const fam=id=>CROPS_G[id].fam,perms=(a)=>a.length<=1?[a]:a.flatMap((x,i)=>perms([...a.slice(0,i),...a.slice(i+1)]).map(p=>[x,...p]));
    const combos=(arr,k,s=0,acc=[],out=[])=>{if(acc.length===k){out.push(acc.slice());return out}for(let i=s;i<arr.length;i++){acc.push(arr[i]);combos(arr,k,i+1,acc,out);acc.pop()}return out};
    for(let L=2;L<=Math.min(4,H,pool.length);L++)for(const cb of combos(pool,L)){for(const rest of perms(cb.slice(1))){const seq=[cb[0],...rest];if(seq.some((x,i)=>fam(x)===fam(seq[(i+1)%L])))continue;
      cands.push(seq.map(c=>({crop:c,cover:null})));cands.push(seq.map(c=>({crop:c,cover:autoCover(c,zone)})))}}}
  const seen=new Set(),uniq=[];for(const c of cands){const key=JSON.stringify(c);if(!seen.has(key)){seen.add(key);uniq.push(c)}}
  let scoredC=[];for(const rot of uniq){tested++;const e=evalRot(rot,setup,rec,mg,fast);if(e&&ok(e))scoredC.push({rot,ov:e.ov})}
  if(!scoredC.length){for(const rot of uniq){const e=evalRot(rot,setup,rec,mg,fast);if(e)scoredC.push({rot,ov:e.ov})}}
  scoredC.sort((a,b)=>b.ov-a.ov);
  const top=scoredC.slice(0,6).map(x=>({rot:x.rot,e:evalRot(x.rot,setup,rec,mg,final)})).filter(x=>x.e).sort((a,b)=>b.e.ov-a.e.ov).slice(0,3)
    .map(x=>({rot:x.rot,ov:x.e.ov,cat:x.e.cat,vs:Object.fromEntries(SCORE_CATS.map(([c])=>[c,x.e.cat[c]==null||curFinal.cat[c]==null?null:x.e.cat[c]-curFinal.cat[c]]))}));
  return{list:top,tested,ms:Date.now()-t0,curOv:curFinal.ov}}

/* ================= IMPROVE THE CURRENT ROTATION =================
   Starts from the user's own rotation and hill-climbs through small, explainable edits — add or change a
   winter cover, add a legume / break-crop year, swap a repeated year for another crop, reorder, or drop a
   repeated year. Every edit is scored on this location's resampled NASA weather; an edit is kept only if it
   raises the overall score and income stays within 5 points of the current rotation. Every crop the user
   grows stays in the rotation. Returns the improved rotation, the edits taken (with their score effect),
   and the change versus current on 12 fresh weather sequences. */
function improveRotation(cur,setup,rec,mg){
  const zone=setup.zone,t0=Date.now(),fast=mkSeeds(setup,rec,4,9000),final=mkSeeds(setup,rec,12,7000);
  const orig=cur.filter(s=>s.crop).map(s=>({crop:s.crop,cover:s.cover||null}));
  const empty={rot:null,steps:[],tested:0,ms:0};if(!orig.length)return empty;
  // a cover that overlaps its crop's season can't be planted — start the search without it
  const fixes=[],base=orig.map(s=>{if(s.cover&&coverConflict(s.crop,s.cover,zone)){fixes.push(`Remove the ${COVERS[s.cover].name.toLowerCase()} cover from ${CROPS_G[s.crop].name} — it overlaps the crop's growing season`);return{crop:s.crop,cover:null}}return s});
  const curFast=evalRot(orig,setup,rec,mg,fast),curFinal=evalRot(orig,setup,rec,mg,final);
  if(!curFast||!curFinal)return empty;
  const minInc=curFast.cat.income-5,own=new Set(base.map(s=>s.crop)),MAXL=8;
  const C=id=>CROPS_G[id],nm=id=>C(id).name,lc=s=>s.charAt(0).toLowerCase()+s.slice(1);
  const allPer=base.every(s=>C(s.crop).perennial&&s.crop!=='alfalfa');
  // candidate crops: best single-crop performers here, plus the best-fitting legumes and cereal/oilseed break crops
  const annual=Object.values(CROPS_G).filter(c=>!c.unmodeled&&!c.perennial&&c.cat!=='native'&&fitOf(c.id,zone)!=='poor');
  const ranked=allPer?[]:annual.map(c=>({c,e:evalRot([{crop:c.id,cover:autoCover(c.id,zone)}],setup,rec,mg,fast.slice(0,2))})).filter(x=>x.e).sort((a,b)=>b.e.ov-a.e.ov).map(x=>x.c);
  const pool=[...new Set([...ranked.slice(0,5),...ranked.filter(c=>c.nFix>0).slice(0,2),...ranked.filter(c=>['wheat','safflower','sorghum','barley','oats'].includes(c.id)).slice(0,2)].map(c=>c.id))];
  const why=id=>{const c=C(id);return c.nFix>0?'a legume that adds nitrogen for the next crop':`a different crop family (${c.fam}), so pests and diseases don't build up`};
  const neighbors=rot=>{const L=rot.length,out=[],put=(r,text)=>out.push({rot:r,text});
    rot.forEach((s,i)=>{[null,...Object.keys(COVERS)].forEach(cv=>{if(cv===s.cover||coverConflict(s.crop,cv,zone))return;const r=copy(rot);r[i].cover=cv;
      put(r,cv?`${s.cover?'Switch to':'Add'} a ${lc(COVERS[cv].name)} ${C(s.crop).perennial?'cover crop under':'winter cover after'} ${nm(s.crop)}${COVERS[cv].nFix>0?' — legume cover adds nitrogen':COVERS[cv].scav>.3?' — holds leftover nitrate and builds organic matter':''}`:`Leave the ground uncovered after ${nm(s.crop)} — saves the cover's spring water and cost`)})});
    if(allPer)return out;
    if(L<MAXL)for(let p=0;p<=L;p++)pool.forEach(id=>{const r=copy(rot);r.splice(p,0,{crop:id,cover:autoCover(id,zone)});put(r,`Add a year of ${nm(id)}${p<L?' before '+nm(rot[p].crop):' after '+nm(rot[L-1].crop)} — ${why(id)}`)});
    const count=id=>rot.filter(s=>s.crop===id).length;
    rot.forEach((s,i)=>{if(own.has(s.crop)&&count(s.crop)<2)return;
      pool.forEach(id=>{if(id===s.crop)return;const r=copy(rot);r[i]={crop:id,cover:autoCover(id,zone)};put(r,`Replace one ${nm(s.crop)} year with ${nm(id)} — ${why(id)}`)});
      if(L>1){const r=copy(rot);r.splice(i,1);put(r,`Drop one repeat ${nm(s.crop)} year`)}});
    for(let i=0;i<L-1;i++){if(rot[i].crop===rot[i+1].crop)continue;const r=copy(rot);[r[i],r[i+1]]=[r[i+1],r[i]];put(r,`Move ${nm(rot[i+1].crop)} ahead of ${nm(rot[i].crop)}`)}
    return out};
  const effect=(a,b)=>SCORE_CATS.map(([c,,l])=>({c,l,d:(b.cat[c]||0)-(a.cat[c]||0)})).filter(x=>Math.abs(x.d)>=1).sort((x,y)=>Math.abs(y.d)-Math.abs(x.d)).slice(0,3);
  let rot=base,e=fixes.length?evalRot(base,setup,rec,mg,fast)||curFast:curFast,tested=0;const steps=fixes.map(text=>({text,gain:e.ov-curFast.ov,fx:[]})),seen=new Set([JSON.stringify(base)]);
  for(let it=0;it<5;it++){let best=null;
    for(const n of neighbors(rot)){const key=JSON.stringify(n.rot);if(seen.has(key))continue;seen.add(key);tested++;
      const ne=evalRot(n.rot,setup,rec,mg,fast);if(!ne||ne.cat.income<minInc)continue;if(!best||ne.ov>best.e.ov)best={...n,e:ne}}
    if(!best||best.e.ov<e.ov+0.5)break;
    steps.push({text:best.text,gain:best.e.ov-e.ov,fx:effect(e,best.e)});rot=best.rot;e=best.e}
  if(steps.length===fixes.length&&!fixes.length)return{...empty,tested,ms:Date.now()-t0,curOv:curFinal.ov};
  const fe=evalRot(rot,setup,rec,mg,final);
  if(!fe||fe.ov<=curFinal.ov)return{...empty,tested,ms:Date.now()-t0,curOv:curFinal.ov};
  return{rot,steps,ov:fe.ov,curOv:curFinal.ov,vs:Object.fromEntries(SCORE_CATS.map(([c])=>[c,fe.cat[c]==null||curFinal.cat[c]==null?null:fe.cat[c]-curFinal.cat[c]])),tested,ms:Date.now()-t0}}

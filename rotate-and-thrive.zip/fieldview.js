'use strict';
/* Field picture: a farm scene drawn only from the model's outputs for one rotation-year.
   Sky = that year's rain; soil colour = soil score; plant shape = crop; plant size/colour = yield & stress;
   gaps = pest/disease loss; cracks = water shortage; green strips = winter cover; cutaway = roots + NASA soil wetness. */
const GLYPH={tomato:'bush',lettuce:'rosette',broccoli:'rosette',spinach:'rosette',artichoke:'rosette',carrot:'tops',garlic:'tops',onion:'tops',strawberry:'low',melon:'low',garbanzo:'low',drybean:'low',jojoba:'low',elderberry:'low',
  corn:'stalk',safflower:'stalk',sunflower:'sun',cotton:'cotton',wheat:'grain',sorghum:'grain',rice:'grain',alfalfa:'blades',bunchgrass:'blades',wildflower:'flower',
  almond:'tree',walnut:'tree',pistachio:'tree',peach:'tree',citrus:'tree',avocado:'tree',olive:'tree',pomegranate:'tree',date:'palm',winegrape:'vine',tablegrape:'vine'};
const FRUITCOL={tomato:'#d63b2f',citrus:'#f39c1f',peach:'#f08a6b',pomegranate:'#b3202f',avocado:'#2f4a1f',olive:'#4d3f22',strawberry:'#d62a45',melon:'#e6c25e',date:'#8a4b1c',tablegrape:'#8a52b8',winegrape:'#5b2a6e',elderberry:'#3a2a6e'};
const ROOTM={veg:.6,field:1,forage:1.5,orchard:1.5,vine:1.5,native:1};
const mixRGB=(a,b,t)=>`rgb(${a.map((v,i)=>Math.round(v+(b[i]-v)*t)).join(',')})`;
const DENS={veg:[7,9,9],field:[9,13,7],forage:[10,15,6],orchard:[4,5,15],vine:[5,8,9],native:[7,9,7]};

function glyph(type,id,x,y,s,col,dark,Y,rng,bearing){
  const f=FRUITCOL[id],n=Math.round(clamp(Y,0,1)*5);let o='';
  const dots=(cx,cy,r,count,c)=>{let d='';for(let i=0;i<count;i++)d+=`<circle cx="${(cx+(rng()-.5)*r*2).toFixed(1)}" cy="${(cy+(rng()-.5)*r*1.4).toFixed(1)}" r="${(1.5*s).toFixed(1)}" fill="${c}"/>`;return d};
  switch(type){
    case'bush':o+=`<ellipse cx="${x}" cy="${y-5*s}" rx="${7*s}" ry="${6*s}" fill="${col}" stroke="${dark}" stroke-width=".8"/><circle cx="${x-3*s}" cy="${y-7*s}" r="${4*s}" fill="${col}"/>`+(bearing?dots(x,y-5*s,6*s,n,f):'');break;
    case'rosette':for(let a=0;a<6;a++){const an=a*Math.PI/3;o+=`<circle cx="${(x+Math.cos(an)*3.5*s).toFixed(1)}" cy="${(y-3*s+Math.sin(an)*2.2*s).toFixed(1)}" r="${3.4*s}" fill="${col}" stroke="${dark}" stroke-width=".5"/>`}o+=`<circle cx="${x}" cy="${y-3*s}" r="${2.6*s}" fill="${col}" stroke="${dark}" stroke-width=".5" opacity=".9"/>`;break;
    case'tops':for(let a=-2;a<=2;a++)o+=`<line x1="${x}" y1="${y}" x2="${x+a*2.2*s}" y2="${y-9*s}" stroke="${col}" stroke-width="${1.6*s}" stroke-linecap="round"/>`;break;
    case'low':o+=`<ellipse cx="${x}" cy="${y-3*s}" rx="${6*s}" ry="${3.6*s}" fill="${col}" stroke="${dark}" stroke-width=".7"/>`+(bearing&&f?dots(x,y-3*s,5*s,Math.min(n,3),f):'');break;
    case'stalk':o+=`<line x1="${x}" y1="${y}" x2="${x}" y2="${y-15*s}" stroke="${dark}" stroke-width="${1.6*s}"/><path d="M${x} ${y-5*s} q${7*s} ${-3*s} ${8*s} ${-8*s} M${x} ${y-9*s} q${-7*s} ${-2*s} ${-8*s} ${-7*s}" stroke="${col}" stroke-width="${2*s}" fill="none" stroke-linecap="round"/>`;break;
    case'sun':o+=`<line x1="${x}" y1="${y}" x2="${x}" y2="${y-13*s}" stroke="${dark}" stroke-width="${1.6*s}"/><circle cx="${x}" cy="${y-15*s}" r="${4.5*s}" fill="${Y>.45?'#f4c20d':col}" stroke="#7a5a05" stroke-width=".6"/><circle cx="${x}" cy="${y-15*s}" r="${1.8*s}" fill="#5a3a12"/>`;break;
    case'cotton':o+=`<ellipse cx="${x}" cy="${y-5*s}" rx="${5*s}" ry="${6*s}" fill="${col}" stroke="${dark}" stroke-width=".6"/>`+(bearing?dots(x,y-6*s,4.5*s,n,'#fff'):'');break;
    case'grain':for(let a=-2;a<=2;a++){const hx=x+a*2.4*s;o+=`<line x1="${hx}" y1="${y}" x2="${hx+a*.8*s}" y2="${y-12*s}" stroke="${col}" stroke-width="${1.1*s}"/><ellipse cx="${hx+a*.8*s}" cy="${y-13*s}" rx="${1.1*s}" ry="${2.8*s}" fill="${Y>.5?'#d8b64a':col}"/>`}break;
    case'blades':for(let a=-3;a<=3;a++)o+=`<line x1="${x+a*1.3*s}" y1="${y}" x2="${x+a*2.1*s}" y2="${y-8*s}" stroke="${col}" stroke-width="${1.2*s}" stroke-linecap="round"/>`;break;
    case'flower':o+=`<ellipse cx="${x}" cy="${y-2*s}" rx="${4*s}" ry="${2.6*s}" fill="${col}"/>`+dots(x,y-5*s,4*s,3,['#f39c12','#9b59b6','#f4d03f','#e67e22'][Math.floor(rng()*4)]);break;
    case'tree':{const c=bearing?1:.45;o+=`<rect x="${x-1.4*s}" y="${y-8*s*c}" width="${2.8*s}" height="${8*s*c}" fill="#5a3d22"/><circle cx="${x}" cy="${y-(8+7)*s*c}" r="${(bearing?11:5)*s}" fill="${col}" stroke="${dark}" stroke-width=".8"/>`+(bearing&&f?dots(x,y-15*s,9*s,n+1,f):'');break}
    case'palm':o+=`<line x1="${x}" y1="${y}" x2="${x}" y2="${y-(bearing?16:6)*s}" stroke="#6b4a2a" stroke-width="${2.6*s}"/>`+[-3,-1.5,0,1.5,3].map(a=>`<path d="M${x} ${y-(bearing?16:6)*s} q${a*4*s} ${-8*s} ${a*8*s} ${-3*s}" stroke="${col}" stroke-width="${1.6*s}" fill="none" stroke-linecap="round"/>`).join('');break;
    case'vine':o+=`<line x1="${x}" y1="${y}" x2="${x}" y2="${y-9*s}" stroke="#6b4a2a" stroke-width="${1.4*s}"/><ellipse cx="${x}" cy="${y-8*s}" rx="${9*s}" ry="${5*s}" fill="${col}" stroke="${dark}" stroke-width=".7"/>`+(bearing&&f?dots(x,y-6*s,7*s,n,f):'');break;
    default:o+=`<circle cx="${x}" cy="${y-4*s}" r="${5*s}" fill="${col}"/>`}
  return o}

function fieldSVG(k,Sk,E,t){
  const r=E[k].first[t-1],row=r.rows[0],slot=r.slot,cr=slot.crop&&CROPS_G[slot.crop],W=360,H=262,rng=mulberry(k.charCodeAt(0)*977+t*131+(slot.crop||'x').length*17);
  const soilT=Sk?clamp(Sk.soil/100,0,1):.4,soil=mixRGB([214,178,124],[74,44,21],soilT),sub=mixRGB([196,160,110],[110,80,48],soilT*.6);
  const pidx=r.pidx,wet=pidx>1.3,dry=pidx<.75;
  // sky + hills
  let g=`<rect width="${W}" height="80" fill="${wet?'#aebdc9':dry?'#f0d9a8':'#bfe3f5'}"/>`;
  if(wet){g+=`<ellipse cx="80" cy="22" rx="52" ry="14" fill="#8696a4"/><ellipse cx="220" cy="30" rx="62" ry="15" fill="#8696a4"/>`;for(let i=0;i<22;i++){const x=(i*29+rng()*20)%W,y=36+rng()*34;g+=`<line x1="${x.toFixed(0)}" y1="${y.toFixed(0)}" x2="${(x-3).toFixed(0)}" y2="${(y+9).toFixed(0)}" stroke="#4d6a85" stroke-width="1.5"/>`}}
  else{g+=`<circle cx="${W-50}" cy="28" r="${dry?19:14}" fill="${dry?'#f08a24':'#ffd23f'}"/>`;if(!dry)g+=`<ellipse cx="90" cy="26" rx="34" ry="9" fill="#fff" opacity=".85"/><ellipse cx="120" cy="30" rx="26" ry="8" fill="#fff" opacity=".85"/>`;else for(let i=0;i<4;i++)g+=`<path d="M${30+i*70} 66 q8 -7 16 0 t16 0" stroke="#d9822b" fill="none" opacity=".6"/>`}
  g+=`<path d="M0 80 Q70 58 150 74 T290 66 T360 76 V84 H0Z" fill="${wet?'#6f8f6a':dry?'#b9a56a':'#7fa863'}"/>`;
  // ground
  g+=`<rect x="0" y="80" width="${W}" height="104" fill="${wet?'#7f9a62':dry?'#c2ad78':'#8fb26b'}"/>`;
  if(!cr||row.unmodeled){g+=`<polygon points="4,182 356,182 270,84 90,84" fill="${soil}"/><text x="${W/2}" y="140" text-anchor="middle" fill="#fff" font-size="15">${cr?'Crop not modeled — no picture':'Fallow (bare soil)'}</text>`;
    return`<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="${cr?'Not modeled':'Fallow'}">${g}</svg>`}
  const Y=row.Y,bearing=!!(Y>0||!cr.bear),Yeff=bearing?Y:.55,type=GLYPH[cr.id]||'bush',[nR,nP,sz]=DENS[cr.cat]||DENS.veg;
  g+=`<polygon points="4,182 356,182 270,84 90,84" fill="${soil}"/>`;
  const rowX=(i,d)=>{const tb=4+(i+.5)/nR*352,tt=90+(i+.5)/nR*180;return tt+(tb-tt)*d},yAt=d=>84+98*d;
  // winter cover strips between rows
  if(slot.cover)for(let i=0;i<=nR;i++){const p=i/nR,a=90+p*180,b=4+p*352,w=Math.max(2,9);g+=`<polygon points="${a-w*.25},84 ${a+w*.25},84 ${b+w},182 ${b-w},182" fill="#6fb35a" opacity=".6"/>`}
  // cracks (water shortage), puddles (wet), erosion streaks (low soil)
  const nCr=Math.round((1-(row.wsF==null?1:row.wsF))*50);for(let c=0;c<nCr;c++){const d=rng(),x=rowX(Math.floor(rng()*nR),d),y=yAt(d);g+=`<path d="M${x.toFixed(0)} ${y.toFixed(0)} l${(5*(.4+d)).toFixed(1)} ${(-8*(.4+d)).toFixed(1)} l${(-3*(.4+d)).toFixed(1)} ${(-7*(.4+d)).toFixed(1)}" stroke="#2b1a0e" stroke-width="1.2" fill="none" opacity=".6"/>`}
  if(wet)for(let c=0;c<3;c++){const d=.5+rng()*.5;g+=`<ellipse cx="${(50+rng()*260).toFixed(0)}" cy="${yAt(d).toFixed(0)}" rx="${(10+d*14).toFixed(0)}" ry="${(2+d*3).toFixed(0)}" fill="#6fa6d4" opacity=".5"/>`}
  if(Sk&&Sk.soil<45)for(let c=0;c<Math.round((45-Sk.soil)/5);c++){const x=20+rng()*320;g+=`<path d="M${x.toFixed(0)} 160 q6 12 -2 20 q-4 6 1 12" stroke="#6b3d17" stroke-width="3" fill="none" opacity=".5"/>`}
  // plants (far → near)
  const miss=clamp((1-(row.pestF==null?1:row.pestF))*1.5+(1-Yeff)*.12,0,.5),hue=30+clamp(Yeff,0,1)*95;
  for(let j=0;j<nP;j++){const d=Math.pow((j+.5)/nP,1.25),y=yAt(d),s=(.28+.8*d)*sz/7;
    for(let i=0;i<nR;i++){const x=rowX(i,d)+(rng()-.5)*6*s;
      if(rng()<miss){g+=`<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="${(3.2*s).toFixed(1)}" ry="${(1.6*s).toFixed(1)}" fill="#3b2412" opacity=".65"/>`;continue}
      const sc=s*(.55+.6*clamp(Yeff,0,1.1))*(.9+.2*rng()),L=34+rng()*9;
      g+=glyph(type,cr.id,+x.toFixed(1),+y.toFixed(1),+sc.toFixed(2),`hsl(${hue.toFixed(0)},58%,${L.toFixed(0)}%)`,`hsl(${hue.toFixed(0)},60%,18%)`,Y||0,rng,bearing)}}
  // soil cutaway
  const root=ROOTM[cr.cat]||1,wetv=row.wet!=null?row.wet:null,top=190,bot=H-6,hgt=bot-top;
  g+=`<rect x="4" y="${top}" width="352" height="${hgt}" fill="${sub}" stroke="#5a3d22" stroke-width="1.5"/><rect x="4" y="${top}" width="352" height="16" fill="${soil}"/>`;
  if(wetv!=null)g+=`<rect x="4" y="${(bot-wetv*hgt).toFixed(1)}" width="352" height="${(wetv*hgt).toFixed(1)}" fill="#3a7fb5" opacity=".2"/>`;
  const rl=Math.min(hgt-6,root*hgt*.62*clamp(Yeff+.25,.4,1));for(let i=0;i<9;i++){const x=24+i*38+(rng()-.5)*10;g+=`<path d="M${x.toFixed(0)} ${top} q${((rng()-.5)*14).toFixed(0)} ${(rl*.5).toFixed(0)} ${((rng()-.5)*10).toFixed(0)} ${rl.toFixed(0)}" stroke="#efe3c6" stroke-width="1.6" fill="none" opacity=".9"/>`}
  g+=`<text x="10" y="${top+11}" font-size="9.5" fill="#fff" opacity=".95">topsoil ${Sk?'· soil score '+Math.round(Sk.soil):''}</text><text x="${W-8}" y="${bot-4}" font-size="9.5" text-anchor="end" fill="#fff">${wetv!=null?'NASA soil wetness '+wetv.toFixed(2):'roots'}</text>`;
  return`<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Field picture for ${esc(cr.name)}, yield ${Y==null?'n/a':fmt(Y*100)+'%'}">${g}</svg>`}

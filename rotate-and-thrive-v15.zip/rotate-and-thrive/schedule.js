'use strict';
/* Editable rotation schedule: how many years each crop stays before the field rotates.
   Each rotation slot carries `yrs` (default 1). Presets set every slot to 1, 2, 3 or 5 years; "Custom" lets each crop
   have its own length. The model expands the slots year by year (expandRot in gamecore.js). Loaded before game.js. */
const SCH_PRESETS=[1,2,3,5];
const yrsOf=s=>Math.max(1,Math.round(s.yrs||1));
function holdOf(k){const r=U.rots[k];if(!r.length)return 1;const v=yrsOf(r[0]);return r.every(s=>yrsOf(s)===v)?v:null}
function schMode(k){const h=holdOf(k);return(U.schCustom&&U.schCustom[k])||!SCH_PRESETS.includes(h)?'custom':h}
function scheduleHTML(k){const rot=U.rots[k];if(!rot.length)return'';const mode=schMode(k),H=U.horizon,cyc=rot.reduce((a,s)=>a+yrsOf(s),0);
  const years=[];for(let y=0;y<H;y++){let t=y%cyc,i=0;while(t>=yrsOf(rot[i])){t-=yrsOf(rot[i]);i++}years.push({i,first:t===0,cyc:Math.floor(y/cyc)})}
  const tone=i=>['#ecfdf5','#eff6ff','#fef3c7','#fce7f3','#ede9fe','#e0f2fe','#fef9c3','#ffedd5'][i%8];
  const sel=U.sel&&U.sel.rot===k?U.sel.i:null;
  const runs=rot.map((s,i)=>{const a=rot.slice(0,i).reduce((x,r)=>x+yrsOf(r),0)+1,b=a+yrsOf(s)-1;return`${a===b?`Yr ${a}`:`Yr ${a}–${b}`} ${esc(CROPS_G[s.crop].name.split(' /')[0].split(' (')[0])}`});
  return`<div class="sched"><div class="schh"><b>📅 Rotation schedule</b><span class="tiny">Switch crops every</span>
   <div class="seg one" role="group" aria-label="Years before rotating">${SCH_PRESETS.map(n=>`<button data-act="schset" data-rot="${k}" data-v="${n}" class="${mode===n?'on':''}">${n} yr${n>1?'s':''}</button>`).join('')}<button data-act="schcustom" data-rot="${k}" class="${mode==='custom'?'on':''}">Custom</button></div></div>
   ${mode==='custom'?`<div class="schcus">${rot.map((s,i)=>`<div class="schc">${cropIco(s.crop,22)}<span>${esc(CROPS_G[s.crop].name.split(' /')[0].split(' (')[0])}</span><button data-act="schdec" data-rot="${k}" data-i="${i}" aria-label="One year less" ${yrsOf(s)<=1?'disabled':''}>−</button><b>${yrsOf(s)} yr${yrsOf(s)>1?'s':''}</b><button data-act="schinc" data-rot="${k}" data-i="${i}" aria-label="One year more" ${yrsOf(s)>=10?'disabled':''}>＋</button></div>`).join('')}</div>`:''}
   <div class="schline" role="list" aria-label="Year-by-year schedule">${years.map((y,j)=>{const s=rot[y.i];return`<button class="schy ${y.first?'sst':''} ${sel===y.i?'sel':''}" role="listitem" data-act="schpick" data-rot="${k}" data-i="${y.i}" style="--bg:${tone(y.i)}" title="Year ${j+1}: ${esc(CROPS_G[s.crop].name)}${s.cover?' + '+esc(COVERS[s.cover].name)+' cover':''} — click to change">${cropIco(s.crop,22)}${s.cover?`<span class="cvb sm">${ico('cover',s.cover,11)}</span>`:''}<small>${j+1}</small></button>`}).join('')}</div>
   <div class="tiny schsum">${runs.join(' → ')} · repeats every ${cyc} year${cyc>1?'s':''}${cyc>H?` · <b>one full cycle is longer than your ${H}-year simulation</b> — raise Years in Settings`:''}. Click a year to change its crop.</div></div>`}

document.addEventListener('click',e=>{const b=e.target.closest('[data-act^="sch"]');if(!b)return;const k=b.dataset.rot,rot=U.rots[k],i=+b.dataset.i,a=b.dataset.act;if(!rot)return;
  U.schCustom=U.schCustom||{};
  if(a==='schset'){const n=+b.dataset.v;rot.forEach(s=>s.yrs=n);U.schCustom[k]=false}
  else if(a==='schcustom'){U.schCustom[k]=true;render();return}
  else if(a==='schinc'||a==='schdec'){rot[i].yrs=clamp(yrsOf(rot[i])+(a==='schinc'?1:-1),1,10);U.schCustom[k]=true}
  else if(a==='schpick'){U.sel=U.sel&&U.sel.rot===k&&U.sel.i===i?null:{rot:k,i};render();const inp=document.getElementById('cq-'+k);inp&&inp.focus();return}
  change()});

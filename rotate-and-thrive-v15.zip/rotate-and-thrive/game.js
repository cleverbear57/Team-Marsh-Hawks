'use strict';
/* California Rotation Lab — compact one-page rotation explorer */
const U={mapView:null,nassCrop:'',loc:null,rec:null,recMsg:'',recState:'none',zone:null,soil:'loam',horizon:15,planMode:'plan',interval:null,dec:[],pick:null,priority:'soil',alloc:100,seed:57,N:30,
  rots:{cur:[],prop:[]},sel:null,cq:{cur:'',prop:''},q:'',matches:[],nearby:null,msgSetup:'',mg:{equip:[],fert:'standard',irrig:'full'},msg:{cur:'',prop:''},
  sim:null,t:0,timer:null,acres:40,clim:{dT:0,dP:0},cw:null,wiOpen:false,sugRes:null,impRes:null,busy:false,busyKind:'',page:1};
const PRI={soil:'Soil',water:'Water',output:'Income',resil:'Resilience'};
/* drawn icons for the crops added in data/us_regions.js reuse the closest existing sprite */
if(typeof CROP_ICO!=='undefined')[['graincorn','corn'],['soybean','drybean'],['peanut','garbanzo'],['oats','wheat'],['barley','wheat'],['canola','safflower'],['potato','carrot'],['sugarbeet','carrot'],['pecan','walnut'],['apple','peach']].forEach(([a,b])=>{if(!CROP_ICO[a]&&CROP_ICO[b])CROP_ICO[a]=CROP_ICO[b]});
const RK={cur:{n:'Current',c:'#b45309'},prop:{n:'Proposed',c:'#0e7490'}};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const money=x=>x==null?'n/a':usd(x);
const scol=v=>v==null?'#999':v<40?'#dc2626':v<60?'#d97706':'#059669';
const ready=()=>U.rec&&(U.recState==='ready'||U.recState==='illustrative');
const copy=o=>JSON.parse(JSON.stringify(o));
const setup=()=>({zone:U.zone,soil:U.soil,horizon:U.horizon,priority:U.priority,allocPct:U.alloc,seed:U.seed});
function dataStatus(){const r=U.rec;return[['Weather',r?(r.status==='available'?'ok':'bad'):'warn',r?`${r.source} · ${r.years[0]}–${r.years[r.years.length-1]} (${r.n} complete years)`:'not loaded'],['Soil moisture',r&&r.Sw?'ok':'warn',r&&r.Sw?'NASA MERRA-2 root-zone soil wetness (via POWER), monthly 2001–2025 — sets starting soil water':'not available for this weather source'],['Soil texture','warn','Regional texture default — edit it; SSURGO lookup not wired in'],['Satellite fields (SMAP, GPM, ECOSTRESS, GRACE)','warn','Context only; not used inside the game model'],['Current rotation','warn','Default is an illustrative example']]}
function reset(){stop();U.sim=null;U.t=0;U.sugRes=null;U.impRes=null}
function stop(){if(U.timer){clearInterval(U.timer);U.timer=null}}

/* ---------- location ---------- */
function search(q){q=q.trim().toLowerCase();if(!q)return[];const ca=GAZ.filter(g=>g.name.toLowerCase().includes(q)||g.county.toLowerCase().includes(q)).slice(0,6),us=[];
  if(typeof LM!=='undefined'&&LM.us&&q.length>=3)LM.us.eachLayer(l=>{if(us.length<6&&l.feature.properties.name.toLowerCase().startsWith(q.replace(/ county.*$/,''))){const st=US_STATE_ABBR[String(l.feature.id).slice(0,2)];us.push({us:true,id:String(l.feature.id),name:l.feature.properties.name+' County',county:st||''})}});
  return ca.concat(us).slice(0,10)}
/* which U.S. county (us-atlas feature) contains a point — used for pins outside California */
function usFeatureAt(lat,lon){if(typeof LM==='undefined'||!LM.us)return null;let hit=null;const inRing=r=>{let k=false;for(let i=0,j=r.length-1;i<r.length;j=i++){const[xi,yi]=r[i],[xj,yj]=r[j];if((yi>lat)!==(yj>lat)&&lon<(xj-xi)*(lat-yi)/(yj-yi)+xi)k=!k}return k};
  LM.us.eachLayer(l=>{if(hit||!l.getBounds().contains([lat,lon]))return;const g=l.feature.geometry,polys=g.type==='Polygon'?[g.coordinates]:g.coordinates;if(polys.some(p=>inRing(p[0])&&!p.slice(1).some(inRing)))hit=l.feature});return hit}
function parseLL(q){const m=q.match(/^\s*(-?\d+(\.\d+)?)\s*[, ]\s*(-?\d+(\.\d+)?)\s*$/);return m?{lat:+m[1],lon:+m[3]}:null}
function distKm(a,b){return Math.hypot(a.lat-b.lat,(a.lon-b.lon)*Math.cos(a.lat*Math.PI/180))*111}
async function loadLoc(loc){
  reset();U.msgSetup='';U.nearby=null;U.matches=[];U.usData=[];U.soilInfo=null;delete SOILG['USDA soil survey'];
  const inCA=inCalifornia(loc.lat,loc.lon);let zone=inCA?zoneOf(loc.lat,loc.lon):null;
  if(!inCA){const f=(typeof US_ZONES!=='undefined')?usFeatureAt(loc.lat,loc.lon):null;zone=f&&usZoneOf(f.id);
    if(!zone){U.loc=null;U.rec=null;U.recState='none';U.msgSetup=(typeof US_ZONES!=='undefined')?(LM.us?'Outside the United States — pick a U.S. place.':'The U.S. county map is still loading — try again in a moment.'):'Outside California — pick a California place.';render();return}
    U.usSel=String(f.id);loc={...loc,county:f.properties.name+' County',state:US_STATE_ABBR[String(f.id).slice(0,2)]||''}}
  else U.usSel=null;
  U.loc=loc;U.zone=zone;U.soil=ZONE_SOIL[U.zone];U.recState='loading';
  /* outside California: real USDA yields, prices, costs and irrigation for this state/county, and this spot's soil survey */
  const soilP=!inCA&&typeof fetchSoil==='function'?fetchSoil(loc.lat,loc.lon):null;
  if(!inCA&&typeof applyUSData==='function')U.usData=applyUSData(zone,loc.state,U.usSel);
  render();
  let rec=null;if(loc.id)rec=cachedRecord(loc.id,loc.lat);
  if(!rec){try{rec=await liveRecord(loc.lat,loc.lon)}catch(e){const n=inCA&&GAZ.map(g=>({g,d:distKm(g,loc)})).sort((a,b)=>a.d-b.d)[0];   // cached California weather is only a fair stand-in inside California
    rec=n&&cachedRecord(n.g.id,loc.lat);if(rec)rec.source=`NASA POWER (cached for ${n.g.name}, ${fmt(n.d)} km away)`;else U.recMsg='NASA POWER request failed.'}}
  const soil=soilP?await soilP:null;if(U.loc!==loc)return;   // a newer pin arrived meanwhile
  if(soil){SOILG['USDA soil survey']={awc:soil.awc,leach:soil.leach,om0:soil.om0};U.soil='USDA soil survey';U.soilInfo=soil}
  if(rec){U.rec=rec;U.recState='ready';defaultRots()}else{U.rec=null;U.recState='failed'}
  render()}
function defaultRots(){U.rots.cur=[{crop:DEFAULT_CROP[U.zone],cover:null}];U.rots.prop=suggestRotation(U.rots.cur,U.zone);U.sel=null;U.cq={cur:'',prop:''}}
function runSearch(){if(!ready()||!U.rots.cur.length)return;U.busy=true;U.busyKind='search';render();setTimeout(()=>{try{const r=searchRotations(U.rots.cur,setup(),simRec(),U.mg);reset();U.sugRes=r;if(r.list.length)U.rots.prop=copy(r.list[0].rot)}finally{U.busy=false;render()}},40)}
function runImprove(){if(!ready()||!U.rots.cur.length)return;U.busy=true;U.busyKind='improve';render();setTimeout(()=>{try{const r=improveRotation(U.rots.cur,setup(),simRec(),U.mg);reset();U.impRes=r;if(r.rot){U.rots.prop=copy(r.rot);U.sel=null}}finally{U.busy=false;render()}},40)}
function useNearby(){const n=U.nearby;U.rec=cachedRecord(n.g.id,U.loc.lat);U.rec.source=`NASA POWER (cached for ${n.g.name}, ${fmt(n.d)} km away)`;U.recState='ready';defaultRots();render()}
function useSynthetic(){U.rec=syntheticRecord(U.zone,U.loc.lat,U.seed);U.recState='illustrative';defaultRots();render()}

/* ---------- crop search ---------- */
const FITORD={good:0,ok:1,poor:2,unmodeled:3};
function cropMatches(q){q=q.trim().toLowerCase();let L=Object.values(CROPS_G);
  if(!q)return L.filter(c=>fitOf(c.id,U.zone)==='good').slice(0,10);
  L=L.filter(c=>(c.name+' '+c.fam+' '+CAT_LABEL[c.cat]+' '+c.id+(c.cat==='native'?' california native':'')).toLowerCase().includes(q));
  const rank=c=>{const t=(c.name+' '+(c.cat==='native'?'california native':'')).toLowerCase(),ws=t.split(/[\s\/(),-]+/);return(ws.some(w=>w.startsWith(q))?0:10)+FITORD[fitOf(c.id,U.zone)]};
  return L.sort((a,b)=>rank(a)-rank(b)).slice(0,8)}
const sugBtn=(c,k)=>{const f=fitOf(c.id,U.zone);return`<button class="sug" draggable="true" data-drag="crop:${c.id}" data-act="addcrop" data-rot="${k}" data-id="${c.id}"><span class="e">${cropIco(c.id,36)}</span><span><b>${c.name}</b><small class="fit-${f}">${FIT_LABEL[f]}${c.cat==='native'?' · CA native':''}</small></span></button>`};

/* ---------- map: California counties shaded by USDA NASS crop acreage (data/nass.js, cached by tools/fetch_nass.py) ---------- */
const MAPK=53.6,mapP=([lo,la])=>[(lo+124.6)*.8*MAPK,(42.1-la)*MAPK];
const NASS_SCALE=['#f1f5f9','#d1fae5','#a7f3d0','#6ee7b7','#10b981','#047857'];
let _rings=null;
function countyRings(){if(_rings||!window.CA_COUNTIES)return _rings||{};_rings={};
  for(const[f,c]of Object.entries(CA_COUNTIES))_rings[f]=c.d.split('Z').filter(Boolean).map(r=>r.replace('M','').split('L').map(p=>p.split(',').map(Number)));return _rings}
function countyAtXY(x,y){for(const[f,rs]of Object.entries(countyRings())){let inside=false;for(const r of rs)for(let i=0,j=r.length-1;i<r.length;j=i++){const[xi,yi]=r[i],[xj,yj]=r[j];if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)inside=!inside}if(inside)return f}return null}
function locCounty(){if(!U.loc||!window.CA_COUNTIES||(U.loc.state&&U.loc.state!=='CA'))return null;
  if(U.loc.county){const n=U.loc.county.toLowerCase();const f=Object.keys(CA_COUNTIES).find(k=>CA_COUNTIES[k].name.toLowerCase()===n);if(f)return f}
  const[x,y]=mapP([U.loc.lon,U.loc.lat]);return countyAtXY(x,y)}
const nassVal=(f,crop)=>{const c=window.NASS&&NASS.counties[f];if(!c)return null;return crop?(c.crops[crop]??null):(c.cropland??null)};
const EXTRA_CROPS={soybean:['Soybeans','drybean'],barley:['Barley','wheat'],oats:['Oats','wheat'],rye:['Rye (grain)','wheat'],canola:['Canola','safflower'],peanut:['Peanuts','garbanzo'],sugarbeet:['Sugar beets','carrot'],lentil:['Lentils','garbanzo'],potato:['Potatoes','carrot'],tobacco:['Tobacco','lettuce'],pecan:['Pecans','walnut'],apple:['Apples','peach'],cherry:['Cherries','peach'],blueberry:['Blueberries','strawberry']};
const nassCropName=id=>id==='winegrape'?'Grapes (wine & table)':id==='corn'?'Corn (grain & silage)':id?(CROPS_G[id]?CROPS_G[id].name:EXTRA_CROPS[id]?EXTRA_CROPS[id][0]:id):'All harvested cropland';
const nassIco=(id,px)=>cropIco(EXTRA_CROPS[id]?EXTRA_CROPS[id][1]:id,px);
function nassAllVals(crop){const pick=o=>o?Object.values(o.counties).map(c=>crop?(c.crops[crop]??null):(c.cropland??null)).filter(v=>typeof v==='number'):[];return pick(window.NASS).concat(pick(window.NASS_US))}
const usVal=(f,crop)=>{const c=window.NASS_US&&NASS_US.counties[f];if(!c)return null;return crop?(c.crops[crop]??null):(c.cropland??null)};
function nassBreaks(vals){const v=vals.filter(x=>x>0).sort((a,b)=>a-b);return[.2,.4,.6,.8].map(q=>v.length?v[Math.min(v.length-1,Math.floor(q*v.length))]:0)}
function nassColor(v,br){if(v==null)return'#e2e8f0';if(v==='D')return'url(#nassD)';if(!v)return NASS_SCALE[0];let i=1;for(const b of br)if(v>b)i++;return NASS_SCALE[Math.min(5,i)]}
const acres=v=>v==null?'no data':v==='D'?'withheld by NASS':Math.round(v).toLocaleString()+' ac';
/* map zoom & pan: U.mapView = [x,y,w,h] viewBox in map units (null = whole state) */
const MAPW=500,MAPH=520,MAPMIN=MAPW/16;
const mapVB=()=>U.mapView||[0,0,MAPW,MAPH];
function setMapView(v){if(!v||v[2]>=MAPW-.5){U.mapView=null;return}const w=Math.max(MAPMIN,v[2]),h=w*MAPH/MAPW;U.mapView=[clamp(v[0],0,MAPW-w),clamp(v[1],0,MAPH-h),w,h]}
function zoomAt(cx,cy,f){const[x,y,w,h]=mapVB(),nw=clamp(w*f,MAPMIN,MAPW),r=nw/w;setMapView([cx-(cx-x)*r,cy-(cy-y)*r,nw,h*r])}
function zoomToCounty(f){const rs=countyRings()[f];if(!rs)return;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const r of rs)for(const[x,y]of r){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y)}
  const w=Math.max((x1-x0)*1.5,(y1-y0)*1.5*MAPW/MAPH,MAPMIN*1.5);setMapView([(x0+x1)/2-w/2,(y0+y1)/2-w*MAPH/MAPW/2,w])}
function mapPt(svg,e){const p=svg.createSVGPoint();p.x=e.clientX;p.y=e.clientY;const q=p.matrixTransform(svg.getScreenCTM().inverse());return[q.x,q.y]}
function wireMap(){if(useLeaflet())return wireLeaflet();const cm=document.getElementById('camap');if(!cm)return;let drag=null;
  const pin=(x,y)=>{const f=countyAtXY(x,y);loadLoc({name:'Map pin',county:f&&window.CA_COUNTIES?CA_COUNTIES[f].name:undefined,lat:+(42.1-y/MAPK).toFixed(3),lon:+(x/(.8*MAPK)-124.6).toFixed(3)})};
  cm.addEventListener('wheel',e=>{e.preventDefault();const[x,y]=mapPt(cm,e);zoomAt(x,y,e.deltaY<0?.8:1.25);cm.setAttribute('viewBox',mapVB().join(' '));scaleMarks(cm);syncZoomUI()},{passive:false});
  cm.addEventListener('pointerdown',e=>{if(e.button)return;drag={sx:e.clientX,sy:e.clientY,v:mapVB().slice(),moved:false,pt:mapPt(cm,e)};cm.setPointerCapture(e.pointerId)});
  cm.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;if(!drag.moved&&Math.hypot(dx,dy)<5)return;
    drag.moved=true;if(!U.mapView)return;const b=cm.getBoundingClientRect(),s=drag.v[2]/b.width;setMapView([drag.v[0]-dx*s,drag.v[1]-dy*s,drag.v[2]]);cm.setAttribute('viewBox',mapVB().join(' '));cm.style.cursor='grabbing'});
  cm.addEventListener('pointerup',()=>{if(!drag)return;const d=drag;drag=null;cm.style.cursor='';if(!d.moved)pin(d.pt[0],d.pt[1])});
  cm.addEventListener('dblclick',e=>e.preventDefault())}
function scaleMarks(cm){const k=mapVB()[2]/MAPW;cm.querySelectorAll('[data-r]').forEach(c=>c.setAttribute('r',+c.dataset.r*Math.max(k,.18)));cm.querySelectorAll('[data-sw]').forEach(c=>c.setAttribute('stroke-width',+c.dataset.sw*Math.max(k,.18)))}
function syncZoomUI(){const z=document.getElementById('mapzoomlvl');if(z)z.textContent=(MAPW/mapVB()[2]).toFixed(1)+'×';const o=document.querySelector('[data-act=mapzoom][data-v=out]'),r=document.querySelector('[data-act=mapzoom][data-v=reset]');if(o)o.disabled=!U.mapView;if(r)r.disabled=!U.mapView;
  const cm=document.getElementById('camap');if(cm)cm.style.touchAction=U.mapView?'none':''}
/* ---------- Leaflet + OpenStreetMap basemap (same map API as the Field Shift project) ----------
   One Leaflet map is created once and kept alive; render() rebuilds the page, so wireMap() re-attaches
   the map's element into #lmapslot and refreshes county shading, the selected county and the pin.
   If Leaflet can't load (offline), mapPanel() falls back to the drawn SVG map above. */
const useLeaflet=()=>typeof window.L!=='undefined'&&!!window.CA_COUNTIES;
const unP=([x,y])=>[42.1-y/MAPK,x/(.8*MAPK)-124.6];           // map units → [lat, lon]
const LM={map:null,el:null,counties:{},dots:null,pin:null,locKey:'',fitted:false,us:null};
/* every other U.S. county (US Census cartographic boundaries via us-atlas, same source as data/ca_counties.js),
   drawn on a canvas layer so ~3,000 outlines stay fast. California keeps its own NASS-shaded layer on top. */
const US_ATLAS_JS='vendor/counties-10m.js',TOPO_JS='vendor/topojson-client.min.js';   // bundled locally (as scripts, not fetch) so the map works offline, from file://, and inside sandboxes that block other hosts
const loadScript=src=>new Promise((ok,no)=>{if(window.topojson)return ok();const t=document.createElement('script');t.src=src;t.onload=ok;t.onerror=no;document.head.appendChild(t)});
async function addUSCounties(){try{await loadScript(TOPO_JS);if(!window.US_ATLAS_TOPO)await loadScript2(US_ATLAS_JS);const topo=window.US_ATLAS_TOPO;
  const states={};topojson.feature(topo,topo.objects.states).features.forEach(f=>states[f.id]=f.properties.name);
  const feats=topojson.feature(topo,topo.objects.counties).features.filter(f=>!String(f.id).startsWith('06'));
  LM.states=states;
  LM.us=L.geoJSON({type:'FeatureCollection',features:feats},{renderer:L.canvas({padding:.5}),style:{color:'#065f46',weight:1.2,opacity:.9,fillColor:'#a7f3d0',fillOpacity:.6},
    onEachFeature:(f,p)=>{p.bindTooltip('',{sticky:true});
      p.on('mouseover',()=>{p.setStyle({weight:2.5,color:'#022c22',fillOpacity:.75});p.bringToFront()});p.on('mouseout',()=>p.setStyle(p._base||{}));
      p.on('click',e=>{U.usSel=String(f.id);LM.usLL=e.latlng})}}).addTo(LM.map);
  LM.us.bringToBack();styleUS(true);
  if(!window.NASS_US)loadScript2('data/nass_us.js?v=2').then(()=>{styleUS(true);render()}).catch(()=>{})}catch(e){console.warn('U.S. county outlines unavailable',e)}}
const loadScript2=src=>new Promise((ok,no)=>{const t=document.createElement('script');t.src=src;t.onload=ok;t.onerror=no;document.head.appendChild(t)});
const usCountyName=id=>{const c=window.NASS_US&&NASS_US.counties[id];if(c)return c.name.replace(/, ([A-Z]{2})$/,(m,st)=>' County, '+st);let n='';LM.us&&LM.us.eachLayer(l=>{if(String(l.feature.id)===id)n=l.feature.properties.name+' County, '+(LM.states[id.slice(0,2)]||'')});return n};
/* shade the rest of the U.S. on the same scale as California (re-styled only when the crop or data changes) */
function styleUS(force){if(!LM.us)return;const crop=U.nassCrop||'',has=!!window.NASS_US,usSel=locCounty()?null:U.usSel,key=crop+'|'+has+'|'+(usSel||'');if(!force&&key===LM.usKey)return;LM.usKey=key;
  const br=nassBreaks(nassAllVals(crop));
  LM.us.eachLayer(p=>{const id=String(p.feature.id),v=has?usVal(id,crop):null,sel=id===usSel;
    p._base={color:sel?'#0f172a':'#065f46',weight:sel?3.5:1.2,opacity:sel?1:.9,fillColor:!has?'#a7f3d0':v==='D'?'#cbd5e1':(v==null||!v)?'#ecfdf5':nassColor(v,br),fillOpacity:satOp(sel?.8:.6)};p.setStyle(p._base);
    p.setTooltipContent(`<b>${esc(p.feature.properties.name)} County, ${esc(LM.states[id.slice(0,2)]||'')}</b>${has?'<br>'+esc(nassCropName(crop))+': '+acres(v):''}<br><span style="color:#64748b">Click to plan here and see its crops</span>`)})}
function initLeaflet(){if(LM.map)return;
  LM.el=document.createElement('div');LM.el.className='lmap';LM.el.setAttribute('aria-label','Map of California counties. Click to drop a pin.');
  LM.map=L.map(LM.el,{zoomSnap:.5,scrollWheelZoom:true,wheelPxPerZoomLevel:90,minZoom:3,maxZoom:15,maxBounds:[[10,-180],[75,-50]],maxBoundsViscosity:.8}).fitBounds([[32.5,-124.4],[42,-114.1]]);
  LM.map.createPane('pinPane').style.zIndex=650;   // pin always above the county layers
  /* basemap: NASA Blue Marble shaded relief, bundled with the site so it shows offline and inside sandboxed viewers:
     images/sat/us.jpg covers the whole U.S. (GIBS, Web Mercator so it lines up with the map), and the sharper
     images/sat/california.jpg (built by tools/build_sat.py) sits on top of it. */
  LM.map.createPane('labelPane').style.zIndex=450;
  LM.base={sat:L.layerGroup([L.imageOverlay('images/sat/us.jpg',[[15,-180],[72,-60]],{attribution:'Imagery: NASA Blue Marble (GIBS)',interactive:false}),
    L.imageOverlay('images/sat/california.jpg',[[31.5,-125.5],[43,-113.5]],{interactive:false})])};
  const Toggle=L.Control.extend({options:{position:'topright'},onAdd(){const d=L.DomUtil.create('div','basetoggle');d.setAttribute('role','group');d.setAttribute('aria-label','Satellite image');
    d.innerHTML='<button type="button" data-base="sat">Satellite</button><button type="button" data-base="map">Off</button>';L.DomEvent.disableClickPropagation(d);L.DomEvent.disableScrollPropagation(d);
    d.addEventListener('click',e=>{const b=e.target.closest('[data-base]');if(b)setBasemap(b.dataset.base)});return d}});
  LM.toggle=new Toggle().addTo(LM.map);
  setBasemap(U.mapBase||'sat');
  for(const[f,rs]of Object.entries(countyRings())){const p=LM.counties[f]=L.polygon(rs.map(r=>r.map(unP)),{weight:1.4,color:'#065f46',opacity:.9,fillOpacity:.6}).bindTooltip('',{sticky:true}).addTo(LM.map);
    p.on('mouseover',()=>{p.setStyle({weight:3.5,color:'#022c22',fillOpacity:.85});p.bringToFront();LM.pin&&LM.pin.bringToFront()});
    p.on('mouseout',()=>{p.setStyle(p._base||{});const s=locCounty();s&&LM.counties[s]&&LM.counties[s].bringToFront();LM.pin&&LM.pin.bringToFront()})}
  addUSCounties();
  LM.dots=L.layerGroup(GAZ.map(g=>L.circleMarker([g.lat,g.lon],{radius:3,weight:1,color:'#fff',fillColor:'#334155',fillOpacity:.8}).bindTooltip(esc(g.name)))).addTo(LM.map);
  LM.map.on('click',e=>{const{lat,lng}=e.latlng,x=(lng+124.6)*.8*MAPK,y=(42.1-lat)*MAPK,f=countyAtXY(x,y);if(f)U.usSel=null;
    loadLoc({name:'Map pin',county:f?CA_COUNTIES[f].name:undefined,lat:+lat.toFixed(3),lon:+lng.toFixed(3)})})}
function setBasemap(k){U.mapBase=k;if(LM.noTiles)return;for(const[n,l]of Object.entries(LM.base)){if(n===k){if(!LM.map.hasLayer(l))l.addTo(LM.map)}else if(LM.map.hasLayer(l))LM.map.removeLayer(l)}
  LM.el.classList.toggle('is-sat',k==='sat');syncBaseToggle();
  if(Object.keys(LM.counties).length){styleUS(true);wireLeaflet()}}
/* satellite view: lighter county fills so the photo shows through */
const satOp=x=>U.mapBase==='sat'?Math.min(x,.16):x;
function noTiles(){LM.noTiles=true;for(const l of Object.values(LM.base))if(LM.map.hasLayer(l))LM.map.removeLayer(l);
  LM.el.classList.remove('is-sat');LM.el.classList.add('no-tiles');if(LM.toggle){LM.map.removeControl(LM.toggle);LM.toggle=null}
  LM.map.attributionControl.addAttribution('Background map unavailable here · county outlines: US Census Bureau (us-atlas)')}
function syncBaseToggle(){const d=LM.toggle&&LM.toggle.getContainer();if(d)d.querySelectorAll('[data-base]').forEach(b=>{const on=b.dataset.base===(U.mapBase||'sat');b.classList.toggle('on',on);b.setAttribute('aria-pressed',on)})}
function zoomLeafletToCounty(f){const p=LM.counties[f];if(p)LM.map.flyToBounds(p.getBounds(),{padding:[24,24],duration:.6})}
function wireLeaflet(){const slot=document.getElementById('lmapslot');if(!slot)return;initLeaflet();
  if(LM.el.parentNode!==slot)slot.appendChild(LM.el);LM.map.invalidateSize(false);
  if(!LM.fitted&&LM.el.clientWidth){LM.fitted=true;LM.map.fitBounds([[32.5,-124.4],[42,-114.1]],{padding:[6,6]})}
  const crop=U.nassCrop||'',sel=locCounty(),has=!!window.NASS,br=nassBreaks(nassAllVals(crop));styleUS();
  for(const[f,p]of Object.entries(LM.counties)){const v=has?nassVal(f,crop):null;
    const fc=!has?'#a7f3d0':v==='D'?'#cbd5e1':(v==null||!v)?'#ecfdf5':nassColor(v,br);   // every county gets a visible tint and outline
    p._base={fillColor:fc,color:f===sel?'#0f172a':'#065f46',weight:f===sel?3.5:1.4,opacity:f===sel?1:.9,fillOpacity:satOp(f===sel?.8:.6)};p.setStyle(p._base);if(f===sel)p.bringToFront();
    p.setTooltipContent(`<b>${esc(CA_COUNTIES[f].name)} County</b>${has?'<br>'+esc(nassCropName(crop))+': '+acres(v):''}`)}
  if(LM.pin){LM.pin.remove();LM.pin=null}
  if(!U.loc&&U.usSel&&LM.usLL)LM.pin=L.circleMarker(LM.usLL,{radius:9,weight:3,color:'#fff',fillColor:'#dc2626',fillOpacity:1,pane:'pinPane'}).addTo(LM.map);
  if(U.loc){LM.pin=L.circleMarker([U.loc.lat,U.loc.lon],{radius:9,weight:3,color:'#fff',fillColor:'#dc2626',fillOpacity:1,pane:'pinPane'}).bindTooltip(esc(U.loc.name||'Pin')).addTo(LM.map);
    const key=U.loc.lat+','+U.loc.lon;if(key!==LM.locKey){const fromMap=U.loc.name==='Map pin';LM.locKey=key;if(!fromMap)LM.map.flyTo([U.loc.lat,U.loc.lon],Math.max(LM.map.getZoom(),9),{duration:.8})}}}
function mapSVG(){
  const crop=U.nassCrop||'',sel=locCounty(),has=!!window.NASS,C=window.CA_COUNTIES,mk=Math.max(mapVB()[2]/MAPW,.18);
  let body;
  if(C){const vals=has?Object.keys(C).map(f=>nassVal(f,crop)).filter(v=>typeof v==='number'):[],br=nassBreaks(vals);
    body=Object.entries(C).map(([f,c])=>`<path d="${c.d}" fill="${has?nassColor(nassVal(f,crop),br):'#f8fafc'}" stroke="${f===sel?'#0f172a':'#ffffff'}" stroke-width="${f===sel?2.6:.9}" vector-effect="non-scaling-stroke"><title>${esc(c.name)} County${has?' — '+esc(nassCropName(crop))+': '+acres(nassVal(f,crop)):''}</title></path>`).join('');
    if(sel)body+=`<path d="${C[sel].d}" fill="none" stroke="#0f172a" stroke-width="2.6" vector-effect="non-scaling-stroke" pointer-events="none"/>`}
  else body=`<polygon points="${CA_OUTLINE.map(p=>mapP(p).join(',')).join(' ')}" fill="#f8fafc" stroke="#0f172a" stroke-width="2"/>`;
  const dots=GAZ.map(g=>{const[x,y]=mapP([g.lon,g.lat]);return`<circle cx="${x}" cy="${y}" r="${2.2*mk}" data-r="2.2" fill="#334155" opacity=".5" pointer-events="none"><title>${esc(g.name)}</title></circle>`}).join('');
  let pin='';if(U.loc){const[x,y]=mapP([U.loc.lon,U.loc.lat]);pin=`<circle cx="${x}" cy="${y}" r="${8*mk}" data-r="8" fill="#dc2626" stroke="#fff" stroke-width="${2.5*mk}" data-sw="2.5" pointer-events="none"/>`}
  return`<svg id="camap" viewBox="${mapVB().join(' ')}" width="100%" style="cursor:crosshair;display:block;${U.mapView?'touch-action:none;':''}" role="img" aria-label="California county map${has?' shaded by '+esc(nassCropName(crop))+' acres from USDA NASS':''}: click to place a pin">
   <defs><pattern id="nassD" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="6" height="6" fill="#e2e8f0"/><rect width="2" height="6" fill="#94a3b8"/></pattern></defs>${body}${dots}${pin}</svg>`}
function mapPanel(){
  const has=!!window.NASS,sel=locCounty(),C=window.CA_COUNTIES||{},crop=U.nassCrop||'';
  const allC=Object.values(NASS.counties||{}).concat(Object.values((window.NASS_US||{}).counties||{}));
  const opts=has?[['','All harvested cropland'],...[...new Set(Object.keys(CROPS_G).concat(Object.keys(EXTRA_CROPS)))].filter(id=>id!=='tablegrape'&&allC.some(c=>c.crops[id]!=null)).map(id=>[id,nassCropName(id)])]:[];
  const legend=has?`<div class="nasslegend"><span>none</span><i style="background:${useLeaflet()?'#ecfdf5':'#e2e8f0'};outline:1px solid ${useLeaflet()?'#065f46':'#cbd5e1'}"></i><span style="margin-left:8px">fewer acres</span>${NASS_SCALE.slice(1).map(c=>`<i style="background:${c}"></i>`).join('')}<span>more</span><i class="d" title="withheld"></i><span>withheld</span></div>`:'';
  let info='';
  if(!has)info=`<div class="note"><b>County crop data not loaded.</b> The map is ready for USDA NASS Quick Stats data. Run <code>tools/fetch_nass.py</code> with a free NASS API key to fill it in.</div>`;
  const countyInfo=(title,c,extra)=>{const list=c?Object.entries(c.crops).filter(([id,v])=>id!=='tablegrape'&&(v==='D'||v>0)).sort((a,b)=>(b[1]==='D'?-1:b[1])-(a[1]==='D'?-1:a[1])).slice(0,8):[];
    return`<h3 style="margin:4px 0 6px">${esc(title)}</h3><div class="tiny">${c&&c.cropland!=null?'Harvested cropland: <b>'+acres(c.cropland)+'</b>':''}</div>
     ${list.length?`<ul class="nasslist">${list.map(([id,v])=>`<li>${nassIco(id,26)}<span>${esc(nassCropName(id))}</span><b>${acres(v)}</b></li>`).join('')}</ul>`:'<p class="tiny">NASS lists none of the mapped crops here.</p>'}${extra||''}`};
  if(!has){}else if(sel){info=countyInfo(C[sel].name+' County',NASS.counties[sel])}
  else if(U.usSel&&window.NASS_US&&NASS_US.counties[U.usSel])info=countyInfo(usCountyName(U.usSel),NASS_US.counties[U.usSel],(U.loc&&ZONES[U.zone]&&ZONES[U.zone].us?`<div class="info">Planning here uses this spot’s NASA weather${U.soilInfo?', its USDA soil survey':''}${(U.usData||[]).length?', and USDA yields, prices, costs and irrigation for '+esc(U.loc.state):''}. Crop timing and fit come from the <b>${esc(ZONES[U.zone].name)}</b> region; crops without USDA price data use estimates — see Data &amp; method.</div>`:''));
  else if(U.usSel&&useLeaflet())info=`<h3 style="margin:4px 0 6px">${esc(usCountyName(U.usSel))}</h3><div class="note">${window.NASS_US?'NASS lists no crop acres for this county.':'Crop acres for counties outside California are not loaded yet (data/nass_us.js).'}</div>`
  else info='<p class="tiny">Pick a place, or click the map, to see which crops are grown in that county.</p>';
  const LF=useLeaflet();
  return`<div class="mapgrid${LF?' mapgrid-lf':''}"><div class="mapbox">${LF?'<div id="lmapslot"></div>':`<div class="mapzoom" role="group" aria-label="Map zoom"><button data-act="mapzoom" data-v="in" aria-label="Zoom in">＋</button><button data-act="mapzoom" data-v="out" aria-label="Zoom out" ${U.mapView?'':'disabled'}>－</button><button data-act="mapzoom" data-v="reset" aria-label="Show all of California" title="Show all of California" ${U.mapView?'':'disabled'}>⤢</button></div><span class="mapzlvl" id="mapzoomlvl">${(MAPW/mapVB()[2]).toFixed(1)}×</span>${mapSVG()}<div class="tiny mapnote">🛰 Street map, satellite view and NASA satellite layers appear when the site is run from your computer (they need an internet connection).</div>`}${legend}${sel?`<button class="btn sm alt mapcty" data-act="mapzoom" data-v="county">Zoom to ${esc(C[sel].name)} County</button>`:LF&&U.usSel&&!sel?`<button class="btn sm alt mapcty" data-act="mapzoom" data-v="uscounty">Zoom to ${esc(usCountyName(U.usSel))}</button>`:''}<div class="tiny" style="margin-top:4px">${LF?'Click to drop a pin · drag to move · scroll, ＋ － or pinch to zoom · switch Map / Satellite at top right · hover a county for its acres':'Scroll or use ＋ － to zoom · drag to move · click to drop a pin'}</div></div><div>
   ${has?`<label for="nasscrop" class="tiny">Shade counties by</label><select id="nasscrop">${opts.map(([v,l])=>`<option value="${v}" ${v===crop?'selected':''}>${esc(l)}</option>`).join('')}</select>`:''}
   ${info}
   <p class="tiny" style="margin-top:10px">${has?`Source: ${esc(NASS.source)} (fetched ${esc(NASS.fetched)})${window.NASS_US?'; other states: same census, fetched '+esc(NASS_US.fetched):''}. Colours use one scale for the whole country. ${esc(NASS.note)}`:'County outlines: US Census Bureau (via us-atlas).'}</p></div></div>`}

/* ---------- sections ---------- */
function secLocation(){
  return`<div class="card"><div class="row" style="align-items:center"><h2 style="margin:0"><span class="num">1</span> Location</h2><div style="flex:0 0 auto"></div></div>
  <input type="text" id="q" value="${esc(U.q)}" placeholder="Search any U.S. county or a California town, or type “lat, lon”" aria-label="Search location" autocomplete="off" style="margin-top:8px">
  <div id="res" class="results" ${U.matches.length?'':'hidden'}>${U.matches.map(g=>`<button data-act="${g.us?'pickus':'pick'}" data-id="${g.id}">${ico('ui','pin',18)} ${esc(g.name)} <span class="mute">· ${esc(g.county)}</span></button>`).join('')}</div>
  ${U.msgSetup?`<div class="warnb">${esc(U.msgSetup)}</div>`:''}
  ${U.loc?`<div class="loc">${ico('ui','pin',20)} <b>${esc(U.loc.name||'Pin')}${U.loc.county&&U.loc.county!==U.loc.name?', '+esc(U.loc.county):''}${U.loc.state?', '+esc(U.loc.state):''}</b> · ${ZONES[U.zone].name}${ZONES[U.zone].us?' region':''}</div>`:''}
  ${U.recState==='loading'?'<p class="tiny">Loading NASA weather…</p>':''}
  ${U.recState==='failed'?`<div class="warnb">${U.recMsg} ${U.nearby?`<button class="btn sm alt" data-act="nearby">Use ${esc(U.nearby.g.name)} data (${fmt(U.nearby.d)} km away)</button>`:''} ${!U.loc||!U.loc.state||U.loc.state==='CA'?`<button class="btn sm alt" data-act="synth">Use illustrative weather (not NASA)</button>`:''}</div>`:''}
  ${U.recState==='illustrative'?'<div class="warnb">Illustrative weather — not NASA data.</div>':''}
  ${U.rec&&U.recState==='ready'?`<div class="tiny">✔ ${esc(U.rec.source)} · ${U.rec.years[0]}–${U.rec.years[U.rec.years.length-1]}</div>`:''}
  ${U.soilInfo?`<div class="tiny">✔ Soil: <b>${esc(U.soilInfo.comp||U.soilInfo.name)}</b> (${esc(U.soilInfo.tex||'texture n/a')}${U.soilInfo.clay!=null?', '+Math.round(U.soilInfo.clay)+'% clay':''}${U.soilInfo.om!=null?', '+U.soilInfo.om.toFixed(1)+'% organic matter':''}), holds ${Math.round(U.soilInfo.awc)} mm of water in the top metre · USDA NRCS soil survey (SSURGO)</div>`:U.loc&&U.loc.state&&U.loc.state!=='CA'&&U.recState==='ready'?'<div class="tiny">Soil survey unavailable for this spot — using the region’s typical soil (editable in Settings).</div>':''}
  ${(U.usData||[]).map(d=>`<div class="tiny">✔ ${esc(d.t)}</div>`).join('')}
  <h3 style="margin:16px 0 8px">Crops by county <span class="tiny" style="font-weight:400">· USDA NASS</span></h3>${mapPanel()}</div>`}

function slotHTML(k,i,s){const cr=s.crop&&CROPS_G[s.crop],sel=U.sel&&U.sel.rot===k&&U.sel.i===i;
  const opts=[['','No cover'],...Object.keys(COVERS).map(c=>[c,COVERS[c].name])];
  return`<div class="slot ${sel?'sel':''}" draggable="true" data-drag="slot:${k}:${i}" data-slot="${k}:${i}" tabindex="0" role="button" aria-label="Year ${i+1}: ${cr?cr.name:'empty'}" aria-pressed="${sel}">
    <div class="yr">${(()=>{const r=U.rots[k],a=r.slice(0,i).reduce((x,q)=>x+(q.yrs||1),0)+1,b=a+(s.yrs||1)-1;return a===b?`Yr ${a}`:`Yr ${a}–${b}`})()}</div><div class="em">${cropIco(s.crop,50)}${s.cover?`<span class="cvb" title="${esc(COVERS[s.cover].name)} winter cover">${ico('cover',s.cover,22)}</span>`:''}</div><div class="nm">${cr?cr.name:'Fallow'}</div>
    <select class="cvsel" data-cv="${k}:${i}" aria-label="Winter cover year ${i+1}">${opts.map(([v,l])=>{const bad=v&&coverConflict(s.crop,v,U.zone);return`<option value="${v}" ${s.cover===v?'selected':''} ${bad?'disabled':''}>${l}</option>`}).join('')}</select>
    <div class="ctl"><button data-act="mvleft" data-rot="${k}" data-i="${i}" aria-label="Earlier" ${i===0?'disabled':''}>◀</button><button data-act="mvright" data-rot="${k}" data-i="${i}" aria-label="Later" ${i===U.rots[k].length-1?'disabled':''}>▶</button><button data-act="rmslot" data-rot="${k}" data-i="${i}" aria-label="Remove">✕</button></div></div>`}
function tagsHTML(rot){if(!rot.length)return'';const f=rotationFacts(rot,U.zone);return f.unmodeled?`<span class="tag warn">⚠ unmodeled crop</span>`:''}
function editorHTML(k){const rot=U.rots[k],sel=U.sel&&U.sel.rot===k?U.sel:null,q=U.cq[k],sug=q?cropMatches(q):[],rec=!q?cropMatches(''):[];
  return`<div class="rotcard" style="--c:${RK[k].c}"><div class="row" style="align-items:center"><h3 style="margin:0;color:${RK[k].c}">${RK[k].n} rotation</h3>
   <div style="flex:0 0 auto;display:flex;gap:6px">${k==='prop'?`<button class="btn sm" data-act="improve" ${U.busy||!U.rots.cur.length?'disabled':''} title="Small, tested changes to your current rotation">${U.busy&&U.busyKind==='improve'?'Improving…':'✨ Improve my current rotation'}</button><button class="btn sm alt" data-act="usesug" ${U.busy?'disabled':''}>${U.busy&&U.busyKind==='search'?'Searching…':'Suggest a rotation'}</button>`:''}<select data-preset="${k}" aria-label="Example rotation" style="width:auto"><option value="">Example…</option>${Object.keys(ROT_PRESETS).map(p=>`<option value="${p}">${ROT_PRESETS[p][0]}</option>`).join('')}</select></div></div>
  ${tagsHTML(rot)?`<div>${tagsHTML(rot)}</div>`:''}
  <div class="slots">${rot.map((s,i)=>slotHTML(k,i,s)).join('')}<button class="slot add" data-act="focussearch" data-rot="${k}" data-drag-add="${k}" aria-label="Add a year">＋</button></div>
  <input type="text" id="cq-${k}" data-cq="${k}" value="${esc(q)}" placeholder="${sel?`Replace year ${sel.i+1} with…`:'Add a crop (try “tom”, “almond”, “native”)'}" aria-label="Search crops" autocomplete="off">
  ${q?`<div class="results">${sug.length?sug.map(c=>sugBtn(c,k)).join(''):'<div style="padding:8px" class="mute">No match</div>'}</div>`:''}
  ${U.msg[k]?`<div class="note">${esc(U.msg[k])}</div>`:''}${scheduleHTML(k)}</div>`}
function sugPanel(){const r=U.sugRes;if(!r)return'';if(!r.list.length)return'<div class="note">No better rotation found for this location and priority.</div>';
  const emo=rot=>rot.map(s=>`<span class="sq">${cropIco(s.crop,30)}${s.cover?`<span class="cvb sm">${ico('cover',s.cover,14)}</span>`:''}</span>`).join('<span class="arr">›</span>');
  const dl=v=>v==null?'':`<span class="${v>=0?'up':'dn'}">${sgn(v,0)}</span>`;
  return`<div class="sugbox"><div class="tiny">Best of <b>${fmt(r.tested)}</b> rotations tested on ${esc(U.loc.name||'this')} NASA weather (${U.priority==='output'?'income':PRI[U.priority].toLowerCase()} first, income kept close to current):</div>${r.list.map((x,i)=>`<div class="cand"><span class="seq">${emo(x.rot)}</span><span class="tiny">${SCORE_CATS.filter(c=>['soil','water','income','resil'].includes(c[0])).map(c=>ico('cat',c[0],16)+dl(x.vs[c[0]])).join(' ')}</span><b style="color:${scol(x.ov)}">${Math.round(x.ov)}</b><button class="btn sm ${U.rots.prop&&JSON.stringify(U.rots.prop)===JSON.stringify(x.rot)?'':'alt'}" data-act="usecand" data-i="${i}">${JSON.stringify(U.rots.prop)===JSON.stringify(x.rot)?'In use':'Use'}</button></div>`).join('')}<div class="tiny">Numbers = change vs current. Searched in ${(r.ms/1000).toFixed(1)}s.</div></div>`}
function impPanel(){const r=U.impRes;if(!r)return'';
  if(!r.rot)return`<div class="note">Your current rotation already scores best among ${fmt(r.tested)} small changes tested on ${esc(U.loc.name||'this')} NASA weather (${PRI[U.priority].toLowerCase()} priority). Try “Suggest a rotation” for a completely different sequence.</div>`;
  const emo=rot=>rot.map(s=>`<span class="sq">${cropIco(s.crop,30)}${s.cover?`<span class="cvb sm">${ico('cover',s.cover,14)}</span>`:''}</span>`).join('<span class="arr">›</span>');
  const dl=v=>v==null?'':`<span class="${v>=0?'up':'dn'}">${sgn(v,0)}</span>`;
  return`<div class="sugbox impbox"><div class="imphead"><div><div class="eyebrow" style="margin:0">Improved rotation</div><div class="tiny">Built from your current rotation · loaded into <b style="color:${RK.prop.c}">Proposed</b> above</div></div>
   <div class="impscore"><span style="color:${scol(r.curOv)}">${Math.round(r.curOv)}</span><span class="arr">→</span><b style="color:${scol(r.ov)}">${Math.round(r.ov)}</b><small>overall</small></div></div>
   <div class="cand"><span class="seq">${emo(U.rots.cur)}</span><span class="tiny">current</span></div>
   <div class="cand"><span class="seq">${emo(r.rot)}</span><span class="tiny">improved</span></div>
   <div class="impfx">${SCORE_CATS.map(c=>r.vs[c[0]]==null?'':`<span class="tag">${ico('cat',c[0],14)} ${c[2]} ${dl(r.vs[c[0]])}</span>`).join('')}</div>
   <ol class="impsteps">${r.steps.map(st=>`<li><b>${esc(st.text)}</b><span class="tiny">${dl(st.gain)} overall${st.fx.length?' · '+st.fx.map(x=>`${x.l} ${dl(x.d)}`).join(', '):''}</span></li>`).join('')}</ol>
   <div class="tiny">Scored with your ${PRI[U.priority].toLowerCase()} priority (change it in Settings, then improve again). ${fmt(r.tested)} variations tested on ${esc(U.loc.name||'this')} NASA weather; income kept within 5 points of current; every crop you grow is kept. Changes vs current are measured on 12 fresh weather sequences.</div></div>`}
function secRotations(){return`<div class="card"><h2><span class="num">3</span> Rotations</h2>${editorHTML('cur')}${liveMode()?`<p class="tiny livenote"><b>Decide as I go:</b> plan Current in full now. Proposed only needs its first crop (years 1–${ivl()}); you choose each next crop during the simulation. Any later Proposed crops below are only offered as suggestions.</p>`:''}${editorHTML('prop')}${issuesHTML('prop')}${impPanel()}${sugPanel()}</div>`}
function secRun(){const can=U.rots.cur.length&&U.rots.prop.length;
  return`<div class="card"><h2><span class="num">2</span> Settings</h2>
  <div class="row" style="align-items:flex-end"><div class="sl"><div class="t"><label for="hz">Years</label><b>${U.horizon}</b></div><input type="range" id="hz" min="3" max="20" value="${U.horizon}" style="width:100%"></div>
  <div class="acset"><label for="acres" class="tiny">Farm size (acres)</label><input type="number" id="acres" class="acresIn" min="1" max="100000" step="1" value="${U.acres}"></div>
  <div class="prio"><div class="tiny">Priority</div><div class="seg one">${Object.keys(PRI).map(k=>`<button data-act="pri" data-v="${k}" class="${U.priority===k?'on':''}">${PRI[k]}</button>`).join('')}</div></div></div>
  <details id="moreSet" ${U.moreOpen?'open':''}><summary class="tiny">More settings</summary><div class="grid2" style="margin-top:8px"><div>
   <label for="soil" class="tiny">Soil texture</label><select id="soil">${Object.keys(SOILG).map(s=>`<option value="${s}" ${s===U.soil?'selected':''}>${s==='USDA soil survey'&&U.soilInfo?'This spot’s soil — '+esc(U.soilInfo.comp||'')+' ('+esc(U.soilInfo.tex||'')+')':s}</option>`).join('')}</select>
   <label for="alloc" class="tiny">Water limit ${U.alloc}%</label><input type="range" id="alloc" min="50" max="120" step="5" value="${U.alloc}" style="width:100%">
   <label for="fert" class="tiny">Fertilizer</label><select id="fert">${Object.keys(FERT).map(k=>`<option value="${k}" ${U.mg.fert===k?'selected':''}>${FERT[k].name}</option>`).join('')}</select>
   <label for="irrig" class="tiny">Irrigation</label><select id="irrig">${[['full','Full'],['deficit','Deficit 80%'],['drought','Drought-saver 60%']].map(([k,n])=>`<option value="${k}" ${U.mg.irrig===k?'selected':''}>${n}</option>`).join('')}</select></div>
   <div><div class="tiny">Equipment</div>${Object.keys(EQUIP).map(k=>{const e=EQUIP[k],o=U.mg.equip.includes(k);return`<label class="eq ${o?'own':''}" title="${esc(e.desc)}"><input type="checkbox" data-eq="${k}" ${o?'checked':''}><span class="e">${ico('equip',k,30)}</span><div><b>${e.name}</b> ${money(e.price)}</div></label>`}).join('')}</div></div></details>
  ${planModeHTML()}${whatIfBar()}</div>`}
/* step 3 page: the two rotations, then Run (Settings is step 2) */
function secPlan(){const can=U.rots.cur.length&&U.rots.prop.length;
  return`${secRotations()}<div class="card runcard"><button class="btn big" data-act="run" ${can?'':'disabled'}>▶ Run simulation</button>
  <span class="tiny">${can?(liveMode()?`You'll choose the Proposed crop every ${ivl()} year${ivl()>1?'s':''} as the years play.`:`Runs both rotations for ${U.horizon} years.`):'Add at least one crop to each rotation first.'}</span></div>`}

/* ---------- scoreboard (appears after Run, steps through the years) ---------- */
function yieldCol(y){if(y==null)return'#e5e5e5';const t=clamp((y-.4)/.6,0,1);return`hsl(${Math.round(t*115)},55%,${86-t*18}%)`}
function scoresAtT(k,t=U.t){const reps=U.sim.E[k].first.slice(0,t);return avgScores(reps,U.zone)}
/* ---------- field preview: draws what the field would look like from this year's model outputs ---------- */
function fieldsHTML(E,S,t,below){
  const cap=k=>{const r=E[k].first[t-1],row=r.rows[0],cr=r.slot.crop&&CROPS_G[r.slot.crop];if(!cr)return'Fallow';
    const lim=row.limits&&row.limits[0]?` · main limit: ${row.limits[0][0].toLowerCase()} −${fmt(row.limits[0][1]*100)}%`:'';
    return`${cropIco(cr.id,20)} <b>${cr.name}</b>${r.slot.cover?' + '+ico('cover',r.slot.cover,16)+' '+COVERS[r.slot.cover].name+' cover':''} · yield ${row.unmodeled?'n/a':row.Y==null?'–':fmt(row.Y*100)+'%'}${lim}`};
  return`<div class="fieldsbox"><h3 style="margin:10px 0 4px">${ico('ui','sprout',24)} Your field — year ${t}</h3><div class="fields">${['cur','prop'].map(k=>`<figure><div class="fh" style="color:${RK[k].c}"><b>${RK[k].n}</b></div>${fieldSVG(k,S[k],E,t)}<figcaption class="tiny">${cap(k)}</figcaption>${harvestLine(k,t)}${below?below(k):''}</figure>`).join('')}</div>
  <details class="legend"><summary class="tiny">What the picture shows</summary><div class="tiny">Drag the field to turn it in 3D, scroll or pinch to zoom, right-drag (or shift-drag) to pan, double-click or ⟲ to reset — both fields turn together. Illustration of the model’s numbers, not a photo or forecast. Sky = that year’s rain · bigger, greener plants = higher yield · gaps = pest loss · cracks = water shortage · green strips = winter cover · darker soil = higher soil score · blue band on the cut-away sides = NASA soil wetness · pale lines on the sides = roots.</div></details></div>`}
function simData(t=U.t){const E=U.sim.E,H=U.horizon,rec=simRec(),idx=E.cur.idx,S={cur:scoresAtT('cur',t),prop:scoresAtT('prop',t)},ov={cur:overallOf(S.cur,U.priority),prop:overallOf(S.prop,U.priority)};
  return{E,H,t,rec,idx,W:weightsFor(U.priority),S,ov,done:t>=H,pid:idx.map(i=>rec.annualP[i]/rec.meanP)}}
function scoreTable(D){
  const cell=(v,ar='')=>v==null?'<td class="sc">–</td>':`<td class="sc"><b style="color:${scol(v)}">${Math.round(v)}</b>${ar}<span class="mb"><i style="width:${v}%;background:${scol(v)}"></i></span></td>`;
  const best=D.ov.prop==null||D.ov.cur==null?null:D.ov.prop>D.ov.cur+1?'prop':D.ov.cur>D.ov.prop+1?'cur':null;
  return`<table class="sb"><tr><th></th><th style="color:${RK.cur.c}">Current</th><th style="color:${RK.prop.c}">Proposed</th></tr>
  ${SCORE_CATS.map(([c,e,l,d])=>`<tr title="${esc(d)}"><th>${ico('cat',c,24)} ${l}${D.W[c]>.3?' ★':''}</th>${cell(D.S.cur&&D.S.cur[c],trendArrow('cur',c))}${cell(D.S.prop&&D.S.prop[c],trendArrow('prop',c))}</tr>`).join('')}
  <tr class="tot"><th>OVERALL</th>${['cur','prop'].map(k=>`<td class="sc">${D.ov[k]==null?'–':`<b style="font-size:24px;color:${scol(D.ov[k])}">${Math.round(D.ov[k])}</b>${best===k?'<div class="tiny">★ higher</div>':''}`}</td>`).join('')}</tr></table>`}

/* one rotation's scoreboard, shown under its own field picture (proposed also shows the change vs current) */
function sideScore(D,k){
  const other=k==='prop'?'cur':null,best=D.ov.prop==null||D.ov.cur==null?null:D.ov.prop>D.ov.cur+1?'prop':D.ov.cur>D.ov.prop+1?'cur':null;
  const dl=(a,b)=>other&&a!=null&&b!=null&&Math.round(a-b)!==0?`<span class="sdl ${a>=b?'up':'dn'}">${sgn(a-b,0)}</span>`:'';
  const cell=c=>{const v=D.S[k]&&D.S[k][c];return v==null?'<td class="sc">–</td>':`<td class="sc"><span class="sv"><b style="color:${scol(v)}">${Math.round(v)}</b>${dl(v,other&&D.S[other]&&D.S[other][c])}</span><span class="mb"><i style="width:${v}%;background:${scol(v)}"></i></span></td>`};
  return`<table class="sb sbside" style="--c:${RK[k].c}"><tr><th colspan="2" style="color:${RK[k].c}">${RK[k].n} · scoreboard</th></tr>
  ${SCORE_CATS.map(([c,e,l,d])=>`<tr title="${esc(d)}"><th>${ico('cat',c,22)} ${l}${D.W[c]>.3?' ★':''}</th>${cell(c)}</tr>`).join('')}
  <tr class="tot"><th>OVERALL</th><td class="sc">${D.ov[k]==null?'–':`<span class="sv"><b style="font-size:24px;color:${scol(D.ov[k])}">${Math.round(D.ov[k])}</b>${dl(D.ov[k],other&&D.ov[other])}</span>${best===k?'<div class="tiny">★ higher</div>':''}`}</td></tr></table>`}

/* page 4: each field picture with its own scoreboard underneath, stepping through the years */
function simPage(){
  const D=simData(),{H,t,done}=D;
  return`<div class="card score" id="score"><div class="row" style="align-items:center"><h2>${ico('crop','wheat',30)} Simulation</h2><div class="ctlbar"><button class="btn sm alt" data-act="tprev" ${t<=1?'disabled':''} aria-label="Previous year">◀</button><button class="btn sm" data-act="tplay">${U.timer?'⏸ Pause':done?'↻ Replay years':'▶ Play'}</button><button class="btn sm alt" data-act="tnext" ${done||t>=decidedYrs()?'disabled':''} aria-label="Next year">▶</button><b>Year ${t} / ${H}</b></div></div>
  ${showPick()?pickPanel():''}
  <input type="range" id="tr" min="1" max="${H}" value="${t}" style="width:100%" aria-label="Year">${whatIfBar()}
  <div class="simstack">${fieldsHTML(D.E,D.S,t,k=>sideScore(D,k))}<div class="tiny" style="margin-top:8px">Scores are 0–100, higher is better · ★ = your priority · green/red numbers on Proposed = change vs Current · hover a row for its formula</div></div></div>`}

/* page 5: whole-run summary (all years), outcome, exports */
function summaryPage(){
  const D=simData(U.horizon),{E,rec,idx,pid,S}=D,t=U.horizon,ks=['cur','prop'];
  const strip=`<div class="yrs">${idx.map((i,j)=>`<div class="yc"><div class="wb"><i style="height:${clamp(pid[j]/1.8*100,6,100)}%;background:${pid[j]<.7?'#c87a1a':pid[j]>1.3?'#1b6f8c':'#8aa7b5'}"></i></div><small>${rec.years[i]}</small></div>`).join('')}</div>`;
  const swStrip=rec.Sw?`<div class="lane"><div class="ln" title="NASA MERRA-2 root-zone soil wetness in March (0 = dry, 1 = saturated)"><b>Soil wet</b></div><div class="yrs">${idx.map((i,j)=>{const v=rec.Sw[i][2];return`<div class="yc" title="Year ${j+1}: March root-zone wetness ${v.toFixed(2)} (NASA)"><div class="wb"><i style="height:${clamp(v*100,6,100)}%;background:#8b6a43"></i></div><small>${v.toFixed(2)}</small></div>`}).join('')}</div></div>`:'';
  const lane=k=>`<div class="lane"><div class="ln" style="color:${RK[k].c}"><b>${RK[k].n}</b></div><div class="yrs">${E[k].first.map((r,j)=>{const cr=r.slot.crop&&CROPS_G[r.slot.crop],w=r.rows[0];return`<div class="yc" style="background:${w.unmodeled?'#e9e2f7':yieldCol(w.Y)}" title="Year ${j+1}: ${cr?cr.name:'fallow'}${w.Y!=null?' · yield '+fmt(w.Y*100)+'%':''}">${cropIco(r.slot.crop,26)}${r.slot.cover?`<span class="cvb sm">${ico('cover',r.slot.cover,12)}</span>`:''}<small>${w.unmodeled?'n/a':w.Y==null?'–':fmt(w.Y*100)+'%'}</small></div>`}).join('')}</div></div>`;
  const o=outcome(S),pP=E.prop.ov.all.filter((v,i)=>v!=null&&E.cur.ov.all[i]!=null&&v>E.cur.ov.all[i]).length/U.N;
  return`<div class="card"><h2>Summary</h2><p class="tiny" style="margin:2px 0 8px">Final scores after ${t} years, and what happened each year.</p>
  <div class="final"><span class="badge">${o.cat}</span> <span class="tiny">${esc(o.why)}</span><div class="tiny" style="margin-top:4px">Proposed beats Current in <b>${fmt(pP*100)}%</b> of ${U.N} other weather sequences.</div></div>
  ${scoreTable(D)}
  <h3>Year by year</h3>${ks.map(lane).join('')}${liveMode()&&U.dec.length?`<p class="tiny">Proposed was chosen as the years played, every ${ivl()} year${ivl()>1?'s':''}: ${U.dec.map((d,i)=>{const a=i*ivl()+1,b=Math.min(U.horizon,a+ivl()-1);return`${a===b?'Yr '+a:'Yr '+a+'–'+b} ${esc(CROPS_G[d.crop].name.split(' (')[0])}${d.cover?' + '+esc(COVERS[d.cover].name)+' cover':''}`}).join(' → ')}.</p>`:''}
  <div style="margin-top:12px"><button class="btn sm" data-act="export-json">⬇ JSON</button> <button class="btn sm alt" data-act="export-csv">⬇ CSV</button> <button class="btn sm alt" data-act="replay">↻ Replay the simulation</button> <button class="btn sm alt" data-act="newweather">Try new weather</button></div>
  <div class="tiny" style="margin-top:8px">0–100, higher is better · ★ = your priority · ↑ ↗ → ↘ ↓ = how each score moves over the years · <button class="lnk2" id="evBtn2">model &amp; limits</button>${confHTML()}</div>${whatIfBar()}</div>${climateCard()}${harvestTable(E)}${tradeCard()}${nasaEvidence()}`}

/* ---------- paging ---------- */
const PAGES=[['1','Place'],['2','Settings'],['3','Rotations'],['4','Simulation'],['5','Summary']];
function canGo(p){if(p===1)return true;if(!ready())return false;if(p===2)return true;if(p===3)return true;if(p===5&&liveMode()&&U.sim&&decidedYrs()<U.horizon)return false;return!!U.sim}
function gotoPage(p){if(!canGo(p))return;stop();U.page=p;render();window.scrollTo(0,0)}
function stepper(){return`<nav class="stepper" aria-label="Steps">${PAGES.map(([n,l],ix)=>{const p=+n,on=U.page===p,done=p<U.page&&canGo(p);return`<button class="st ${on?'on':''} ${done?'done':''}" data-act="goto" data-v="${p}" ${canGo(p)?'':'disabled'} ${on?'aria-current="step"':''}><b>${done?'✓':ix+1}</b><span>${l}</span></button>`}).join('')}</nav>`}
function navBar(){const p=U.page,back=p>1?`<button class="btn alt" data-act="goto" data-v="${p-1}">← Back</button>`:'<span></span>';
  const nxt={1:['Next: Settings →',2],2:['Next: Rotations →',3],4:['See summary →',5]}[p];
  const right=nxt?`<button class="btn" data-act="goto" data-v="${nxt[1]}" ${canGo(nxt[1])?'':'disabled'}>${nxt[0]}</button>`:p===5?`<button class="btn alt" data-act="startover">Start a new comparison</button>`:'<span></span>';
  return p===3?`<div class="navbar">${back}<span></span></div>`:`<div class="navbar">${back}${right}</div>`}

function outcome(S){const c=S.cur,p=S.prop,key={soil:'soil',water:'water',output:'income',resil:'resil'}[U.priority],lab={soil:'Soil Builder',water:'Water Saver',income:'Harvest Booster',resil:'Resilience Builder'}[key];
  if(!c||!p)return{cat:'Insufficient evidence',why:'Outputs unavailable (unmodeled crop).'};
  if(JSON.stringify(U.rots.cur)===JSON.stringify(U.rots.prop))return{cat:'Same rotation',why:'Both rotations are identical.'};
  const dp=p[key]-c[key],di=p.income-c.income,nm=SCORE_CATS.find(x=>x[0]===key)[2];
  if(dp>=5&&di>=-5)return{cat:lab,why:`${nm} ${sgn(dp,0)}, income ${sgn(di,0)}.`};
  if(dp>=5)return{cat:'Tradeoff',why:`${nm} ${sgn(dp,0)} but income ${sgn(di,0)}.`};
  if(dp<=-5)return{cat:'Worse on your priority',why:`${nm} ${sgn(dp,0)}.`};
  return{cat:'No clear difference',why:`${nm} ${sgn(dp,0)} (within ±5).`}}

/* ---------- render ---------- */
function render(){
  const a=document.getElementById('app'),fid=document.activeElement&&document.activeElement.id,pos=window.scrollY;
  if(U.page>1&&!canGo(U.page))U.page=ready()?2:1;
  const body={1:secLocation,2:secRun,3:secPlan,4:simPage,5:summaryPage}[U.page]();
  a.innerHTML=`<div class="narrow ${U.page===4?'wide':''}">${stepper()}${body}${navBar()}</div>`;
  a.classList.toggle('wide',U.page===4);document.body.classList.toggle('nohero',U.page!==1);const hero=document.querySelector('.hero');if(hero)hero.style.display=U.page===1?'':'none';
  if(fid&&(fid==='q'||fid.startsWith('cq-'))){const q=document.getElementById(fid);if(q){q.focus();q.setSelectionRange(q.value.length,q.value.length)}}
  window.scrollTo(0,pos);
  wireMap();
  const e2=document.getElementById('evBtn2');if(e2)e2.onclick=showEvidence}
function change(){reset();render()}
function simulate(){const rots={cur:U.rots.cur,prop:liveMode()?liveRot():U.rots.prop};U.sim={E:ensembleRotations(rots,setup(),simRec(),U.mg,U.N)};if(climOn())U.sim.base=ensembleRotations(rots,setup(),U.rec,U.mg,U.N)}
function runSim(){reset();U.pick=null;if(liveMode()){const f=planYears()[0];U.dec=[{crop:f.crop,cover:f.cover||null}]}else U.dec=[];
  simulate();U.t=1;U.page=4;render();window.scrollTo(0,0);play()}
function play(){stop();if(!U.sim)return;if(U.t>=U.horizon)U.t=1;U.timer=setInterval(()=>{if(U.t>=U.horizon){stop();render();return}if(needPick()){stop();render();return}U.t++;render()},1600);render()}

/* ---------- exports ---------- */
function download(name,text,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}
function exportJSON(){const E=U.sim.E,S={cur:scoresAtT('cur'),prop:scoresAtT('prop')};download('rotate-and-thrive-run.json',JSON.stringify({app:'Rotate & Thrive',version:4,exported:new Date().toISOString(),setup:setup(),management:U.mg,location:U.loc,dataStatus:dataStatus(),weather:{source:U.rec.source,sha256:U.rec.sha,exampleSourceYears:E.cur.idx.map(i=>U.rec.years[i]),resamplings:U.N},rotations:{current:U.rots.cur,proposed:U.rots.prop},scoresFinalYear:S,ensemble:Object.fromEntries(['cur','prop'].map(k=>[k,{overall:E[k].ov,categories:E[k].cat,numbers:E[k].num}])),outcome:outcome(S),caveats:ASSUMPTIONS},null,1),'application/json')}
function exportCSV(){const E=U.sim.E,L=['rotation,year,source_year,crop,cover,yield_fraction,net_usd_per_acre,water_af_per_acre'];['cur','prop'].forEach(k=>E[k].first.forEach((r,j)=>{const w=r.rows[0];L.push([k,j+1,r.srcYear,r.slot.crop,r.slot.cover||'',w.Y==null?'':w.Y.toFixed(3),w.net==null||w.unmodeled?'':(w.net/PLOT_AC).toFixed(0),w.pull==null?'':(w.pull/304.8).toFixed(3)].join(','))}));download('rotate-and-thrive-run.csv',L.join('\n'),'text/csv')}
function showEvidence(){const r=U.rec;document.getElementById('evBody').innerHTML=`<h2>Model &amp; limits</h2><ul>${dataStatus().map(([a,c,t])=>`<li><b>${a}</b> (${c==='ok'?'available':c==='bad'?'unavailable':'partial'}): ${esc(t)}</li>`).join('')}</ul>${r?`<p class="tiny">${esc(r.source)}${r.retrieved?', retrieved '+r.retrieved:''}. ${esc((window.WEATHER_META||{}).note||'')}</p>`:''}<h3>Scores</h3><ul>${SCORE_CATS.map(([k,e,l,d])=>`<li><b>${ico('cat',k,18)} ${l}.</b> ${esc(d)}</li>`).join('')}<li><b>Overall.</b> 40% your priority + 12% each other.</li></ul><h3>Model (educational, unvalidated)</h3><ul>${ASSUMPTIONS.map(([a,t])=>`<li><b>${a}.</b> ${esc(t)}</li>`).join('')}</ul><p>One representative 40-acre field. No farm advisor has reviewed this.</p>`;document.getElementById('ev').showModal()}

/* ---------- actions ---------- */
function addCrop(k,id,at){const rot=U.rots[k];U.msg[k]='';reset();
  if(U.sel&&U.sel.rot===k&&at==null)at=U.sel.i;
  if(at!=null&&rot[at]){const s=rot[at];s.crop=id;const cf=coverConflict(id,s.cover,U.zone);if(cf){s.cover=null;U.msg[k]='Cover removed — overlaps crop.'}}else rot.push({crop:id,cover:null,yrs:holdOf(k)||1});
  if(rot.length>20){rot.length=20;U.msg[k]='Max 20 years.'}U.sel=null;U.cq[k]='';render()}
document.addEventListener('click',e=>{
  const ctl=e.target.closest('[data-act]');
  if(!ctl){const s=e.target.closest('[data-slot]');if(s&&!e.target.closest('select')){const[k,i]=s.dataset.slot.split(':');U.sel=U.sel&&U.sel.rot===k&&U.sel.i===+i?null:{rot:k,i:+i};render();const inp=document.getElementById('cq-'+k);inp&&inp.focus()}return}
  const act=ctl.dataset.act,v=ctl.dataset.v,id=ctl.dataset.id,k=ctl.dataset.rot,i=+ctl.dataset.i;
  const H={
   pick:()=>{const g=GAZ.find(x=>x.id===id);U.q=g.name;loadLoc({...g})},pickus:()=>{let l0=null;LM.us.eachLayer(l=>{if(String(l.feature.id)===id)l0=l});if(!l0)return;const c=l0.getBounds().getCenter();U.q=l0.feature.properties.name+' County';loadLoc({name:U.q,lat:+c.lat.toFixed(3),lon:+c.lng.toFixed(3)})},mapzoom:()=>{if(useLeaflet()){if(v==='county'){const f=locCounty();f&&zoomLeafletToCounty(f)}if(v==='uscounty'&&LM.us)LM.us.eachLayer(l=>{if(String(l.feature.id)===U.usSel)LM.map.flyToBounds(l.getBounds(),{padding:[24,24],duration:.6})});return}const[x,y,w,h]=mapVB();if(v==='in')zoomAt(x+w/2,y+h/2,.6);else if(v==='out')zoomAt(x+w/2,y+h/2,1/.6);else if(v==='county'){const f=locCounty();f&&zoomToCounty(f)}else U.mapView=null;render()},nearby:useNearby,synth:useSynthetic,
   pri:()=>{U.priority=v;change()},
   addcrop:()=>addCrop(k,id),focussearch:()=>{U.sel=null;const inp=document.getElementById('cq-'+k);inp&&inp.focus()},
   mvleft:()=>{const r=U.rots[k];[r[i-1],r[i]]=[r[i],r[i-1]];U.sel=null;change()},mvright:()=>{const r=U.rots[k];[r[i+1],r[i]]=[r[i],r[i+1]];U.sel=null;change()},
   rmslot:()=>{U.rots[k].splice(i,1);U.sel=null;change()},
   usesug:runSearch,improve:runImprove,usecand:()=>{const keep=U.sugRes;U.rots.prop=copy(keep.list[i].rot);U.sel=null;change();U.sugRes=keep;render()},
   run:runSim,tplay:()=>{if(U.timer){stop();render()}else play()},tprev:()=>{stop();U.t=Math.max(1,U.t-1);render()},tnext:()=>{stop();U.t=Math.min(decidedYrs(),U.t+1);render()},
   pmode:()=>{U.planMode=v;change()},ivl:()=>{U.interval=+v;change()},pkgo:pickGo,pkplan:pickPlan,
   goto:()=>gotoPage(+v),startover:()=>{reset();U.page=1;render();window.scrollTo(0,0)},
   replay:()=>{U.t=1;U.page=4;window.scrollTo(0,0);play()},newweather:()=>{U.seed+=1000;runSim()},
   'export-json':exportJSON,'export-csv':exportCSV};
  if(H[act])H[act]()});
document.addEventListener('keydown',e=>{
  if(e.target.matches&&e.target.matches('[data-slot]')&&(e.key==='Enter'||e.key===' ')){e.preventDefault();const[k,i]=e.target.dataset.slot.split(':');U.sel=U.sel&&U.sel.rot===k&&U.sel.i===+i?null:{rot:k,i:+i};render();const inp=document.getElementById('cq-'+k);inp&&inp.focus();return}
  if(e.target.dataset&&e.target.dataset.cq){const k=e.target.dataset.cq;if(e.key==='Enter'){const m=cropMatches(U.cq[k])[0];if(m){e.preventDefault();addCrop(k,m.id)}}if(e.key==='Escape'){U.cq[k]='';U.sel=null;render()}}
  if(e.target.id==='q'&&e.key==='Enter'){const m=search(U.q)[0];if(m){e.preventDefault();if(m.us){const b=document.querySelector(`[data-act=pickus][data-id="${m.id}"]`);b&&b.click()}else{U.q=m.name;loadLoc({...m})}}}});
document.addEventListener('input',e=>{const t=e.target;
  if(t.id==='q'){U.q=t.value;const ll=parseLL(U.q);U.matches=ll?[]:search(U.q);render();if(ll){clearTimeout(U._t);U._t=setTimeout(()=>loadLoc({name:'Typed coordinates',...ll}),700)}}
  if(t.dataset&&t.dataset.cq){U.cq[t.dataset.cq]=t.value;render()}
  if(t.id==='tr'){stop();U.t=Math.min(+t.value,decidedYrs());render()}
  if(t.id==='pkcrop'||t.id==='pkcov'){const c=document.getElementById('pkcrop'),v=document.getElementById('pkcov');U.pick={d:nextIdx(),crop:c.value,cover:v.value||null};render()}
  if(t.id==='hz'){U.horizon=+t.value;change()}
  if(t.id==='soil'){U.soil=t.value;change()}if(t.id==='alloc'){U.alloc=+t.value;change()}
  if(t.id==='fert'){U.mg.fert=t.value;change()}if(t.id==='irrig'){U.mg.irrig=t.value;change()}
  if(t.dataset&&t.dataset.eq){const a=U.mg.equip,k=t.dataset.eq,p=a.indexOf(k);t.checked?(p<0&&a.push(k)):(p>=0&&a.splice(p,1));change()}});
document.addEventListener('change',e=>{const t=e.target;if(t.id==='nasscrop'){U.nassCrop=t.value;render();return}
  if(t.dataset&&t.dataset.cv){const[k,i]=t.dataset.cv.split(':');U.rots[k][+i].cover=t.value||null;change()}
  if(t.dataset&&t.dataset.preset&&t.value){const k=t.dataset.preset;U.rots[k]=copy(ROT_PRESETS[t.value][1](U.zone));U.sel=null;change()}});
document.addEventListener('dragstart',e=>{const d=e.target.closest('[data-drag]');if(d){e.dataTransfer.setData('text/plain',d.dataset.drag);e.dataTransfer.effectAllowed='copyMove'}});
document.addEventListener('dragover',e=>{const t=e.target.closest('[data-slot],[data-drag-add]');if(t){e.preventDefault();t.classList.add('over')}});
document.addEventListener('dragleave',e=>{const t=e.target.closest('[data-slot],[data-drag-add]');if(t)t.classList.remove('over')});
document.addEventListener('drop',e=>{const t=e.target.closest('[data-slot],[data-drag-add]');if(!t)return;e.preventDefault();const tok=e.dataTransfer.getData('text/plain');if(!tok)return;const p=tok.split(':');
  const dest=t.dataset.slot?t.dataset.slot.split(':'):[t.dataset.dragAdd,null];
  if(p[0]==='crop')addCrop(dest[0],p[1],dest[1]==null?null:+dest[1]);
  else if(p[0]==='slot'&&p[1]===dest[0]){const r=U.rots[p[1]],from=+p[2],to=dest[1]==null?r.length-1:+dest[1];const[m]=r.splice(from,1);r.splice(to,0,m);U.sel=null;change()}});
document.getElementById('evBtn').onclick=showEvidence;
function showCredits(){const L=Object.entries(window.IMGS||{}).sort((a,b)=>a[0].localeCompare(b[0]));document.getElementById('evBody').innerHTML=`<h2>Photo credits</h2><p class="tiny">Photographs are from Wikimedia Commons under the free licenses shown; they illustrate each crop or practice in general and are not images of your field. Charts, field overlays and the soil cutaway are drawn from the model.</p><ul class="credits">${L.map(([k,m])=>`<li><b>${esc(k)}</b> — <a href="${esc(m.page||'#')}" target="_blank" rel="noopener">${esc((m.title||'').replace(/^File:/,''))}</a> · ${esc(m.artist||'unknown')} · ${esc(m.license||'')}</li>`).join('')||'<li>No photos installed.</li>'}</ul>`;document.getElementById('ev').showModal()}
const cb=document.getElementById('creditsBtn');if(cb)cb.onclick=showCredits;
/* deep links from other pages: planner.html?priority=water */
(function(){const q=new URLSearchParams(location.search),p=q.get('priority');if(p&&PRI[p])U.priority=p;})();
render();

/* keep "More settings" open across re-renders: remember its state when the viewer opens or closes it */
document.addEventListener('toggle',e=>{if(e.target&&e.target.id==='moreSet')U.moreOpen=e.target.open},true);

/* ---------- "Decide as I go": the Proposed rotation is chosen one time interval at a time while the years play ----------
   The simulation is sequential (each year starts from the soil, pests and nitrogen the previous year left), so after
   each choice the whole ensemble is re-run with the choices made so far; years already shown never change. Years not
   yet decided are filled from the planned Proposed rotation only so the model has something to run; they stay hidden. */
const liveMode=()=>U.planMode==='live';
const ivl=()=>U.interval||holdOf('prop')||1;
function planYears(){const ex=expandRot(U.rots.prop);return Array.from({length:U.horizon},(_,j)=>ex[j%ex.length])}
function liveRot(){const I=ivl(),pl=planYears();return Array.from({length:U.horizon},(_,j)=>{const d=Math.floor(j/I),s=d<U.dec.length?U.dec[d]:pl[j];return{crop:s.crop,cover:s.cover||null,yrs:1}})}
function decidedYrs(){return liveMode()&&U.sim?Math.min(U.horizon,U.dec.length*ivl()):U.horizon}
function needPick(){return liveMode()&&!!U.sim&&U.t>=decidedYrs()&&decidedYrs()<U.horizon}
function planModeHTML(){const live=liveMode(),I=ivl();
  return`<div class="planmode"><div class="tiny">How do you want to plan the Proposed rotation?</div>
  <div class="seg one" role="group" aria-label="Planning style"><button data-act="pmode" data-v="plan" class="${live?'':'on'}">Plan the whole rotation now</button><button data-act="pmode" data-v="live" class="${live?'on':''}">Decide as I go</button></div>
  ${live?`<div class="pmrow"><span class="tiny">Rotate every</span><div class="seg one" role="group" aria-label="Years between decisions">${[1,2,3,5].map(n=>`<button data-act="ivl" data-v="${n}" class="${I===n?'on':''}">${n} yr${n>1?'s':''}</button>`).join('')}</div></div>`
  :`<p class="tiny">Both rotations are set before the run and repeat for all ${U.horizon} years.</p>`}</div>`}
const nextIdx=()=>Math.floor((Math.max(1,U.t)-1)/ivl())+1;   // the interval after the one now playing
function showPick(){return liveMode()&&!!U.sim&&nextIdx()*ivl()<U.horizon}
function pickPanel(){const I=ivl(),d=nextIdx(),a=d*I+1,b=Math.min(U.horizon,a+I-1),end=d*I,locked=U.dec[d],pl=planYears()[a-1],
  base=locked||{crop:pl.crop,cover:pl.cover||null},sel=U.pick&&U.pick.d===d?U.pick:base,at=needPick();
  const prev=U.dec[d-1],prevC=CROPS_G[prev.crop];
  const crops=Object.values(CROPS_G).filter(c=>!c.unmodeled).sort((x,y)=>FITORD2[fitOf(x.id,U.zone)]-FITORD2[fitOf(y.id,U.zone)]||x.name.localeCompare(y.name));
  const grp=f=>{const cs=crops.filter(c=>fitOf(c.id,U.zone)===f);return cs.length?`<optgroup label="${FIT_LABEL[f]}">${cs.map(c=>`<option value="${c.id}" ${c.id===sel.crop?'selected':''}>${esc(c.name)}${c.id===prev.crop?' (same as now)':''}</option>`).join('')}</optgroup>`:''};
  const cf=coverConflict(sel.crop,sel.cover,U.zone),same=sel.crop===prev.crop||(CROPS_G[sel.crop].fam===prevC.fam);
  const changed=locked&&(sel.crop!==locked.crop||(sel.cover||null)!==(locked.cover||null));
  const span=a===b?'year '+a:'years '+a+'–'+b;
  const head=at?`🔄 Time to rotate`:locked?`✓ Next crop chosen`:`🗓 Plan your next crop`;
  const msg=at?`Year ${end} is the last year of this interval. Choose what the Proposed field grows in <b>${span}</b>.`
    :locked?`Proposed grows <b>${esc(CROPS_G[locked.crop].name)}</b>${locked.cover?' + '+esc(COVERS[locked.cover].name)+' cover':''} in ${span}. You can change it until the end of year ${end}.`
    :`Pick what the Proposed field grows in <b>${span}</b>. You can choose or change it until the end of year ${end}; the simulation waits for you there.`;
  return`<div class="pickbox ${at?'due':''}" role="region" aria-label="Choose the next Proposed crop"><h3>${head}</h3>
  <p class="tiny">${msg} Right now it has ${esc(prevC.name)}${prev.cover?' + '+esc(COVERS[prev.cover].name)+' cover':''}.</p>
  <div class="pkrow"><div><label for="pkcrop" class="tiny">Crop</label><select id="pkcrop">${['good','ok','poor'].map(grp).join('')}</select></div>
  <div><label for="pkcov" class="tiny">Winter cover</label><select id="pkcov"><option value="">None</option>${Object.keys(COVERS).map(k=>`<option value="${k}" ${k===sel.cover?'selected':''}>${esc(COVERS[k].name)}</option>`).join('')}</select></div></div>
  ${cf?`<div class="tiny warnline">⚠ ${esc(cf)} The cover will be skipped.</div>`:''}${same&&!CROPS_G[sel.crop].perennial?`<div class="tiny warnline">⚠ Same plant family as now — pests and disease build up when a family repeats.</div>`:''}
  <div class="pkbtns">${at?`<button class="btn" data-act="pkgo">Plant and continue ▶</button>`:locked?(changed?`<button class="btn" data-act="pkgo">Update choice</button>`:''):`<button class="btn" data-act="pkgo">Lock in for ${span}</button>`}<button class="btn alt" data-act="pkplan">Use my planned rotation for the rest</button></div></div>`}
/* lock in (or change) the next interval's crop. Only intervals that haven't started yet can change, so years already shown stay the same. */
function pickGo(){const I=ivl(),d=nextIdx(),pl=planYears()[d*I],at=needPick(),was=!!U.timer;
  const c=U.pick&&U.pick.d===d?{crop:U.pick.crop,cover:U.pick.cover||null}:(U.dec[d]||{crop:pl.crop,cover:pl.cover||null});
  if(d<U.dec.length)U.dec[d]=c;else U.dec.push(c);U.pick=null;stop();const t=U.t;simulate();U.t=t;if(at||was)play();else render()}
function pickPlan(){const I=ivl(),pl=planYears(),at=needPick(),was=!!U.timer;while(U.dec.length*I<U.horizon){const s=pl[U.dec.length*I];U.dec.push({crop:s.crop,cover:s.cover||null})}U.pick=null;stop();const t=U.t;simulate();U.t=t;if(at||was)play();else render()}

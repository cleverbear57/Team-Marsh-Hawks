# Rotate & Thrive — Team Marsh Hawks (NASA Space Apps 2026)

One-page crop-rotation explorer for a single representative 40-acre field. Search a California place or any U.S. county (or drop a pin anywhere in the U.S.) → build your **current rotation** and a **proposed rotation** (any length, 1–20 years, each year = a crop + optional winter cover)→ press Run: a 0–100 scoreboard (incl. dry-year resilience) appears and steps through the simulation year by year (play/pause/scrub). “✨ Improve my current rotation” makes small, tested changes to your own rotation (adds a break crop or legume year, a winter cover, reorders, drops repeats — never removes a crop you grow) and lists each change with its score effect; “Suggest a rotation” searches for a completely different sequence.

## Run it
```bash
python3 -m http.server 8765      # from this folder (serve over http, not file://)
```
Open http://localhost:8765/ — `tests.html` runs the functional tests.

## Pages
`index.html` (home) · `planner.html` (the tool; deep link `?priority=water|soil|output|resil`) · `data.html` (data & method) · photo credits are listed at the bottom of `data.html`. Shared header/footer: `site.js`.

## County crop map (USDA NASS)
The planner's California map shades each county by crop acreage from the **USDA NASS Quick Stats API** (2022 Census of Agriculture). The API needs a free key and can't be called from the browser, so the data is fetched once and cached:
```bash
export NASS_API_KEY=your-key            # get one at https://quickstats.nass.usda.gov/api
python3 tools/fetch_nass.py             # writes data/nass.js (+ raw/nass/, tools/nass_unmatched.txt)
```
The map itself is a **Leaflet** map on **OpenStreetMap** tiles (same map setup as the Field Shift project): drag, zoom, click to drop a pin, hover a county for its acres. Every other U.S. county is drawn too (us-atlas county boundaries, loaded from jsdelivr at runtime) and shaded from `data/nass_us.js` — the same 2022 Census county acreage for the other 48 states (3,012 counties; Alaska is reported by NASS as districts without county codes, so it stays unshaded). Rebuild it with `python3 tools/fetch_nass.py 2022 --us` (resumes from `raw/nass/` and retries if NASS rate-limits). Click any county for its cropland and top crops; outside California this also lists soybeans, barley, canola and other crops the planner doesn't model. Planning works in every U.S. county: outside California, `data/us_regions.js` assigns each state to one of 11 farming regions (irrigation allowance, groundwater share, slope, default soil, starter crop, crop fit, later spring planting in cold regions) and adds 10 non-California crops; weather is the pin's own live NASA POWER record. These regional numbers are rougher estimates than California's. Leaflet loads from cdnjs; if it can't load (offline), the planner falls back to the drawn SVG county map. County outlines (`data/ca_counties.js`) come from us-atlas (US Census Bureau) via `tools/build_counties.py`.

## Look & feel
Pixel-art crop and cover icons are drawn in `pixelicons.js` (original 20×20 sprites). Colors: light “Golden Hills” `#f4e9cf`, dark “Valley Loam” `#3b2a1d`, “Poppy” orange buttons `#c8481a` (tokens at the top of `game.css`). Font: **Astralaga** — a paid font; put its files in `fonts/` (see `fonts/README.md`). Until then the site falls back to Lora.

## Dev tooling (project-local)
`.claude/skills/ui-ux-pro-max/` — the UI UX Pro Max design skill (MIT, from github.com/nextlevelbuilder/ui-ux-pro-max-skill). `.mcp.json` registers the 21st.dev MCP server and reads the key from the `API_KEY_21ST` environment variable (no secret is stored in the file). Optional photo pipeline: `tools/find_photos.py`, `tools/build_photos.py`, `images/manifest.js` (empty = drawn icons are used). Home-page photos live in `images/home/` with credits in `images/home.js`.

## Files
`index.html` + `game.css` + `game.js` (UI) · `fieldview.js` (2D field picture) · `schedule.js` (editable rotation schedule — rotate every 1, 2, 3, 5 or custom years per crop; the model repeats each crop for its years) · `nasa.js` (NASA GIBS satellite map layers — SMAP, GPM IMERG, MODIS NDVI & land-surface temperature, NLDAS, GLDAS, SRTM, Landsat HLS — plus live NASA POWER daily downloads for extreme-rain, heat and frost days) · `checks.js` (rotation mistake detector, score trend arrows, compact NASA evidence card) · `farmplus.js` (farm size in acres → harvest in tons, net income and water for your farm; ⚖️ trade-off explorer that tests every single change to one year of the Proposed rotation; 🌡 climate what-if: shift temperature and scale rainfall, rerun, compare with today's climate. Tons per acre are rough educational estimates in `YIELD_EST`) · `field3d.js` (3D field view — drag to turn, scroll/pinch to zoom, right/shift-drag to pan, double-click to reset; plain WebGL, no library; falls back to the 2D picture without WebGL) · `gamecore.js` (simulation, scoring, rotation logic) · `data/crops.js` (35-crop catalog) · `data/gazetteer.js`, `data/weather.js` (cached NASA POWER for 63 places) · `raw/power/` (raw API responses) · `tools/fetch_power.py` (refresh the cache; needs curl) · `legacy/` (earlier multi-plot and detailed-analysis pages).

## How it works
Each rotation is run over the chosen number of years (repeating the cycle) on **30 resampled sequences of 2001–2025 NASA POWER weather**; all rotations see identical weather and prices. Scores (Water, Soil, Fertilizer, Pests, Income, Dry-year resilience, Overall) are medians with a 10th–90th spread. Overall = 40% your priority + 12% each of the others. Formulas are on the page.

## Honest limits
- Weather is NASA POWER monthly reanalysis (MERRA-2 grid, ~50 km), not an on-farm station; years are resampled in contiguous seeded blocks — a scenario, not a forecast.
- Crop, cost, yield and soil coefficients are **educational estimates** (see “Evidence & model”). Nothing is calibrated or validated; no farm advisor has reviewed it.
- Soil is an editable regional texture default; SSURGO retrieval, SMAP/GPM/ECOSTRESS/GRACE inside the model, rice, salinity and markets are not implemented. The soil measure is a 0–100 proxy, not % organic matter.
- If NASA POWER is unreachable for a custom pin, the page says so and offers cached nearby data or clearly labeled *illustrative* weather — never silent fake data.

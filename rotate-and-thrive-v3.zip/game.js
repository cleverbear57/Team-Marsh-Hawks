'use strict';
/* California Rotation Lab — compact one-page rotation explorer */
const U={mapView:null,nassCrop:'',loc:null,rec:null,recMsg:'',recState:'none',zone:null,soil:'loam',horizon:9,priority:'soil',alloc:100,seed:57,N:30,
  rots:{cur:[],prop:[]},sel:null,cq:{cur:'',prop:''},q:'',matches:[],nearby:null,msgSetup:'',mg:{equip:[],fert:'standard',irrig:'full'},msg:{cur:'',prop:''},
  sim:null,t:0,timer:null,sugRes:null,impRes:null,busy:false,busyKind:'',page:1};
const PRI={soil:'Soil',water:'Water',output:'Income',resil:'Resilience'};
const RK={cur:{n:'Current',c:'#b45309'},prop:{n:'Proposed',c:'#0e7490'}};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const money=x=>x==null?'n/a':usd(x);
const scol=v=>v==null?'#999':v<40?'#dc2626':v<60?'#d97706':'#059669';
const ready=()=>U.rec&&(U.recState==='ready'||U.recState==='illustrative');
const copy=o=>JSON.parse(JSON.stringify(o));
const setup=()=>({zone:U.zone,soil:U.soil,horizon:U.horizon,priority:U.priority,allocPct:U.alloc,seed:U.seed});
function dataStatus(){const r=U.rec;return[['Weather',r?(r.status==='available'?'ok':'bad'):'warn',r?`${r.source} · ${r.years[0]}–${r.years[r.years.length-1]} (${r.n} complete years)`:'not loaded'],['Soil moisture',r&&r.Sw?'ok':'warn',r&&r.Sw?'NASA MERRA-2 root-zone soil wetness (via POWER), monthly 2001–2025 — sets starting soil water':'not available for this weather source'],['Soil texture','warn','Regional texture default — edit it; SSURGO lookup not wired in'],['Satellite fields (SMAP, GPM, ECOSTRESS, GRACE)','warn','Context only; not used inside the game model'],['Current rotation','warn','Default is an illustrative example']]}
function reset(){stop();U.sim=null;U.t=0;U.sugRes=null;U.impRes=null}
function stop(){if(U.timer){clearInterval(U.timer);U.timer=null}}

/* ---------- location ---------- */
function search(q){q=q.trim().toLowerCase();if(!q)return[];return GAZ.filter(g=>g.name.toLowerCase().includes(q)||g.county.toLowerCase().includes(q)).slice(0,8)}
function parseLL(q){const m=q.match(/^\s*(-?\d+(\.\d+)?)\s*[, ]\s*(-?\d+(\.\d+)?)\s*$/);return m?{lat:+m[1],lon:+m[3]}:null}
function distKm(a,b){return Math.hypot(a.lat-b.lat,(a.lon-b.lon)*Math.cos(a.lat*Math.PI/180))*111}
async function loadLoc(loc){
  reset();U.msgSetup='';U.nearby=null;U.matches=[];
  if(!inCalifornia(loc.lat,loc.lon)){U.loc=null;U.rec=null;U.recState='none';U.msgSetup='Outside California — pick a California place.';render();return}
  U.loc=loc;U.zone=zoneOf(loc.lat,loc.lon);U.soil=ZONE_SOIL[U.zone];U.recState='loading';render();
  let rec=null;if(loc.id)rec=cachedRecord(loc.id,loc.lat);
  if(!rec){try{rec=await liveRecord(loc.lat,loc.lon)}catch(e){U.nearby=GAZ.map(g=>({g,d:distKm(g,loc)})).sort((a,b)=>a.d-b.d)[0];U.recMsg='NASA POWER request failed.'}}
  if(rec){U.rec=rec;U.recState='ready';defaultRots()}else{U.rec=null;U.recState='failed'}
  render()}
function defaultRots(){U.rots.cur=[{crop:DEFAULT_CROP[U.zone],cover:null}];U.rots.prop=suggestRotation(U.rots.cur,U.zone);U.sel=null;U.cq={cur:'',prop:''}}
function runSearch(){if(!ready()||!U.rots.cur.length)return;U.busy=true;U.busyKind='search';render();setTimeout(()=>{try{const r=searchRotations(U.rots.cur,setup(),U.rec,U.mg);reset();U.sugRes=r;if(r.list.length)U.rots.prop=copy(r.list[0].rot)}finally{U.busy=false;render()}},40)}
function runImprove(){if(!ready()||!U.rots.cur.length)return;U.busy=true;U.busyKind='improve';render();setTimeout(()=>{try{const r=improveRotation(U.rots.cur,setup(),U.rec,U.mg);reset();U.impRes=r;if(r.rot){U.rots.prop=copy(r.rot);U.sel=null}}finally{U.busy=false;render()}},40)}
function useNearby(){const n=U.nearby;U.rec=cachedRecord(n.g.id,U.loc.lat);U.rec.source=`NASA POWER (cached for ${n.g.name}, ${fmt(n.d)} km away)`;U.recState='ready';defaultRots();render()}
function useSynthetic(){U.rec=syntheticRecord(U.zone,U.loc.lat,U.seed);U.recState='illustrative';defaultRots();render()}

/* ---------- crop search ---------- */
const FITORD={good:0,ok:1,poor:2,unmodeled:3};
function cropMatches(q){q=q.trim().toLowerCase();let L=Object.values(CROPS_G);
  if(!q)return L.filter(c=>fitOf(c.id,U.zone)==='good').slice(0,10);
  L=L.filter(c=>(c.name+' '+c.fam+' '+CAT_LABEL[c.cat]+' '+c.id+(c.cat==='native'?' california native':'')).toLowerCase().includes(q));
  const rank=c=>{const t=(c.name+' '+(c.cat==='native'?'california native':'')).toLowerCase(),ws=t.split(/[\s\/(),-]+/);return(ws.some(w=>w.startsWith(q))?0:10)+FITORD[fitOf(c.id,U.zone)]};
  return L.sort((a,b)=>rank(a)-rank(b)).slice(0,8)}
const sugBtn=(c,k)=>{const f=fitOf(c.id,U.zone);return`<button class="sug" draggable="true" data-drag="crop:${c.id}" data-act="addcrop" data-rot="${k}" data-id="${c.id}"><span class="e">${cropIco(c.id,36)}</span><span><b>${c.name}</b><small class="fit-${f}">${FIT_LABEL[f]}${c.cat==='native'?' · CA native':''}</small></span></button>`};

/* ---------- map: California counties shaded by USDA NASS crop acreage (data/nass.js, cached by tools/fetch_nass.py) ---------- */
const MAPK=53.6,mapP=([lo,la])=>[(lo+124.6)*.8*MAPK,(42.1-la)*MAPK];
const NASS_SCALE=['#f1f5f9','#d1fae5','#a7f3d0','#6ee7b7','#10b981','#047857'];
let _rings=null;
function countyRings(){if(_rings||!window.CA_COUNTIES)return _rings||{};_rings={};
  for(const[f,c]of Object.entries(CA_COUNTIES))_rings[f]=c.d.split('Z').filter(Boolean).map(r=>r.replace('M','').split('L').map(p=>p.split(',').map(Number)));return _rings}
function countyAtXY(x,y){for(const[f,rs]of Object.entries(countyRings())){let inside=false;for(const r of rs)for(let i=0,j=r.length-1;i<r.length;j=i++){const[xi,yi]=r[i],[xj,yj]=r[j];if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)inside=!inside}if(inside)return f}return null}
function locCounty(){if(!U.loc||!window.CA_COUNTIES)return null;
  if(U.loc.county){const n=U.loc.county.toLowerCase();const f=Object.keys(CA_COUNTIES).find(k=>CA_COUNTIES[k].name.toLowerCase()===n);if(f)return f}
  const[x,y]=mapP([U.loc.lon,U.loc.lat]);return countyAtXY(x,y)}
const nassVal=(f,crop)=>{const c=window.NASS&&NASS.counties[f];if(!c)return null;return crop?(c.crops[crop]??null):(c.cropland??null)};
const nassCropName=id=>id==='winegrape'?'Grapes (wine & table)':id?(CROPS_G[id]?CROPS_G[id].name:id):'All harvested cropland';
function nassBreaks(vals){const v=vals.filter(x=>x>0).sort((a,b)=>a-b);return[.2,.4,.6,.8].map(q=>v.length?v[Math.min(v.length-1,Math.floor(q*v.length))]:0)}
function nassColor(v,br){if(v==null)return'#e2e8f0';if(v==='D')return'url(#nassD)';if(!v)return NASS_SCALE[0];let i=1;for(const b of br)if(v>b)i++;return NASS_SCALE[Math.min(5,i)]}
const acres=v=>v==null?'no data':v==='D'?'withheld by NASS':Math.round(v).toLocaleString()+' ac';
/* map zoom & pan: U.mapView = [x,y,w,h] viewBox in map units (null = whole state) */
const MAPW=500,MAPH=520,MAPMIN=MAPW/16;
const mapVB=()=>U.mapView||[0,0,MAPW,MAPH];
function setMapView(v){if(!v||v[2]>=MAPW-.5){U.mapView=null;return}const w=Math.max(MAPMIN,v[2]),h=w*MAPH/MAPW;U.mapView=[clamp(v[0],0,MAPW-w),clamp(v[1],0,MAPH-h),w,h]}
function zoomAt(cx,cy,f){const[x,y,w,h]=mapVB(),nw=clamp(w*f,MAPMIN,MAPW),r=nw/w;setMapView([cx-(cx-x)*r,cy-(cy-y)*r,nw,h*r])}
function zoomToCounty(f){const rs=countyRings()[f];if(!rs)return;let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;for(const r of rs)for(const[x,y]of r){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y)}
  const w=Math.max((x1-x0)*1.5,(y1-y0)*1.5*MAPW/MAPH,MAPMIN*1.5);setMapView([(x0+x1)/2-w/2,(y0+y1)/2-w*MAPH/MAPW/2,w])}
function mapPt(svg,e){const p=svg.createSVGPoint();p.x=e.clientX;p.y=e.clientY;const q=p.matrixTransform(svg.getScreenCTM().inverse());return[q.x,q.y]}
function wireMap(){const cm=document.getElementById('camap');if(!cm)return;let drag=null;
  const pin=(x,y)=>{const f=countyAtXY(x,y);loadLoc({name:'Map pin',county:f&&window.CA_COUNTIES?CA_COUNTIES[f].name:undefined,lat:+(42.1-y/MAPK).toFixed(3),lon:+(x/(.8*MAPK)-124.6).toFixed(3)})};
  cm.addEventListener('wheel',e=>{e.preventDefault();const[x,y]=mapPt(cm,e);zoomAt(x,y,e.deltaY<0?.8:1.25);cm.setAttribute('viewBox',mapVB().join(' '));scaleMarks(cm);syncZoomUI()},{passive:false});
  cm.addEventListener('pointerdown',e=>{if(e.button)return;drag={sx:e.clientX,sy:e.clientY,v:mapVB().slice(),moved:false,pt:mapPt(cm,e)};cm.setPointerCapture(e.pointerId)});
  cm.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;if(!drag.moved&&Math.hypot(dx,dy)<5)return;
    drag.moved=true;if(!U.mapView)return;const b=cm.getBoundingClientRect(),s=drag.v[2]/b.width;setMapView([drag.v[0]-dx*s,drag.v[1]-dy*s,drag.v[2]]);cm.setAttribute('viewBox',mapVB().join(' '));cm.style.cursor='grabbing'});
  cm.addEventListener('pointerup',()=>{if(!drag)return;const d=drag;drag=null;cm.style.cursor='';if(!d.moved)pin(d.pt[0],d.pt[1])});
  cm.addEventListener('dblclick',e=>e.preventDefault())}
function scaleMarks(cm){const k=mapVB()[2]/MAPW;cm.querySelectorAll('[data-r]').forEach(c=>c.setAttribute('r',+c.dataset.r*Math.max(k,.18)));cm.querySelectorAll('[data-sw]').forEach(c=>c.setAttribute('stroke-width',+c.dataset.sw*Math.max(k,.18)))}
function syncZoomUI(){const z=document.getElementById('mapzoomlvl');if(z)z.textContent=(MAPW/mapVB()[2]).toFixed(1)+'×';const o=document.querySelector('[data-act=mapzoom][data-v=out]'),r=document.querySelector('[data-act=mapzoom][data-v=reset]');if(o)o.disabled=!U.mapView;if(r)r.disabled=!U.mapView;
  const cm=document.getElementById('camap');if(cm)cm.style.touchAction=U.mapView?'none':''}
function mapSVG(){
  const crop=U.nassCrop||'',sel=locCounty(),has=!!window.NASS,C=window.CA_COUNTIES,mk=Math.max(mapVB()[2]/MAPW,.18);
  let body;
  if(C){const vals=has?Object.keys(C).map(f=>nassVal(f,crop)).filter(v=>typeof v==='number'):[],br=nassBreaks(vals);
    body=Object.entries(C).map(([f,c])=>`<path d="${c.d}" fill="${has?nassColor(nassVal(f,crop),br):'#f8fafc'}" stroke="${f===sel?'#0f172a':'#ffffff'}" stroke-width="${f===sel?2.6:.9}" vector-effect="non-scaling-stroke"><title>${esc(c.name)} County${has?' — '+esc(nassCropName(crop))+': '+acres(nassVal(f,crop)):''}</title></path>`).join('');
    if(sel)body+=`<path d="${C[sel].d}" fill="none" stroke="#0f172a" stroke-width="2.6" vector-effect="non-scaling-stroke" pointer-events="none"/>`}
  else body=`<polygon points="${CA_OUTLINE.map(p=>mapP(p).join(',')).join(' ')}" fill="#f8fafc" stroke="#0f172a" stroke-width="2"/>`;
  const dots=GAZ.map(g=>{const[x,y]=mapP([g.lon,g.lat]);return`<circle cx="${x}" cy="${y}" r="${2.2*mk}" data-r="2.2" fill="#334155" opacity=".5" pointer-events="none"><title>${esc(g.name)}</title></circle>`}).join('');
  let pin='';if(U.loc){const[x,y]=mapP([U.loc.lon,U.loc.lat]);pin=`<circle cx="${x}" cy="${y}" r="${8*mk}" data-r="8" fill="#dc2626" stroke="#fff" stroke-width="${2.5*mk}" data-sw="2.5" pointer-events="none"/>`}
  return`<svg id="camap" viewBox="${mapVB().join(' ')}" width="100%" style="cursor:crosshair;display:block;${U.mapView?'touch-action:none;':''}" role="img" aria-label="California county map${has?' shaded by '+esc(nassCropName(crop))+' acres from USDA NASS':''}: click to place a pin">
   <defs><pattern id="nassD" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="6" height="6" fill="#e2e8f0"/><rect width="2" height="6" fill="#94a3b8"/></pattern></defs>${body}${dots}${pin}</svg>`}
function mapPanel(){
  const has=!!window.NASS,sel=locCounty(),C=window.CA_COUNTIES||{},crop=U.nassCrop||'';
  const opts=has?[['','All harvested cropland'],...Object.keys(CROPS_G).filter(id=>id!=='tablegrape'&&Object.values(NASS.counties).some(c=>c.crops[id]!=null)).map(id=>[id,nassCropName(id)])]:[];
  const legend=has?`<div class="nasslegend"><span>none</span><i style="background:#e2e8f0;outline:1px solid #cbd5e1"></i><span style="margin-left:8px">fewer acres</span>${NASS_SCALE.slice(1).map(c=>`<i style="background:${c}"></i>`).join('')}<span>more</span><i class="d" title="withheld"></i><span>withheld</span></div>`:'';
  let info='';
  if(!has)info=`<div class="note"><b>County crop data not loaded.</b> The map is ready for USDA NASS Quick Stats data. Run <code>tools/fetch_nass.py</code> with a free NASS API key to fill it in.</div>`;
  else if(sel){const c=NASS.counties[sel],list=c?Object.entries(c.crops).filter(([id,v])=>id!=='tablegrape'&&(v==='D'||v>0)).sort((a,b)=>(b[1]==='D'?-1:b[1])-(a[1]==='D'?-1:a[1])).slice(0,8):[];
    info=`<h3 style="margin:4px 0 6px">${esc(C[sel].name)} County</h3><div class="tiny">${c&&c.cropland!=null?'Harvested cropland: <b>'+acres(c.cropland)+'</b>':''}</div>
     ${list.length?`<ul class="nasslist">${list.map(([id,v])=>`<li>${cropIco(id,26)}<span>${esc(nassCropName(id))}</span><b>${acres(v)}</b></li>`).join('')}</ul>`:'<p class="tiny">NASS lists none of the planner’s crops here.</p>'}`}
  else info='<p class="tiny">Pick a place, or click the map, to see which crops are grown in that county.</p>';
  return`<div class="mapgrid"><div class="mapbox"><div class="mapzoom" role="group" aria-label="Map zoom"><button data-act="mapzoom" data-v="in" aria-label="Zoom in">＋</button><button data-act="mapzoom" data-v="out" aria-label="Zoom out" ${U.mapView?'':'disabled'}>－</button><button data-act="mapzoom" data-v="reset" aria-label="Show all of California" title="Show all of California" ${U.mapView?'':'disabled'}>⤢</button></div><span class="mapzlvl" id="mapzoomlvl">${(MAPW/mapVB()[2]).toFixed(1)}×</span>${mapSVG()}${legend}${sel?`<button class="btn sm alt mapcty" data-act="mapzoom" data-v="county">Zoom to ${esc(C[sel].name)} County</button>`:''}<div class="tiny" style="margin-top:4px">Scroll or use ＋ － to zoom · drag to move · click to drop a pin</div></div><div>
   ${has?`<label for="nasscrop" class="tiny">Shade counties by</label><select id="nasscrop">${opts.map(([v,l])=>`<option value="${v}" ${v===crop?'selected':''}>${esc(l)}</option>`).join('')}</select>`:''}
   ${info}
   <p class="tiny" style="margin-top:10px">${has?`Source: ${esc(NASS.source)} (fetched ${esc(NASS.fetched)}). ${esc(NASS.note)}`:'County outlines: US Census Bureau (via us-atlas).'}</p></div></div>`}

/* ---------- sections ---------- */
function secLocation(){
  return`<div class="card"><div class="row" style="align-items:center"><h2 style="margin:0"><span class="num">1</span> Location</h2><div style="flex:0 0 auto"></div></div>
  <input type="text" id="q" value="${esc(U.q)}" placeholder="Search a California town or county, or “lat, lon”" aria-label="Search location" autocomplete="off" style="margin-top:8px">
  <div id="res" class="results" ${U.matches.length?'':'hidden'}>${U.matches.map(g=>`<button data-act="pick" data-id="${g.id}">${ico('ui','pin',18)} ${esc(g.name)} <span class="mute">· ${esc(g.county)}</span></button>`).join('')}</div>
  ${U.msgSetup?`<div class="warnb">${esc(U.msgSetup)}</div>`:''}
  ${U.loc?`<div class="loc">${ico('ui','pin',20)} <b>${esc(U.loc.name||'Pin')}${U.loc.county?', '+esc(U.loc.county):''}</b> · ${ZONES[U.zone].name}</div>`:''}
  ${U.recState==='loading'?'<p class="tiny">Loading NASA weather…</p>':''}
  ${U.recState==='failed'?`<div class="warnb">${U.recMsg} ${U.nearby?`<button class="btn sm alt" data-act="nearby">Use ${esc(U.nearby.g.name)} data (${fmt(U.nearby.d)} km away)</button>`:''} <button class="btn sm alt" data-act="synth">Use illustrative weather (not NASA)</button></div>`:''}
  ${U.recState==='illustrative'?'<div class="warnb">Illustrative weather — not NASA data.</div>':''}
  ${U.rec&&U.recState==='ready'?`<div class="tiny">✔ ${esc(U.rec.source)} · ${U.rec.years[0]}–${U.rec.years[U.rec.years.length-1]}</div>`:''}
  <h3 style="margin:16px 0 8px">California crops by county <span class="tiny" style="font-weight:400">· USDA NASS</span></h3>${mapPanel()}</div>`}

function slotHTML(k,i,s){const cr=s.crop&&CROPS_G[s.crop],sel=U.sel&&U.sel.rot===k&&U.sel.i===i;
  const opts=[['','No cover'],...Object.keys(COVERS).map(c=>[c,COVERS[c].name])];
  return`<div class="slot ${sel?'sel':''}" draggable="true" data-drag="slot:${k}:${i}" data-slot="${k}:${i}" tabindex="0" role="button" aria-label="Year ${i+1}: ${cr?cr.name:'empty'}" aria-pressed="${sel}">
    <div class="yr">Yr ${i+1}</div><div class="em">${cropIco(s.crop,50)}${s.cover?`<span class="cvb" title="${esc(COVERS[s.cover].name)} winter cover">${ico('cover',s.cover,22)}</span>`:''}</div><div class="nm">${cr?cr.name:'Fallow'}</div>
    <select class="cvsel" data-cv="${k}:${i}" aria-label="Winter cover year ${i+1}">${opts.map(([v,l])=>{const bad=v&&coverConflict(s.crop,v,U.zone);return`<option value="${v}" ${s.cover===v?'selected':''} ${bad?'disabled':''}>${l}</option>`}).join('')}</select>
    <div class="ctl"><button data-act="mvleft" data-rot="${k}" data-i="${i}" aria-label="Earlier" ${i===0?'disabled':''}>◀</button><button data-act="mvright" data-rot="${k}" data-i="${i}" aria-label="Later" ${i===U.rots[k].length-1?'disabled':''}>▶</button><button data-act="rmslot" data-rot="${k}" data-i="${i}" aria-label="Remove">✕</button></div></div>`}
function tagsHTML(rot){if(!rot.length)return'';const f=rotationFacts(rot,U.zone);return f.unmodeled?`<span class="tag warn">⚠ unmodeled crop</span>`:''}
function editorHTML(k){const rot=U.rots[k],sel=U.sel&&U.sel.rot===k?U.sel:null,q=U.cq[k],sug=q?cropMatches(q):[],rec=!q?cropMatches(''):[];
  return`<div class="rotcard" style="--c:${RK[k].c}"><div class="row" style="align-items:center"><h3 style="margin:0;color:${RK[k].c}">${RK[k].n} rotation</h3>
   <div style="flex:0 0 auto;display:flex;gap:6px">${k==='prop'?`<button class="btn sm" data-act="improve" ${U.busy||!U.rots.cur.length?'disabled':''} title="Small, tested changes to your current rotation">${U.busy&&U.busyKind==='improve'?'Improving…':'✨ Improve my current rotation'}</button><button class="btn sm alt" data-act="usesug" ${U.busy?'disabled':''}>${U.busy&&U.busyKind==='search'?'Searching…':'Suggest a rotation'}</button>`:''}<select data-preset="${k}" aria-label="Example rotation" style="width:auto"><option value="">Example…</option>${Object.keys(ROT_PRESETS).map(p=>`<option value="${p}">${ROT_PRESETS[p][0]}</option>`).join('')}</select></div></div>
  ${tagsHTML(rot)?`<div>${tagsHTML(rot)}</div>`:''}
  <div class="slots">${rot.map((s,i)=>slotHTML(k,i,s)).join('')}<button class="slot add" data-act="focussearch" data-rot="${k}" data-drag-add="${k}" aria-label="Add a year">＋</button></div>
  <input type="text" id="cq-${k}" data-cq="${k}" value="${esc(q)}" placeholder="${sel?`Replace year ${sel.i+1} with…`:'Add a crop (try “tom”, “almond”, “native”)'}" aria-label="Search crops" autocomplete="off">
  ${q?`<div class="results">${sug.length?sug.map(c=>sugBtn(c,k)).join(''):'<div style="padding:8px" class="mute">No match</div>'}</div>`:''}
  ${U.msg[k]?`<div class="note">${esc(U.msg[k])}</div>`:''}</div>`}
function sugPanel(){const r=U.sugRes;if(!r)return'';if(!r.list.length)return'<div class="note">No better rotation found for this location and priority.</div>';
  const emo=rot=>rot.map(s=>`<span class="sq">${cropIco(s.crop,30)}${s.cover?`<span class="cvb sm">${ico('cover',s.cover,14)}</span>`:''}</span>`).join('<span class="arr">›</span>');
  const dl=v=>v==null?'':`<span class="${v>=0?'up':'dn'}">${sgn(v,0)}</span>`;
  return`<div class="sugbox"><div class="tiny">Best of <b>${fmt(r.tested)}</b> rotations tested on ${esc(U.loc.name||'this')} NASA weather (${U.priority==='output'?'income':PRI[U.priority].toLowerCase()} first, income kept close to current):</div>${r.list.map((x,i)=>`<div class="cand"><span class="seq">${emo(x.rot)}</span><span class="tiny">${SCORE_CATS.filter(c=>['soil','water','income','resil'].includes(c[0])).map(c=>ico('cat',c[0],16)+dl(x.vs[c[0]])).join(' ')}</span><b style="color:${scol(x.ov)}">${Math.round(x.ov)}</b><button class="btn sm ${U.rots.prop&&JSON.stringify(U.rots.prop)===JSON.stringify(x.rot)?'':'alt'}" data-act="usecand" data-i="${i}">${JSON.stringify(U.rots.prop)===JSON.stringify(x.rot)?'In use':'Use'}</button></div>`).join('')}<div class="tiny">Numbers = change vs current. Searched in ${(r.ms/1000).toFixed(1)}s.</div></div>`}
function impPanel(){const r=U.impRes;if(!r)return'';
  if(!r.rot)return`<div class="note">Your current rotation already scores best among ${fmt(r.tested)} small changes tested on ${esc(U.loc.name||'this')} NASA weather (${PRI[U.priority].toLowerCase()} priority). Try “Suggest a rotation” for a completely different sequence.</div>`;
  const emo=rot=>rot.map(s=>`<span class="sq">${cropIco(s.crop,30)}${s.cover?`<span class="cvb sm">${ico('cover',s.cover,14)}</span>`:''}</span>`).join('<span class="arr">›</span>');
  const dl=v=>v==null?'':`<span class="${v>=0?'up':'dn'}">${sgn(v,0)}</span>`;
  return`<div class="sugbox impbox"><div class="imphead"><div><div class="eyebrow" style="margin:0">Improved rotation</div><div class="tiny">Built from your current rotation · loaded into <b style="color:${RK.prop.c}">Proposed</b> above</div></div>
   <div class="impscore"><span style="color:${scol(r.curOv)}">${Math.round(r.curOv)}</span><span class="arr">→</span><b style="color:${scol(r.ov)}">${Math.round(r.ov)}</b><small>overall</small></div></div>
   <div class="cand"><span class="seq">${emo(U.rots.cur)}</span><span class="tiny">current</span></div>
   <div class="cand"><span class="seq">${emo(r.rot)}</span><span class="tiny">improved</span></div>
   <div class="impfx">${SCORE_CATS.map(c=>r.vs[c[0]]==null?'':`<span class="tag">${ico('cat',c[0],14)} ${c[2]} ${dl(r.vs[c[0]])}</span>`).join('')}</div>
   <ol class="impsteps">${r.steps.map(st=>`<li><b>${esc(st.text)}</b><span class="tiny">${dl(st.gain)} overall${st.fx.length?' · '+st.fx.map(x=>`${x.l} ${dl(x.d)}`).join(', '):''}</span></li>`).join('')}</ol>
   <div class="tiny">Scored with your ${PRI[U.priority].toLowerCase()} priority (change it in Settings, then improve again). ${fmt(r.tested)} variations tested on ${esc(U.loc.name||'this')} NASA weather; income kept within 5 points of current; every crop you grow is kept. Changes vs current are measured on 12 fresh weather sequences.</div></div>`}
function secRotations(){return`<div class="card"><h2><span class="num">2</span> Rotations</h2>${editorHTML('cur')}${editorHTML('prop')}${impPanel()}${sugPanel()}</div>`}
function secRun(){const can=U.rots.cur.length&&U.rots.prop.length;
  return`<div class="card"><h2><span class="num">3</span> Settings</h2>
  <div class="row" style="align-items:flex-end"><div class="sl"><div class="t"><label for="hz">Years</label><b>${U.horizon}</b></div><input type="range" id="hz" min="3" max="20" value="${U.horizon}" style="width:100%"></div>
  <div><div class="tiny">Priority</div><div class="seg wrap">${Object.keys(PRI).map(k=>`<button data-act="pri" data-v="${k}" class="${U.priority===k?'on':''}">${PRI[k]}</button>`).join('')}</div></div></div>
  <details><summary class="tiny">More settings</summary><div class="grid2" style="margin-top:8px"><div>
   <label for="soil" class="tiny">Soil texture</label><select id="soil">${Object.keys(SOILG).map(s=>`<option ${s===U.soil?'selected':''}>${s}</option>`).join('')}</select>
   <label for="alloc" class="tiny">Water limit ${U.alloc}%</label><input type="range" id="alloc" min="50" max="120" step="5" value="${U.alloc}" style="width:100%">
   <label for="fert" class="tiny">Fertilizer</label><select id="fert">${Object.keys(FERT).map(k=>`<option value="${k}" ${U.mg.fert===k?'selected':''}>${FERT[k].name}</option>`).join('')}</select>
   <label for="irrig" class="tiny">Irrigation</label><select id="irrig">${[['full','Full'],['deficit','Deficit 80%'],['drought','Drought-saver 60%']].map(([k,n])=>`<option value="${k}" ${U.mg.irrig===k?'selected':''}>${n}</option>`).join('')}</select></div>
   <div><div class="tiny">Equipment</div>${Object.keys(EQUIP).map(k=>{const e=EQUIP[k],o=U.mg.equip.includes(k);return`<label class="eq ${o?'own':''}" title="${esc(e.desc)}"><input type="checkbox" data-eq="${k}" ${o?'checked':''}><span class="e">${ico('equip',k,30)}</span><div><b>${e.name}</b> ${money(e.price)}</div></label>`}).join('')}</div></div></details>
  <div style="margin-top:10px"><button class="btn big" data-act="run" ${can?'':'disabled'}>▶ Run simulation</button></div></div>`}

/* ---------- scoreboard (appears after Run, steps through the years) ---------- */
function yieldCol(y){if(y==null)return'#e5e5e5';const t=clamp((y-.4)/.6,0,1);return`hsl(${Math.round(t*115)},55%,${86-t*18}%)`}
function scoresAtT(k,t=U.t){const reps=U.sim.E[k].first.slice(0,t);return avgScores(reps,U.zone)}
/* ---------- field preview: draws what the field would look like from this year's model outputs ---------- */
function fieldsHTML(E,S,t,below){
  const cap=k=>{const r=E[k].first[t-1],row=r.rows[0],cr=r.slot.crop&&CROPS_G[r.slot.crop];if(!cr)return'Fallow';
    const lim=row.limits&&row.limits[0]?` · main limit: ${row.limits[0][0].toLowerCase()} −${fmt(row.limits[0][1]*100)}%`:'';
    return`${cropIco(cr.id,20)} <b>${cr.name}</b>${r.slot.cover?' + '+ico('cover',r.slot.cover,16)+' '+COVERS[r.slot.cover].name+' cover':''} · yield ${row.unmodeled?'n/a':row.Y==null?'–':fmt(row.Y*100)+'%'}${lim}`};
  return`<div class="fieldsbox"><h3 style="margin:10px 0 4px">${ico('ui','sprout',24)} Your field — year ${t}</h3><div class="fields">${['cur','prop'].map(k=>`<figure><div class="fh" style="color:${RK[k].c}"><b>${RK[k].n}</b></div>${fieldSVG(k,S[k],E,t)}<figcaption class="tiny">${cap(k)}</figcaption>${below?below(k):''}</figure>`).join('')}</div>
  <details class="legend"><summary class="tiny">What the picture shows</summary><div class="tiny">Illustration of the model’s numbers, not a photo or forecast. Sky = that year’s rain · bigger, greener plants = higher yield · gaps = pest loss · cracks = water shortage · green strips = winter cover · darker soil = higher soil score · blue = NASA soil wetness.</div></details></div>`}
function simData(t=U.t){const E=U.sim.E,H=U.horizon,rec=U.rec,idx=E.cur.idx,S={cur:scoresAtT('cur',t),prop:scoresAtT('prop',t)},ov={cur:overallOf(S.cur,U.priority),prop:overallOf(S.prop,U.priority)};
  return{E,H,t,rec,idx,W:weightsFor(U.priority),S,ov,done:t>=H,pid:idx.map(i=>rec.annualP[i]/rec.meanP)}}
function scoreTable(D){
  const cell=v=>v==null?'<td class="sc">–</td>':`<td class="sc"><b style="color:${scol(v)}">${Math.round(v)}</b><span class="mb"><i style="width:${v}%;background:${scol(v)}"></i></span></td>`;
  const best=D.ov.prop==null||D.ov.cur==null?null:D.ov.prop>D.ov.cur+1?'prop':D.ov.cur>D.ov.prop+1?'cur':null;
  return`<table class="sb"><tr><th></th><th style="color:${RK.cur.c}">Current</th><th style="color:${RK.prop.c}">Proposed</th></tr>
  ${SCORE_CATS.map(([c,e,l,d])=>`<tr title="${esc(d)}"><th>${ico('cat',c,24)} ${l}${D.W[c]>.3?' ★':''}</th>${cell(D.S.cur&&D.S.cur[c])}${cell(D.S.prop&&D.S.prop[c])}</tr>`).join('')}
  <tr class="tot"><th>OVERALL</th>${['cur','prop'].map(k=>`<td class="sc">${D.ov[k]==null?'–':`<b style="font-size:24px;color:${scol(D.ov[k])}">${Math.round(D.ov[k])}</b>${best===k?'<div class="tiny">★ higher</div>':''}`}</td>`).join('')}</tr></table>`}

/* one rotation's scoreboard, shown under its own field picture (proposed also shows the change vs current) */
function sideScore(D,k){
  const other=k==='prop'?'cur':null,best=D.ov.prop==null||D.ov.cur==null?null:D.ov.prop>D.ov.cur+1?'prop':D.ov.cur>D.ov.prop+1?'cur':null;
  const dl=(a,b)=>other&&a!=null&&b!=null&&Math.round(a-b)!==0?`<span class="sdl ${a>=b?'up':'dn'}">${sgn(a-b,0)}</span>`:'';
  const cell=c=>{const v=D.S[k]&&D.S[k][c];return v==null?'<td class="sc">–</td>':`<td class="sc"><span class="sv"><b style="color:${scol(v)}">${Math.round(v)}</b>${dl(v,other&&D.S[other]&&D.S[other][c])}</span><span class="mb"><i style="width:${v}%;background:${scol(v)}"></i></span></td>`};
  return`<table class="sb sbside" style="--c:${RK[k].c}"><tr><th colspan="2" style="color:${RK[k].c}">${RK[k].n} · scoreboard</th></tr>
  ${SCORE_CATS.map(([c,e,l,d])=>`<tr title="${esc(d)}"><th>${ico('cat',c,22)} ${l}${D.W[c]>.3?' ★':''}</th>${cell(c)}</tr>`).join('')}
  <tr class="tot"><th>OVERALL</th><td class="sc">${D.ov[k]==null?'–':`<span class="sv"><b style="font-size:24px;color:${scol(D.ov[k])}">${Math.round(D.ov[k])}</b>${dl(D.ov[k],other&&D.ov[other])}</span>${best===k?'<div class="tiny">★ higher</div>':''}`}</td></tr></table>`}

/* page 4: each field picture with its own scoreboard underneath, stepping through the years */
function simPage(){
  const D=simData(),{H,t,done}=D;
  return`<div class="card score" id="score"><div class="row" style="align-items:center"><h2>${ico('crop','wheat',30)} Simulation</h2><div class="ctlbar"><button class="btn sm alt" data-act="tprev" ${t<=1?'disabled':''} aria-label="Previous year">◀</button><button class="btn sm" data-act="tplay">${U.timer?'⏸ Pause':done?'↻ Replay years':'▶ Play'}</button><button class="btn sm alt" data-act="tnext" ${done?'disabled':''} aria-label="Next year">▶</button><b>Year ${t} / ${H}</b></div></div>
  <input type="range" id="tr" min="1" max="${H}" value="${t}" style="width:100%" aria-label="Year">
  <div class="simstack">${fieldsHTML(D.E,D.S,t,k=>sideScore(D,k))}<div class="tiny" style="margin-top:8px">Scores are 0–100, higher is better · ★ = your priority · green/red numbers on Proposed = change vs Current · hover a row for its formula</div></div></div>`}

/* page 5: whole-run summary (all years), outcome, exports */
function summaryPage(){
  const D=simData(U.horizon),{E,rec,idx,pid,S}=D,t=U.horizon,ks=['cur','prop'];
  const strip=`<div class="yrs">${idx.map((i,j)=>`<div class="yc"><div class="wb"><i style="height:${clamp(pid[j]/1.8*100,6,100)}%;background:${pid[j]<.7?'#c87a1a':pid[j]>1.3?'#1b6f8c':'#8aa7b5'}"></i></div><small>${rec.years[i]}</small></div>`).join('')}</div>`;
  const swStrip=rec.Sw?`<div class="lane"><div class="ln" title="NASA MERRA-2 root-zone soil wetness in March (0 = dry, 1 = saturated)"><b>Soil wet</b></div><div class="yrs">${idx.map((i,j)=>{const v=rec.Sw[i][2];return`<div class="yc" title="Year ${j+1}: March root-zone wetness ${v.toFixed(2)} (NASA)"><div class="wb"><i style="height:${clamp(v*100,6,100)}%;background:#8b6a43"></i></div><small>${v.toFixed(2)}</small></div>`}).join('')}</div></div>`:'';
  const lane=k=>`<div class="lane"><div class="ln" style="color:${RK[k].c}"><b>${RK[k].n}</b></div><div class="yrs">${E[k].first.map((r,j)=>{const cr=r.slot.crop&&CROPS_G[r.slot.crop],w=r.rows[0];return`<div class="yc" style="background:${w.unmodeled?'#e9e2f7':yieldCol(w.Y)}" title="Year ${j+1}: ${cr?cr.name:'fallow'}${w.Y!=null?' · yield '+fmt(w.Y*100)+'%':''}">${cropIco(r.slot.crop,26)}${r.slot.cover?`<span class="cvb sm">${ico('cover',r.slot.cover,12)}</span>`:''}<small>${w.unmodeled?'n/a':w.Y==null?'–':fmt(w.Y*100)+'%'}</small></div>`}).join('')}</div></div>`;
  const o=outcome(S),pP=E.prop.ov.all.filter((v,i)=>v!=null&&E.cur.ov.all[i]!=null&&v>E.cur.ov.all[i]).length/U.N;
  return`<div class="card"><h2>Summary</h2><p class="tiny" style="margin:2px 0 8px">Final scores after ${t} years, and what happened each year.</p>
  <div class="final"><span class="badge">${o.cat}</span> <span class="tiny">${esc(o.why)}</span><div class="tiny" style="margin-top:4px">Proposed beats Current in <b>${fmt(pP*100)}%</b> of ${U.N} other weather sequences.</div></div>
  ${scoreTable(D)}
  <h3>Year by year</h3><div class="lane"><div class="ln"><b>Rain</b></div>${strip}</div>${swStrip}${ks.map(lane).join('')}
  <div style="margin-top:12px"><button class="btn sm" data-act="export-json">⬇ JSON</button> <button class="btn sm alt" data-act="export-csv">⬇ CSV</button> <button class="btn sm alt" data-act="replay">↻ Replay the simulation</button> <button class="btn sm alt" data-act="newweather">Try new weather</button></div>
  <div class="tiny" style="margin-top:8px">0–100, higher is better · ★ = your priority · <button class="lnk2" id="evBtn2">model &amp; limits</button></div></div>`}

/* ---------- paging ---------- */
const PAGES=[['1','Place'],['2','Rotations'],['3','Settings'],['4','Simulation'],['5','Summary']];
function canGo(p){if(p===1)return true;if(!ready())return false;if(p===2)return true;if(p===3)return U.rots.cur.length>0&&U.rots.prop.length>0;return!!U.sim}
function gotoPage(p){if(!canGo(p))return;stop();U.page=p;render();window.scrollTo(0,0)}
function stepper(){return`<nav class="stepper" aria-label="Steps">${PAGES.map(([n,l])=>{const p=+n,on=U.page===p,done=p<U.page&&canGo(p);return`<button class="st ${on?'on':''} ${done?'done':''}" data-act="goto" data-v="${p}" ${canGo(p)?'':'disabled'} ${on?'aria-current="step"':''}><b>${done?'✓':n}</b><span>${l}</span></button>`}).join('')}</nav>`}
function navBar(){const p=U.page,back=p>1?`<button class="btn alt" data-act="goto" data-v="${p-1}">← Back</button>`:'<span></span>';
  const nxt={1:['Next: Rotations →',2],2:['Next: Settings →',3],4:['See summary →',5]}[p];
  const right=nxt?`<button class="btn" data-act="goto" data-v="${nxt[1]}" ${canGo(nxt[1])?'':'disabled'}>${nxt[0]}</button>`:p===5?`<button class="btn alt" data-act="startover">Start a new comparison</button>`:'<span></span>';
  return p===3?`<div class="navbar">${back}<span></span></div>`:`<div class="navbar">${back}${right}</div>`}

function outcome(S){const c=S.cur,p=S.prop,key={soil:'soil',water:'water',output:'income',resil:'resil'}[U.priority],lab={soil:'Soil Builder',water:'Water Saver',income:'Harvest Booster',resil:'Resilience Builder'}[key];
  if(!c||!p)return{cat:'Insufficient evidence',why:'Outputs unavailable (unmodeled crop).'};
  if(JSON.stringify(U.rots.cur)===JSON.stringify(U.rots.prop))return{cat:'Same rotation',why:'Both rotations are identical.'};
  const dp=p[key]-c[key],di=p.income-c.income,nm=SCORE_CATS.find(x=>x[0]===key)[2];
  if(dp>=5&&di>=-5)return{cat:lab,why:`${nm} ${sgn(dp,0)}, income ${sgn(di,0)}.`};
  if(dp>=5)return{cat:'Tradeoff',why:`${nm} ${sgn(dp,0)} but income ${sgn(di,0)}.`};
  if(dp<=-5)return{cat:'Worse on your priority',why:`${nm} ${sgn(dp,0)}.`};
  return{cat:'No clear difference',why:`${nm} ${sgn(dp,0)} (within ±5).`}}

/* ---------- render ---------- */
function render(){
  const a=document.getElementById('app'),fid=document.activeElement&&document.activeElement.id,pos=window.scrollY;
  if(U.page>1&&!canGo(U.page))U.page=ready()?(canGo(3)?3:2):1;
  const body={1:secLocation,2:secRotations,3:secRun,4:simPage,5:summaryPage}[U.page]();
  a.innerHTML=`<div class="narrow ${U.page===4?'wide':''}">${stepper()}${body}${navBar()}</div>`;
  a.classList.toggle('wide',U.page===4);document.body.classList.toggle('nohero',U.page!==1);const hero=document.querySelector('.hero');if(hero)hero.style.display=U.page===1?'':'none';
  if(fid&&(fid==='q'||fid.startsWith('cq-'))){const q=document.getElementById(fid);if(q){q.focus();q.setSelectionRange(q.value.length,q.value.length)}}
  window.scrollTo(0,pos);
  wireMap();
  const e2=document.getElementById('evBtn2');if(e2)e2.onclick=showEvidence}
function change(){reset();render()}
function runSim(){reset();U.sim={E:ensembleRotations({cur:U.rots.cur,prop:U.rots.prop},setup(),U.rec,U.mg,U.N)};U.t=1;U.page=4;render();window.scrollTo(0,0);play()}
function play(){stop();if(!U.sim)return;if(U.t>=U.horizon)U.t=1;U.timer=setInterval(()=>{if(U.t>=U.horizon){stop();render();return}U.t++;render()},1600);render()}

/* ---------- exports ---------- */
function download(name,text,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}
function exportJSON(){const E=U.sim.E,S={cur:scoresAtT('cur'),prop:scoresAtT('prop')};download('rotate-and-thrive-run.json',JSON.stringify({app:'Rotate & Thrive',version:4,exported:new Date().toISOString(),setup:setup(),management:U.mg,location:U.loc,dataStatus:dataStatus(),weather:{source:U.rec.source,sha256:U.rec.sha,exampleSourceYears:E.cur.idx.map(i=>U.rec.years[i]),resamplings:U.N},rotations:{current:U.rots.cur,proposed:U.rots.prop},scoresFinalYear:S,ensemble:Object.fromEntries(['cur','prop'].map(k=>[k,{overall:E[k].ov,categories:E[k].cat,numbers:E[k].num}])),outcome:outcome(S),caveats:ASSUMPTIONS},null,1),'application/json')}
function exportCSV(){const E=U.sim.E,L=['rotation,year,source_year,crop,cover,yield_fraction,net_usd_per_acre,water_af_per_acre'];['cur','prop'].forEach(k=>E[k].first.forEach((r,j)=>{const w=r.rows[0];L.push([k,j+1,r.srcYear,r.slot.crop,r.slot.cover||'',w.Y==null?'':w.Y.toFixed(3),w.net==null||w.unmodeled?'':(w.net/PLOT_AC).toFixed(0),w.pull==null?'':(w.pull/304.8).toFixed(3)].join(','))}));download('rotate-and-thrive-run.csv',L.join('\n'),'text/csv')}
function showEvidence(){const r=U.rec;document.getElementById('evBody').innerHTML=`<h2>Model &amp; limits</h2><ul>${dataStatus().map(([a,c,t])=>`<li><b>${a}</b> (${c==='ok'?'available':c==='bad'?'unavailable':'partial'}): ${esc(t)}</li>`).join('')}</ul>${r?`<p class="tiny">${esc(r.source)}${r.retrieved?', retrieved '+r.retrieved:''}. ${esc((window.WEATHER_META||{}).note||'')}</p>`:''}<h3>Scores</h3><ul>${SCORE_CATS.map(([k,e,l,d])=>`<li><b>${ico('cat',k,18)} ${l}.</b> ${esc(d)}</li>`).join('')}<li><b>Overall.</b> 40% your priority + 12% each other.</li></ul><h3>Model (educational, unvalidated)</h3><ul>${ASSUMPTIONS.map(([a,t])=>`<li><b>${a}.</b> ${esc(t)}</li>`).join('')}</ul><p>One representative 40-acre field. No farm advisor has reviewed this.</p>`;document.getElementById('ev').showModal()}

/* ---------- actions ---------- */
function addCrop(k,id,at){const rot=U.rots[k];U.msg[k]='';reset();
  if(U.sel&&U.sel.rot===k&&at==null)at=U.sel.i;
  if(at!=null&&rot[at]){const s=rot[at];s.crop=id;const cf=coverConflict(id,s.cover,U.zone);if(cf){s.cover=null;U.msg[k]='Cover removed — overlaps crop.'}}else rot.push({crop:id,cover:null});
  if(rot.length>20){rot.length=20;U.msg[k]='Max 20 years.'}U.sel=null;U.cq[k]='';render()}
document.addEventListener('click',e=>{
  const ctl=e.target.closest('[data-act]');
  if(!ctl){const s=e.target.closest('[data-slot]');if(s&&!e.target.closest('select')){const[k,i]=s.dataset.slot.split(':');U.sel=U.sel&&U.sel.rot===k&&U.sel.i===+i?null:{rot:k,i:+i};render();const inp=document.getElementById('cq-'+k);inp&&inp.focus()}return}
  const act=ctl.dataset.act,v=ctl.dataset.v,id=ctl.dataset.id,k=ctl.dataset.rot,i=+ctl.dataset.i;
  const H={
   pick:()=>{const g=GAZ.find(x=>x.id===id);U.q=g.name;loadLoc({...g})},mapzoom:()=>{const[x,y,w,h]=mapVB();if(v==='in')zoomAt(x+w/2,y+h/2,.6);else if(v==='out')zoomAt(x+w/2,y+h/2,1/.6);else if(v==='county'){const f=locCounty();f&&zoomToCounty(f)}else U.mapView=null;render()},nearby:useNearby,synth:useSynthetic,
   pri:()=>{U.priority=v;change()},
   addcrop:()=>addCrop(k,id),focussearch:()=>{U.sel=null;const inp=document.getElementById('cq-'+k);inp&&inp.focus()},
   mvleft:()=>{const r=U.rots[k];[r[i-1],r[i]]=[r[i],r[i-1]];U.sel=null;change()},mvright:()=>{const r=U.rots[k];[r[i+1],r[i]]=[r[i],r[i+1]];U.sel=null;change()},
   rmslot:()=>{U.rots[k].splice(i,1);U.sel=null;change()},
   usesug:runSearch,improve:runImprove,usecand:()=>{const keep=U.sugRes;U.rots.prop=copy(keep.list[i].rot);U.sel=null;change();U.sugRes=keep;render()},
   run:runSim,tplay:()=>{if(U.timer){stop();render()}else play()},tprev:()=>{stop();U.t=Math.max(1,U.t-1);render()},tnext:()=>{stop();U.t=Math.min(U.horizon,U.t+1);render()},
   goto:()=>gotoPage(+v),startover:()=>{reset();U.page=1;render();window.scrollTo(0,0)},
   replay:()=>{U.t=1;U.page=4;window.scrollTo(0,0);play()},newweather:()=>{U.seed+=1000;runSim()},
   'export-json':exportJSON,'export-csv':exportCSV};
  if(H[act])H[act]()});
document.addEventListener('keydown',e=>{
  if(e.target.matches&&e.target.matches('[data-slot]')&&(e.key==='Enter'||e.key===' ')){e.preventDefault();const[k,i]=e.target.dataset.slot.split(':');U.sel=U.sel&&U.sel.rot===k&&U.sel.i===+i?null:{rot:k,i:+i};render();const inp=document.getElementById('cq-'+k);inp&&inp.focus();return}
  if(e.target.dataset&&e.target.dataset.cq){const k=e.target.dataset.cq;if(e.key==='Enter'){const m=cropMatches(U.cq[k])[0];if(m){e.preventDefault();addCrop(k,m.id)}}if(e.key==='Escape'){U.cq[k]='';U.sel=null;render()}}
  if(e.target.id==='q'&&e.key==='Enter'){const m=search(U.q)[0];if(m){e.preventDefault();U.q=m.name;loadLoc({...m})}}});
document.addEventListener('input',e=>{const t=e.target;
  if(t.id==='q'){U.q=t.value;const ll=parseLL(U.q);U.matches=ll?[]:search(U.q);render();if(ll){clearTimeout(U._t);U._t=setTimeout(()=>loadLoc({name:'Typed coordinates',...ll}),700)}}
  if(t.dataset&&t.dataset.cq){U.cq[t.dataset.cq]=t.value;render()}
  if(t.id==='tr'){stop();U.t=+t.value;render()}
  if(t.id==='hz'){U.horizon=+t.value;change()}
  if(t.id==='soil'){U.soil=t.value;change()}if(t.id==='alloc'){U.alloc=+t.value;change()}
  if(t.id==='fert'){U.mg.fert=t.value;change()}if(t.id==='irrig'){U.mg.irrig=t.value;change()}
  if(t.dataset&&t.dataset.eq){const a=U.mg.equip,k=t.dataset.eq,p=a.indexOf(k);t.checked?(p<0&&a.push(k)):(p>=0&&a.splice(p,1));change()}});
document.addEventListener('change',e=>{const t=e.target;if(t.id==='nasscrop'){U.nassCrop=t.value;render();return}
  if(t.dataset&&t.dataset.cv){const[k,i]=t.dataset.cv.split(':');U.rots[k][+i].cover=t.value||null;change()}
  if(t.dataset&&t.dataset.preset&&t.value){const k=t.dataset.preset;U.rots[k]=copy(ROT_PRESETS[t.value][1](U.zone));U.sel=null;change()}});
document.addEventListener('dragstart',e=>{const d=e.target.closest('[data-drag]');if(d){e.dataTransfer.setData('text/plain',d.dataset.drag);e.dataTransfer.effectAllowed='copyMove'}});
document.addEventListener('dragover',e=>{const t=e.target.closest('[data-slot],[data-drag-add]');if(t){e.preventDefault();t.classList.add('over')}});
document.addEventListener('dragleave',e=>{const t=e.target.closest('[data-slot],[data-drag-add]');if(t)t.classList.remove('over')});
document.addEventListener('drop',e=>{const t=e.target.closest('[data-slot],[data-drag-add]');if(!t)return;e.preventDefault();const tok=e.dataTransfer.getData('text/plain');if(!tok)return;const p=tok.split(':');
  const dest=t.dataset.slot?t.dataset.slot.split(':'):[t.dataset.dragAdd,null];
  if(p[0]==='crop')addCrop(dest[0],p[1],dest[1]==null?null:+dest[1]);
  else if(p[0]==='slot'&&p[1]===dest[0]){const r=U.rots[p[1]],from=+p[2],to=dest[1]==null?r.length-1:+dest[1];const[m]=r.splice(from,1);r.splice(to,0,m);U.sel=null;change()}});
document.getElementById('evBtn').onclick=showEvidence;
function showCredits(){const L=Object.entries(window.IMGS||{}).sort((a,b)=>a[0].localeCompare(b[0]));document.getElementById('evBody').innerHTML=`<h2>Photo credits</h2><p class="tiny">Photographs are from Wikimedia Commons under the free licenses shown; they illustrate each crop or practice in general and are not images of your field. Charts, field overlays and the soil cutaway are drawn from the model.</p><ul class="credits">${L.map(([k,m])=>`<li><b>${esc(k)}</b> — <a href="${esc(m.page||'#')}" target="_blank" rel="noopener">${esc((m.title||'').replace(/^File:/,''))}</a> · ${esc(m.artist||'unknown')} · ${esc(m.license||'')}</li>`).join('')||'<li>No photos installed.</li>'}</ul>`;document.getElementById('ev').showModal()}
const cb=document.getElementById('creditsBtn');if(cb)cb.onclick=showCredits;
/* deep links from other pages: planner.html?priority=water */
(function(){const q=new URLSearchParams(location.search),p=q.get('priority');if(p&&PRI[p])U.priority=p;})();
render();

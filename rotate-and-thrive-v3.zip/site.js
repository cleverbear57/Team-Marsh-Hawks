'use strict';
/* Shared site chrome: header nav + footer for every page. */
const SITE_PAGES=[['index.html','Home'],['planner.html','Planner'],['data.html','Data & method']];
function siteHeader(active,opts={}){
  return`<div class="wrap hd"><a class="brand" href="index.html" aria-label="Rotate &amp; Thrive home"><span id="logo">${ico('ui','logo',36)}</span><div><b>Rotate &amp; Thrive</b><small>Crop rotation planner · NASA Earth data</small></div></a>
  <nav class="sitenav" aria-label="Main">${SITE_PAGES.map(([h,l])=>`<a href="${h}" ${l===active?'aria-current="page"':''}>${l}</a>`).join('')}${opts.planner?'<button id="evBtn" class="lnk">Evidence &amp; model</button>':''}</nav></div>`}
function siteFooter(opts={}){
  return`<div class="wrap ft">
   <div class="ftbrand"><div class="brand">${ico('ui','logo',32)}<b>Rotate &amp; Thrive</b></div><p>Compare California crop rotations on 25 years of NASA weather and soil-moisture data. Built by Team Marsh Hawks for the 2026 NASA Space Apps Challenge.</p></div>
   <div><h4>Explore</h4>${SITE_PAGES.map(([h,l])=>`<a href="${h}">${l}</a>`).join('')}</div>
   <div><h4>Data</h4><span>NASA POWER (MERRA-2)</span><span>Root-zone soil wetness</span><span>USDA NASS Quick Stats</span><a href="data.html#photo-credits">Photo credits</a></div>
  </div>
  <div class="wrap ftlegal flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2"><span>Educational prototype. Crop, cost and yield numbers are unvalidated estimates — confirm decisions with your UC Cooperative Extension advisor.</span><span class="whitespace-nowrap">© 2026 Team Marsh Hawks</span></div>`}
function mountSite(active,opts){const h=document.getElementById('siteheader'),f=document.getElementById('sitefooter');if(h)h.innerHTML=siteHeader(active,opts);if(f)f.innerHTML=siteFooter(opts)}

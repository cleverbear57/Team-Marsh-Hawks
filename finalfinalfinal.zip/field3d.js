'use strict';
/* 3D field view — the same model-driven farm picture as fieldview.js, built as a small 3D diorama you can turn.
   Drag = rotate · scroll / pinch = zoom · right-drag or shift-drag = pan · double-click = reset · arrow keys / +/- work too.
   Encoding is identical to the 2D picture: sky = that year's rain; soil colour = soil score; plant shape = crop;
   plant size/colour = yield & stress; gaps = pest/disease loss; cracks = water shortage; green strips = winter cover;
   cut-away sides = topsoil, roots and NASA root-zone soil wetness (blue band). Facet shading, clouds and the tree line are cosmetic.
   No libraries: plain WebGL 1. Falls back to the 2D picture if WebGL is unavailable. Both views share one camera so
   Current and Proposed always face the same way. */
(function(){
const fieldSVG2D=window.fieldSVG;
const hex=h=>{h=h.replace('#','');return[parseInt(h.slice(0,2),16)/255,parseInt(h.slice(2,4),16)/255,parseInt(h.slice(4,6),16)/255]};
const mix=(a,b,t)=>a.map((v,i)=>v+(b[i]-v)*t);
const rgb=(r,g,b)=>[r/255,g/255,b/255];

/* ---------- unit primitives (triangle soups, flat-shaded later) ---------- */
function icosa(sub){
  const t=(1+Math.sqrt(5))/2;let V=[[-1,t,0],[1,t,0],[-1,-t,0],[1,-t,0],[0,-1,t],[0,1,t],[0,-1,-t],[0,1,-t],[t,0,-1],[t,0,1],[-t,0,-1],[-t,0,1]].map(v=>{const l=Math.hypot(...v);return v.map(x=>x/l)});
  let F=[[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]];
  for(let s=0;s<sub;s++){const NF=[],mid={};const m=(a,b)=>{const k=a<b?a+'_'+b:b+'_'+a;if(mid[k]!=null)return mid[k];const v=V[a].map((x,i)=>(x+V[b][i])/2),l=Math.hypot(...v);V.push(v.map(x=>x/l));return mid[k]=V.length-1};
    for(const[a,b,c]of F){const ab=m(a,b),bc=m(b,c),ca=m(c,a);NF.push([a,ab,ca],[b,bc,ab],[c,ca,bc],[ab,bc,ca])}F=NF}
  return F.flatMap(f=>f.flatMap(i=>V[i]))}
function cyl(seg,r0=1,r1=1,caps=true){const o=[];for(let i=0;i<seg;i++){const a=i/seg*Math.PI*2,b=(i+1)/seg*Math.PI*2,ca=Math.cos(a),sa=Math.sin(a),cb=Math.cos(b),sb=Math.sin(b);
  o.push(ca*r0,0,sa*r0, ca*r1,1,sa*r1, cb*r0,0,sb*r0,  cb*r0,0,sb*r0, ca*r1,1,sa*r1, cb*r1,1,sb*r1);
  if(caps){if(r1>0)o.push(0,1,0, cb*r1,1,sb*r1, ca*r1,1,sa*r1);o.push(0,0,0, ca*r0,0,sa*r0, cb*r0,0,sb*r0)}}return o}
function disc(seg){const o=[];for(let i=0;i<seg;i++){const a=i/seg*Math.PI*2,b=(i+1)/seg*Math.PI*2;o.push(0,0,0, Math.cos(b),0,Math.sin(b), Math.cos(a),0,Math.sin(a))}return o}
const CUBE=(()=>{const o=[],q=(a,b,c,d)=>o.push(...a,...b,...c,...a,...c,...d),h=.5;
  const P=[[-h,-h,-h],[h,-h,-h],[h,h,-h],[-h,h,-h],[-h,-h,h],[h,-h,h],[h,h,h],[-h,h,h]];
  q(P[4],P[5],P[6],P[7]);q(P[1],P[0],P[3],P[2]);q(P[5],P[1],P[2],P[6]);q(P[0],P[4],P[7],P[3]);q(P[3],P[7],P[6],P[2]);q(P[0],P[1],P[5],P[4]);return o})();
const PR={cube:CUBE,ico0:icosa(0),ico1:icosa(1),cyl:cyl(7),cone:cyl(6,1,0),disc:disc(12),tcyl:cyl(6,1,.6)};

/* ---------- geometry builder ---------- */
class GB{
  constructor(seed){this.a=[];this.b=[];this.cur=[0,0,0,0];this.rng=mulberry(seed)}
  tri(p0,p1,p2,c,jit=.1){const ux=p1[0]-p0[0],uy=p1[1]-p0[1],uz=p1[2]-p0[2],vx=p2[0]-p0[0],vy=p2[1]-p0[1],vz=p2[2]-p0[2];
    let nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;const l=Math.hypot(nx,ny,nz)||1;nx/=l;ny/=l;nz/=l;
    const j=1-jit/2+this.rng()*jit,r=c[0]*j,g=c[1]*j,b=c[2]*j;
    this.a.push(p0[0],p0[1],p0[2],nx,ny,nz,r,g,b, p1[0],p1[1],p1[2],nx,ny,nz,r,g,b, p2[0],p2[1],p2[2],nx,ny,nz,r,g,b);const q=this.cur;this.b.push(...q,...q,...q)}
  /* add primitive: scale (sx,sy,sz) → rotate X, Z, Y → translate */
  add(prim,x,y,z,sx,sy,sz,c,o={}){const P=PR[prim],rx=o.rx||0,ry=o.ry||0,rz=o.rz||0,jit=o.jit==null?.12:o.jit;
    const cx=Math.cos(rx),sxr=Math.sin(rx),cz=Math.cos(rz),szr=Math.sin(rz),cy=Math.cos(ry),syr=Math.sin(ry);
    const T=i=>{let px=P[i]*sx,py=P[i+1]*sy,pz=P[i+2]*sz,t;
      t=py*cx-pz*sxr;pz=py*sxr+pz*cx;py=t;          // X
      t=px*cz-py*szr;py=px*szr+py*cz;px=t;          // Z
      t=px*cy+pz*syr;pz=-px*syr+pz*cy;px=t;         // Y
      return[px+x,py+y,pz+z]};
    for(let i=0;i<P.length;i+=9)this.tri(T(i),T(i+3),T(i+6),c,jit)}
  /* a stick from point A to point B with radius r */
  stick(A,B,r,c,prim='cyl'){const dx=B[0]-A[0],dy=B[1]-A[1],dz=B[2]-A[2],L=Math.hypot(dx,dy,dz)||1e-6;
    const rz=-Math.atan2(Math.hypot(dx,dz),dy),ry=-Math.atan2(dz,dx);
    this.add(prim,A[0],A[1],A[2],r,L,r,c,{rz,ry,jit:.08})}
  quad(a,b,c,d,col,jit){this.tri(a,b,c,col,jit);this.tri(a,c,d,col,jit)}
  /* interleave: position, normal, colour (9) + growth base & kind (4) = 13 floats per vertex */
  build(){const n=this.a.length/9,o=new Float32Array(n*13);for(let i=0;i<n;i++){o.set(this.a.subarray?this.a.subarray(i*9,i*9+9):this.a.slice(i*9,i*9+9),i*13);o.set(this.b.slice(i*4,i*4+4),i*13+9)}return o}
}

/* ---------- colours (match the 2D picture) ---------- */
const G3=id=>hex((window.GRADS&&GRADS[id]||['#58a336','#58a336','#2b6a1c'])[1]);
const FRUIT={tomato:'g-red',citrus:'g-orange',peach:'g-peach',pomegranate:'g-red',avocado:'g-avo',olive:'g-olive',strawberry:'g-red',melon:'g-melon',date:'g-date',tablegrape:'g-grape-g',winegrape:'g-purple',elderberry:'g-purple',apple:'g-red'};
const GLYPH3={tomato:'bush',lettuce:'rosette',broccoli:'rosette',spinach:'rosette',artichoke:'rosette',carrot:'tops',garlic:'tops',onion:'tops',strawberry:'low',melon:'low',garbanzo:'low',drybean:'low',jojoba:'low',elderberry:'low',
  corn:'stalk',safflower:'stalk',sunflower:'sun',cotton:'cotton',wheat:'grain',sorghum:'grain',rice:'grain',alfalfa:'blades',bunchgrass:'blades',wildflower:'flower',
  almond:'tree',walnut:'tree',pistachio:'tree',peach:'tree',citrus:'tree',avocado:'tree',olive:'tree',pomegranate:'tree',date:'palm',winegrape:'vine',tablegrape:'vine',
  graincorn:'stalk',soybean:'low',peanut:'low',oats:'grain',barley:'grain',canola:'flower',potato:'bush',sugarbeet:'rosette',pecan:'tree',apple:'tree'};
const DENS3={veg:[7,9],field:[9,14],forage:[10,16],orchard:[4,5],vine:[5,8],native:[7,9]};
const ROOT3={veg:.6,field:1,forage:1.5,orchard:1.5,vine:1.5,native:1};

/* field geometry constants (world units; y is up). Diorama block with a grass rim; field = soil rectangle on top */
const FX=20,FZ=26,BX=23,BZ=29,DEPTH=10;

/* ---------- one plant ---------- */
function plant(g,type,id,x,z,R,Y,bear,fg,dk,rng){
  const n=Math.round(clamp(Y,0,1)*5),fc=FRUIT[id]&&G3(FRUIT[id]),lighter=mix(fg,[1,1,1],.18);
  const fruit=(cx,cy,cz,spread,count,r)=>{const k0=g.cur;g.cur=[k0[0],k0[1],k0[2],k0[3]?2:0];for(let i=0;i<count;i++){const a=rng()*6.28,d=spread*(.5+.5*rng());g.add('ico0',cx+Math.cos(a)*d,cy+(rng()-.3)*spread*.8,cz+Math.sin(a)*d,r,r,r,fc,{jit:.05})}g.cur=k0};
  const leaf=(cx,cy,cz,l,w,th,ry,tilt,c=fg)=>g.add('ico0',cx,cy,cz,l,th,w,c,{ry,rz:tilt});
  switch(type){
    case'bush':{for(let a=0;a<7;a++){const an=a*.9+rng()*.3;leaf(x+Math.cos(an)*R*.55,R*.55,z+Math.sin(an)*R*.55,R*.55,R*.32,R*.18,-an,.35)}
      g.add('ico1',x,R*.75,z,R*.6,R*.5,R*.6,fg);if(bear&&fc)fruit(x,R*.6,z,R*.7,n,R*.16);break}
    case'rosette':{for(let r=0;r<3;r++){const cnt=8-r*2,rad=R*(.62-r*.2);for(let a=0;a<cnt;a++){const an=a/cnt*6.28+r*.35;
        leaf(x+Math.cos(an)*rad,R*(.18+r*.16),z+Math.sin(an)*rad,R*(.5-r*.1),R*(.32-r*.06),R*.1,-an,.45+r*.2,r==2?lighter:fg)}}
      g.add('ico1',x,R*.5,z,R*.28,R*.24,R*.28,lighter);break}
    case'tops':for(let a=-3;a<=3;a++){const an=a*.25,ry=rng()*6.28;g.stick([x,0,z],[x+Math.sin(an)*Math.cos(ry)*R*.6,R*1.9*(.85+rng()*.2),z+Math.sin(an)*Math.sin(ry)*R*.6],R*.14,fg,'cone')}
      g.add('ico0',x,R*.06,z,R*.2,R*.1,R*.2,id==='carrot'?hex('#e8892e'):hex('#efe6cf'));break;
    case'low':{for(let a=0;a<5;a++){const an=a*1.26+rng();g.add('ico0',x+Math.cos(an)*R*.45,R*.25,z+Math.sin(an)*R*.45,R*.42,R*.26,R*.42,fg,{ry:an})}
      if(bear&&fc)fruit(x,R*.3,z,R*.55,Math.min(n,id==='melon'?2:4),id==='melon'?R*.28:R*.13);break}
    case'stalk':{const h=R*3.2;g.add('tcyl',x,0,z,R*.09,h,R*.09,dk);
      for(let a=0;a<4;a++){const yy=h*(.25+a*.17),an=a*2.2+rng();g.stick([x,yy,z],[x+Math.cos(an)*R*.9,yy+R*.2,z+Math.sin(an)*R*.9],R*.07,fg,'cone')}
      if(bear)g.add('ico0',x+R*.14,h*.5,z,R*.12,R*.32,R*.12,hex('#e8c34a'));g.add('cone',x,h,z,R*.08,R*.5,R*.08,bear?hex('#d9b04a'):fg);break}
    case'sun':{const h=R*3;g.add('tcyl',x,0,z,R*.1,h,R*.1,dk);leaf(x-R*.4,h*.4,z,R*.5,R*.25,R*.08,0,.4);leaf(x+R*.4,h*.55,z,R*.5,R*.25,R*.08,Math.PI,.4);
      const pc=Y>.45?hex('#f4c20d'):fg;for(let a=0;a<10;a++){const an=a/10*6.28;g.add('ico0',x+Math.cos(an)*R*.5,h+Math.sin(an)*R*.5,z+R*.12,R*.28,R*.12,R*.06,pc,{rz:an})}
      g.add('cyl',x,h,z+R*.05,R*.32,R*.12,R*.32,G3('g-brown'),{rx:Math.PI/2});break}
    case'cotton':{for(let a=0;a<6;a++){const an=a*1.05;leaf(x+Math.cos(an)*R*.4,R*.7,z+Math.sin(an)*R*.4,R*.5,R*.3,R*.14,-an,.3)}
      g.add('ico1',x,R*.8,z,R*.45,R*.5,R*.45,fg);if(bear)for(let i=0;i<n+1;i++){const a=rng()*6.28;g.add('ico1',x+Math.cos(a)*R*.5,R*(.6+rng()*.7),z+Math.sin(a)*R*.5,R*.16,R*.16,R*.16,[.98,.98,.97],{jit:.03})}break}
    case'grain':{const ripe=Y>.5,sc=ripe?hex('#b79a3c'):dk,hc=ripe?G3('g-gold'):fg,red=id==='sorghum'&&ripe;
      for(let a=0;a<7;a++){const an=a*.9+rng(),d=a?R*.35*rng()+R*.15:0,bx=x+Math.cos(an)*d,bz=z+Math.sin(an)*d,h=R*(2+rng()*.4)*(id==='sorghum'?1.3:1),tx=bx+Math.cos(an)*R*.25,tz=bz+Math.sin(an)*R*.25;
        g.stick([bx,0,bz],[tx,h,tz],R*.035,sc);g.add('ico0',tx,h+R*.2,tz,R*.09,R*.32,R*.09,red?G3('g-redbrown'):hc)}break}
    case'blades':for(let a=0;a<10;a++){const an=a*.63+rng()*.3,d=R*.12;g.stick([x+Math.cos(an)*d,0,z+Math.sin(an)*d],[x+Math.cos(an)*R*.6,R*(1.2+rng()*.5),z+Math.sin(an)*R*.6],R*.12,a%3?fg:lighter,'cone')}break;
    case'flower':{for(let a=0;a<4;a++)leaf(x+Math.cos(a*1.6)*R*.3,R*.15,z+Math.sin(a*1.6)*R*.3,R*.4,R*.2,R*.08,-a*1.6,.2);
      for(let i=0;i<4;i++){const a=i*1.57+rng(),px=x+Math.cos(a)*R*.35,pz=z+Math.sin(a)*R*.35,h=R*(.6+rng()*.5);g.stick([x,0,z],[px,h,pz],R*.04,dk);g.add('ico1',px,h,pz,R*.17,R*.17,R*.17,hex(['#f39c12','#9b59b6','#f4d03f','#e74c3c'][i]),{jit:.04})}break}
    case'tree':{const th=bear?R*.9:R*.55,cr=bear?R*.85:R*.4;g.add('tcyl',x,0,z,R*.13,th+cr*.4,R*.13,G3('g-brown'));
      if(bear){const cy=th+cr*.75;for(const[dx,dy,dz]of[[-.45,0,0],[.45,0,0],[0,0,.45],[0,0,-.45],[0,.45,0],[0,.1,0]])g.add('ico1',x+dx*cr,cy+dy*cr,z+dz*cr,cr*.62,cr*.55,cr*.62,fg);if(fc)fruit(x,cy,z,cr*.95,n+3,cr*.11)}
      else g.add('ico1',x,th+cr*.6,z,cr,cr*.8,cr,fg);break}
    case'palm':{const h=bear?R*2.6:R*1;g.add('tcyl',x,0,z,R*.11,h,R*.11,hex('#7a5a36'));
      for(let a=0;a<7;a++){const an=a/7*6.28;g.stick([x,h,z],[x+Math.cos(an)*R*.9,h+R*.15,z+Math.sin(an)*R*.9],R*.1,fg,'cone');g.stick([x+Math.cos(an)*R*.85,h+R*.18,z+Math.sin(an)*R*.85],[x+Math.cos(an)*R*1.3,h-R*.3,z+Math.sin(an)*R*1.3],R*.07,fg,'cone')}
      if(bear&&fc)fruit(x,h-R*.15,z,R*.2,4,R*.1);break}
    case'vine':{const post=hex('#6b4a2a'),h=R*1.2;g.add('cube',x,h/2,z-R*.95,R*.1,h,R*.1,post);g.stick([x,h*.9,z-R],[x,h*.9,z+R],R*.02,hex('#8a8a8a'));
      g.add('tcyl',x,0,z,R*.06,h*.75,R*.06,G3('g-brown'));for(const dz of[-.55,0,.55])g.add('ico1',x,h*.78,z+dz*R,R*.38,R*.32,R*.48,fg);
      if(bear&&fc)for(const dz of[-.5,.1,.6])fruit(x,h*.45,z+dz*R,R*.12,2,R*.12);break}
    default:g.add('ico1',x,R*.5,z,R*.5,R*.5,R*.5,fg)}
}

/* ---------- build the scene for one rotation-year ---------- */
function buildScene(k,Sk,E,t){
  const r=E[k].first[t-1],row=r.rows[0],slot=r.slot,cr=slot.crop&&CROPS_G[slot.crop],seed=k.charCodeAt(0)*977+t*131+(slot.crop||'x').length*17,g=new GB(seed),rng=mulberry(seed+1);
  const soilT=Sk?clamp(Sk.soil/100,0,1):.4,soilA=rgb(214,178,124),soilB=rgb(74,44,21),soil=mix(soilA,soilB,soilT),subTop=mix(rgb(196,160,110),rgb(110,80,48),soilT*.6),subBot=mix(rgb(160,126,84),rgb(76,52,30),soilT*.6);
  const pidx=r.pidx,wet=pidx>1.3,dry=pidx<.75;
  const sky=wet?['#6f8191','#a3b2bf','#d3dbe2']:dry?['#e0a45a','#f1cf98','#f9ebcf']:['#5aa9e6','#a9d8f3','#e9f6fc'];
  const grass=hex(wet?'#6c8d62':dry?'#b9a56a':'#78a456'),grassDk=hex(wet?'#3f5f3a':dry?'#7d7040':'#44692f');
  const modeled=cr&&!row.unmodeled,Y=modeled?row.Y:null,bearing=modeled&&!!(Y>0||!cr.bear),Yeff=modeled?(bearing?Y:.55):0;
  /* tree / vine size follows how close the planting is to full production (row.mat: 0 = not bearing … 1 = full) */
  const per=!!(cr&&cr.perennial&&cr.id!=='alfalfa'),ageS=per&&row&&row.mat!=null?.3+.7*clamp(row.mat,0,1):1;
  /* the same crop several years in a row keeps growing instead of starting over: find this year's place in the run */
  const run=E[k].first;let pos=0,len=1;if(cr){for(let j=t-2;j>=0&&run[j]&&run[j].slot.crop===cr.id;j--)pos++;len=pos+1;for(let j=t;j<run.length&&run[j]&&run[j].slot.crop===cr.id;j++)len++}
  const sfOf=i=>len>1?.45+.55*i/(len-1):1,runS=per?1:sfOf(pos);   // annuals: bigger each year of the run, full size in its last year
  const prevAge=per&&pos>0&&run[t-2].rows[0].mat!=null?.3+.7*clamp(run[t-2].rows[0].mat,0,1):null;
  const wetv=row&&row.wet!=null?row.wet:null,root=cr?(ROOT3[cr.cat]||1):0;

  /* block sides: topsoil band + subsoil gradient, lower part tinted blue by NASA soil wetness */
  const TOP=1.4,blue=hex('#2d6aa3');
  const side=(ax,az,bx,bz)=>{const steps=12;for(let i=0;i<steps;i++){const t0=i/steps,t1=(i+1)/steps,x0=ax+(bx-ax)*t0,z0=az+(bz-az)*t0,x1=ax+(bx-ax)*t1,z1=az+(bz-az)*t1;
      g.quad([x0,0,z0],[x0,-TOP,z0],[x1,-TOP,z1],[x1,0,z1],soil,.14);
      const layers=8;for(let j=0;j<layers;j++){const y0=-TOP-(DEPTH-TOP)*j/layers,y1=-TOP-(DEPTH-TOP)*(j+1)/layers,f=(j+.5)/layers;let c=mix(subTop,subBot,f);
        if(wetv!=null){const fromBot=1-f;if(fromBot<wetv)c=mix(c,blue,.6*clamp(.55+(wetv-fromBot)*2,.55,1))}
        g.quad([x0,y0,z0],[x0,y1,z0],[x1,y1,z1],[x1,y0,z1],c,.16)}}};
  side(-BX,BZ,BX,BZ);side(BX,BZ,BX,-BZ);side(BX,-BZ,-BX,-BZ);side(-BX,-BZ,-BX,BZ);
  g.quad([-BX,-DEPTH,-BZ],[BX,-DEPTH,-BZ],[BX,-DEPTH,BZ],[-BX,-DEPTH,BZ],mix(subBot,[0,0,0],.3),.05);
  /* pebbles poking out of the cut faces */
  for(let i=0;i<70;i++){const s=i%4,u=rng()*2-1,y=-TOP-.6-rng()*(DEPTH-TOP-1),rr=.18+rng()*.35,c=rng()<.5?rgb(217,191,140):rgb(74,50,32);
    const[x,z]=s===0?[u*BX,BZ]:s===1?[BX,u*BZ]:s===2?[u*BX,-BZ]:[-BX,u*BZ];g.add('ico0',x,y,z,rr,rr*.8,rr,c)}
  /* grass rim */
  const rim=(x0,z0,x1,z1)=>{const nx=Math.max(1,Math.round((x1-x0)/2)),nz=Math.max(1,Math.round((z1-z0)/2));for(let i=0;i<nx;i++)for(let j=0;j<nz;j++){const a=x0+(x1-x0)*i/nx,b=x0+(x1-x0)*(i+1)/nx,c=z0+(z1-z0)*j/nz,d=z0+(z1-z0)*(j+1)/nz;g.quad([a,0,d],[b,0,d],[b,0,c],[a,0,c],grass,.2)}};
  rim(-BX,FZ,BX,BZ);rim(-BX,-BZ,BX,-FZ);rim(-BX,-FZ,-FX,FZ);rim(FX,-FZ,BX,FZ);
  for(let i=0;i<18;i++){const x=-BX+1+i*(2*BX-2)/17+(rng()-.5);g.add('ico1',x,1.2+rng()*.6,-BZ+1.3,1.3+rng()*.6,1.4+rng()*.8,1.1,grassDk);g.add('tcyl',x,0,-BZ+1.3,.18,.9,.18,G3('g-brown'))}
  for(let i=0;i<60;i++){const s=i%4,u=rng()*2-1,[x,z]=s===0?[u*BX,FZ+.6+rng()*2.2]:s===1?[FX+.6+rng()*2.2,u*FZ]:s===2?[u*BX,-FZ-.6-rng()*1.2]:[-FX-.6-rng()*2.2,u*FZ];g.add('cone',x,0,z,.15,.5+rng()*.5,.15,mix(grass,grassDk,rng()*.6))}

  /* field top: a grid of soil cells (grain), raised beds along the rows */
  const NXc=20,NZc=26;for(let i=0;i<NXc;i++)for(let j=0;j<NZc;j++){const a=-FX+2*FX*i/NXc,b=-FX+2*FX*(i+1)/NXc,c=-FZ+2*FZ*j/NZc,d=-FZ+2*FZ*(j+1)/NZc;g.quad([a,0,d],[b,0,d],[b,0,c],[a,0,c],soil,.16)}
  const[nR,nP0]=cr?(DENS3[cr.cat]||DENS3.veg):[9,9],dx=2*FX/nR,rowX=i=>-FX+dx*(i+.5);
  const bedC=mix(soil,[1,1,1],.06),furC=mix(soil,[0,0,0],.18);
  for(let i=0;i<nR;i++){g.add('cube',rowX(i),.17,0,dx*.58,.34,2*FZ-.6,bedC,{jit:.06});
    if(i<nR-1){const fx=rowX(i)+dx/2;g.add('cube',fx,.01,0,dx*.3,.02,2*FZ-.6,furC,{jit:.04});
      if(slot.cover){g.add('cube',fx,.14,0,dx*.36,.24,2*FZ-.8,hex('#5fae3f'),{jit:.1});for(let j=0;j<22;j++)g.add('cone',fx+(rng()-.5)*dx*.3,.2,-FZ+1+rng()*(2*FZ-2),.12,.35+rng()*.4,.12,hex(j%2?'#a8e07a':'#4f9a35'))}}}

  if(modeled){
    /* cracks (water shortfall) */
    const nCr=Math.round((1-(row.wsF==null?1:row.wsF))*70);for(let c=0;c<nCr;c++){let x=-FX+1+rng()*(2*FX-2),z=-FZ+1+rng()*(2*FZ-2),a=rng()*6.28;
      for(let s=0;s<3;s++){const L=.8+rng()*1.1,nx=x+Math.cos(a)*L,nz=z+Math.sin(a)*L;g.stick([x,.36,z],[nx,.36,nz],.07,hex('#241408'),'cube');x=nx;z=nz;a+=(rng()-.5)*1.8}}
    /* erosion gullies (low soil score) */
    if(Sk&&Sk.soil<45)for(let c=0;c<Math.round((45-Sk.soil)/5);c++){let x=-FX+2+rng()*(2*FX-4),z=FZ-.4;for(let s=0;s<4;s++){const nx=x+(rng()-.5)*1.6,nz=z-1.5-rng();g.stick([x,.03,z],[nx,.03,nz],.3,hex('#6b3d17'),'cube');x=nx;z=nz}
      g.quad([x-.5,-.02,BZ+.03],[x-.5,-1.2,BZ+.03],[x+.5,-1.2,BZ+.03],[x+.5,-.02,BZ+.03],hex('#6b3d17'),.1)}
    /* plants (gaps = pest/disease loss) */
    const type=GLYPH3[cr.id]||'bush',bucket=Math.min(4,Math.floor(clamp(Yeff,0,1)*4.99)),fg=G3('g-h'+bucket),dk=hex(['#5f4518','#5b5a14','#44661a','#2b6a1c','#1a5420'][bucket]);
    const nP=nP0,dz=2*FZ/nP,R0=Math.min(dx,dz)*.5*(cr.cat==='orchard'?1:.9);
    const miss=clamp((1-(row.pestF==null?1:row.pestF))*1.5+(1-Yeff)*.12,0,.5),shadow=mix(soil,[0,0,0],.26);
    for(let j=0;j<nP;j++)for(let i=0;i<nR;i++){const x=rowX(i)+(rng()-.5)*dx*.08,z=-FZ+dz*(j+.5)+(rng()-.5)*dz*.12;
      if(rng()<miss){g.add('disc',x,.36,z,R0*.55,1,R0*.4,hex('#3b2412'),{ry:rng()*3});g.stick([x,.36,z],[x+R0*.3,R0*.35,z+R0*.1],R0*.04,hex('#7a5a2a'));g.stick([x+R0*.3,R0*.35,z+R0*.1],[x+R0*.5,.4,z],R0*.03,hex('#7a5a2a'));continue}
      const R=R0*(.55+.6*clamp(Yeff,0,1.1))*(.9+.2*rng())*ageS*runS;
      g.add('disc',x+R*.1,.355,z+R*.1,R*.58,1,R*.58,shadow,{jit:0});
      g.cur=[x,.34,z,1];const before=g.a.length;plant(g,type,cr.id,x,z,R,Y||0,bearing,fg,dk,rng);g.cur=[0,0,0,0];
      for(let q=before+1;q<g.a.length;q+=9)g.a[q]+=.34}          // stand plants on the bed
    /* roots, drawn just in front of the cut faces under each row */
    const rl=Math.min(DEPTH-1.5,root*(DEPTH-TOP)*.6*clamp(Yeff+.25,.4,1)+TOP),rc=hex('#f3e8cc');
    for(let i=0;i<nR;i++){const x=rowX(i);for(const zf of[BZ+.06,-BZ-.06]){let px=x,py=-.2;for(let s=0;s<4;s++){const nx=px+(rng()-.5)*1.4,ny=py-rl/4;g.stick([px,py,zf],[nx,ny,zf],.1-s*.018,rc,'cube');
          if(s<3){const bx=nx+(rng()<.5?-1:1)*(.8+rng()),by=ny-rl/8;g.stick([nx,ny,zf],[bx,by,zf],.05,rc,'cube')}px=nx;py=ny}}}
    for(let j=0;j<6;j++){const z=-FZ+(j+.5)*2*FZ/6;for(const xf of[BX+.06,-BX-.06]){let pz=z,py=-.2;for(let s=0;s<4;s++){const nz=pz+(rng()-.5)*1.4,ny=py-rl/4;g.stick([xf,py,pz],[xf,ny,nz],.1-s*.018,rc,'cube');pz=nz;py=ny}}}
  }
  /* puddles (wet year) */
  if(wet)for(let c=0;c<4;c++){const x=-FX+3+rng()*(2*FX-6),z=-FZ+3+rng()*(2*FZ-6),s=1.6+rng()*1.8;g.add('disc',x,.4,z,s*1.4,1,s,hex('#7db3dc'),{jit:.03,ry:rng()*3});g.add('disc',x-.4,.41,z-.3,s*.5,1,s*.2,[1,1,1],{jit:0,ry:.3})}
  /* clouds (lit) */
  /* clouds live in the sky backdrop (screen space, drift as you turn) so they never block the field */
  const cc=wet?hex('#7c8d9c'):[1,1,1],clouds=[];for(let c=0;c<(wet?9:dry?0:5);c++){const bx=rng()*2.6,by=wet?.62+rng()*.3:.68+rng()*.25;for(let p=0;p<4;p++)clouds.push([bx+(p-1.5)*.07,by+(p%2)*.035,.07+rng()*.04,.04+rng()*.02,mix(cc,[1,1,1],p%2?.08:0)])}
  const lit=g.build();
  /* sun lives in the sky backdrop (screen space) so it is visible from every angle */
  const sun=wet?null:{r:dry?.13:.1,core:hex(dry?'#ffcf7a':'#fffbe0'),glow:mix(hex(sky[1]),hex(dry?'#ffb347':'#fff3b0'),.75)};
  /* growth animation: annual crops sprout from seedlings each season; established trees and vines leaf out from a bigger start */
  /* where this season's growth starts: seedlings for a new annual crop; last year's size when the same crop carries on;
     for trees and vines, last year's size (a new planting starts as a small sapling) */
  const growFrom=!modeled?1:per?(prevAge?clamp(prevAge/ageS,.3,1):.45):pos>0?clamp(sfOf(pos-1)/sfOf(pos),.3,1):.06;
  return{lit,sun,clouds,sky:sky.map(hex),fog:hex(sky[2]),wet,dry,growFrom,ripens:bearing,label:{crop:cr,Y,modeled,wetv,soil:Sk?Math.round(Sk.soil):null}}
}

/* ---------- tiny mat4 helpers (column-major) ---------- */
function persp(fov,asp,n,f){const t=1/Math.tan(fov/2);return[t/asp,0,0,0,0,t,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0]}
function lookAt(e,c,up){let z=[e[0]-c[0],e[1]-c[1],e[2]-c[2]],l=Math.hypot(...z);z=z.map(v=>v/l);let x=[up[1]*z[2]-up[2]*z[1],up[2]*z[0]-up[0]*z[2],up[0]*z[1]-up[1]*z[0]];l=Math.hypot(...x);x=x.map(v=>v/l);
  const y=[z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0]];return[x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-(x[0]*e[0]+x[1]*e[1]+x[2]*e[2]),-(y[0]*e[0]+y[1]*e[1]+y[2]*e[2]),-(z[0]*e[0]+z[1]*e[1]+z[2]*e[2]),1]}
function mul(a,b){const o=new Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++){let s=0;for(let k=0;k<4;k++)s+=a[k*4+r]*b[c*4+k];o[c*4+r]=s}return o}

/* ---------- shared camera (both views turn together) ---------- */
const HOME={yaw:.62,pitch:.5,dist:104,tx:0,ty:-3.5,tz:0};
const CAM=Object.assign({},HOME);let camAnim=null;
const F3={playing:false,spinOff:false};   // shared with game.js (window.FIELD3D)
const RENDS=new Set();let HINTED=false;const dirtyAll=()=>RENDS.forEach(r=>r.dirty=true);
function camEye(){const cp=Math.cos(CAM.pitch);return[CAM.tx+CAM.dist*cp*Math.sin(CAM.yaw),CAM.ty+CAM.dist*Math.sin(CAM.pitch),CAM.tz+CAM.dist*cp*Math.cos(CAM.yaw)]}
function resetCam(){camAnim={from:Object.assign({},CAM),t0:performance.now()}}

const VS=`attribute vec3 p;attribute vec3 n;attribute vec3 c;attribute vec4 b;uniform mat4 vp;uniform vec3 L;uniform vec3 eye;uniform float unlit;uniform vec2 fogR;uniform float grow;uniform float ripe;varying vec3 vc;varying float vf;
void main(){vec3 q=p;if(b.w>.5){float s=b.w>1.5?ripe*grow:grow;float sx=b.w>1.5?s:(.3+.7*s);q.xz=b.xz+(p.xz-b.xz)*sx;q.y=b.y+(p.y-b.y)*s;}
 gl_Position=vp*vec4(q,1.);if(unlit>.5){vc=c;vf=0.;return;}
 float d=max(dot(n,L),0.);vec3 hemi=mix(vec3(.42,.36,.30),vec3(.62,.68,.78),n.y*.5+.5);
 vc=c*(hemi*.85+vec3(1.,.96,.86)*d*.72);vf=smoothstep(fogR.x,fogR.y,distance(p,eye));}`;
const FS=`precision mediump float;varying vec3 vc;varying float vf;uniform vec3 fogC;void main(){gl_FragColor=vec4(mix(vc,fogC,vf*.55),1.);}`;

class Renderer{
  constructor(){const cv=this.canvas=document.createElement('canvas');cv.className='f3dcv';cv.tabIndex=0;cv.setAttribute('role','img');
    const gl=this.gl=cv.getContext('webgl',{antialias:true,alpha:false,preserveDrawingBuffer:true})   /* kept so the last frame can be copied for the year-to-year fade */;if(!gl)throw new Error('no webgl');
    const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(o));return o};
    const pg=this.pg=gl.createProgram();gl.attachShader(pg,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pg,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pg);gl.useProgram(pg);
    this.loc={p:gl.getAttribLocation(pg,'p'),n:gl.getAttribLocation(pg,'n'),c:gl.getAttribLocation(pg,'c'),b:gl.getAttribLocation(pg,'b')};
    ['vp','L','eye','unlit','fogR','fogC','grow','ripe'].forEach(u=>this.loc[u]=gl.getUniformLocation(pg,u));
    this.bLit=gl.createBuffer();this.bSun=gl.createBuffer();this.bSky=gl.createBuffer();this.bRain=gl.createBuffer();
    gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);gl.frontFace(gl.CCW);
    this.rain=Array.from({length:260},()=>[(Math.random()*2-1)*BX*1.3,Math.random()*34,(Math.random()*2-1)*BZ*1.3]);this.rainArr=new Float32Array(260*18);
    this.dirty=true;this.bind(cv);RENDS.add(this)}
  setScene(S){const gl=this.gl;if(this.S===S)return;if(this.S)this.fade();this.S=S;
    gl.bindBuffer(gl.ARRAY_BUFFER,this.bLit);gl.bufferData(gl.ARRAY_BUFFER,S.lit,gl.STATIC_DRAW);this.nLit=S.lit.length/13;this.t0=performance.now();
    const[a,b,c]=S.sky,v=(x,y,col)=>[x,y,.999,0,0,1,...col];
    gl.bindBuffer(gl.ARRAY_BUFFER,this.bSky);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([...v(-1,1,a),...v(-1,.1,b),...v(1,.1,b),...v(-1,1,a),...v(1,.1,b),...v(1,1,a),...v(-1,.1,b),...v(-1,-1,c),...v(1,-1,c),...v(-1,.1,b),...v(1,-1,c),...v(1,.1,b)]),gl.STATIC_DRAW);
    this.dirty=true}
  /* cross-fade: copy the frame on screen to a 2D canvas laid on top, then fade it out while the new year grows in */
  fade(){const cv=this.canvas;if(!cv.isConnected||cv.width<2||(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches))return;
    const sn=this.snap||(this.snap=Object.assign(document.createElement('canvas'),{className:'f3dsnap'}));sn.setAttribute('aria-hidden','true');
    if(sn.width!==cv.width||sn.height!==cv.height){sn.width=cv.width;sn.height=cv.height}
    try{sn.getContext('2d').drawImage(cv,0,0)}catch(e){return}
    if(this.fadeAnim)this.fadeAnim.cancel();this.fadeAnim=sn.animate([{opacity:1},{opacity:0}],{duration:850,easing:'ease-in-out',fill:'forwards'})}
  place(){if(this.snap&&this.canvas.parentNode)this.canvas.after(this.snap)}
  attrs(lit){const gl=this.gl,L=this.loc,st=lit?52:36;for(const[k,o]of[['p',0],['n',12],['c',24]]){gl.enableVertexAttribArray(L[k]);gl.vertexAttribPointer(L[k],3,gl.FLOAT,false,st,o)}
    if(L.b<0)return;if(lit){gl.enableVertexAttribArray(L.b);gl.vertexAttribPointer(L.b,4,gl.FLOAT,false,st,36)}else{gl.disableVertexAttribArray(L.b);gl.vertexAttrib4f(L.b,0,0,0,0)}}
  draw(now){const gl=this.gl,cv=this.canvas,S=this.S;if(!S)return;
    const dpr=Math.min(2,window.devicePixelRatio||1),w=Math.max(1,Math.round(cv.clientWidth*dpr)),h=Math.max(1,Math.round(cv.clientHeight*dpr));
    if(cv.width!==w||cv.height!==h){cv.width=w;cv.height=h;this.dirty=true}
    const RM=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches,ph=RM?1:clamp((now-(this.t0||0))/1900,0,1);
    const ease=x=>1-Math.pow(1-x,3),gw=S.growFrom+(1-S.growFrom)*ease(clamp(ph/.75,0,1)),rp=S.ripens?clamp((ph-.7)/.3,0,1):0;
    if(ph<1)this.dirty=true;
    if(!this.dirty&&!S.wet)return;this.dirty=false;
    gl.viewport(0,0,w,h);gl.clearColor(...S.fog,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);const L=this.loc;
    /* sky backdrop */
    gl.disable(gl.DEPTH_TEST);gl.uniformMatrix4fv(L.vp,false,[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);gl.uniform1f(L.unlit,1);
    gl.bindBuffer(gl.ARRAY_BUFFER,this.bSky);this.attrs();gl.drawArrays(gl.TRIANGLES,0,12);
    {const a=[],asp=w/h,cx=.3,cy=.7,ring=(r,col,cx,cy,ry=r)=>{for(let i=0;i<24;i++){const t0=i/24*6.283,t1=(i+1)/24*6.283;a.push(cx,cy,.998,0,0,1,...col,cx+Math.cos(t0)*r/asp,cy+Math.sin(t0)*ry,.998,0,0,1,...col,cx+Math.cos(t1)*r/asp,cy+Math.sin(t1)*ry,.998,0,0,1,...col)}};
      if(S.sun){ring(S.sun.r*1.9,S.sun.glow,cx,cy);ring(S.sun.r,S.sun.core,cx,cy)}
      for(const[bx,by,rx,ry,col]of S.clouds){const x=((bx-CAM.yaw*.25)%2.6+2.6)%2.6-1.3;ring(rx*asp*.9,col,x,by,ry)}
      if(a.length){gl.disable(gl.CULL_FACE);gl.bindBuffer(gl.ARRAY_BUFFER,this.bSun);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(a),gl.DYNAMIC_DRAW);this.attrs();gl.drawArrays(gl.TRIANGLES,0,a.length/9);gl.enable(gl.CULL_FACE)}}
    gl.enable(gl.DEPTH_TEST);
    const eye=camEye(),VP=mul(persp(.68,w/h,1,600),lookAt(eye,[CAM.tx,CAM.ty,CAM.tz],[0,1,0]));
    gl.uniformMatrix4fv(L.vp,false,VP);
    /* light rides with the camera (upper-left, behind the viewer) so whichever side you turn to stays readable */
    const fx=Math.sin(CAM.yaw),fz=Math.cos(CAM.yaw),lv=[-fz*.45+fx*.5,.78,fx*.45+fz*.5],ll=Math.hypot(...lv);gl.uniform3f(L.L,lv[0]/ll,lv[1]/ll,lv[2]/ll);gl.uniform3fv(L.eye,eye);gl.uniform2f(L.fogR,CAM.dist*.6,CAM.dist*2.2);gl.uniform3fv(L.fogC,S.fog);
    gl.uniform1f(L.unlit,0);gl.uniform1f(L.grow,gw);gl.uniform1f(L.ripe,rp);gl.bindBuffer(gl.ARRAY_BUFFER,this.bLit);this.attrs(true);gl.drawArrays(gl.TRIANGLES,0,this.nLit);
    if(S.wet){const dt=Math.min(.05,(now-(this.last||now))/1000);this.last=now;const A=this.rainArr,rc=hex('#4d6a85');
      this.rain.forEach((d,i)=>{d[1]-=dt*38;d[0]-=dt*6;if(d[1]<.5){d[1]=30+Math.random()*4;d[0]=(Math.random()*2-1)*BX*1.3;d[2]=(Math.random()*2-1)*BZ*1.3}
        A.set([d[0],d[1],d[2],0,1,0,...rc, d[0]+.16,d[1]+1.1,d[2],0,1,0,...rc],i*18)});
      gl.uniform1f(L.unlit,1);gl.bindBuffer(gl.ARRAY_BUFFER,this.bRain);gl.bufferData(gl.ARRAY_BUFFER,A,gl.DYNAMIC_DRAW);this.attrs();gl.drawArrays(gl.LINES,0,this.rain.length*2)}}
  bind(cv){const P=new Map();
    const hide=()=>{if(!HINTED){HINTED=true;document.querySelectorAll('.f3dhint').forEach(e=>e.classList.add('gone'))}};
    cv.addEventListener('contextmenu',e=>e.preventDefault());
    cv.addEventListener('pointerdown',e=>{F3.spinOff=true;cv.setPointerCapture(e.pointerId);P.set(e.pointerId,{x:e.clientX,y:e.clientY,pan:e.button===2||e.shiftKey});camAnim=null;cv.classList.add('grab');hide()});
    const up=e=>{P.delete(e.pointerId);if(!P.size)cv.classList.remove('grab')};cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
    cv.addEventListener('pointermove',e=>{const p=P.get(e.pointerId);if(!p)return;const dx=e.clientX-p.x,dy=e.clientY-p.y;
      if(P.size===2){const[a,b]=[...P.values()],d0=Math.hypot(a.x-b.x,a.y-b.y);p.x=e.clientX;p.y=e.clientY;const d1=Math.hypot(a.x-b.x,a.y-b.y);if(d0>0)CAM.dist=clamp(CAM.dist*d0/d1,30,190)}
      else if(p.pan){const s=CAM.dist*.0016,cy=Math.cos(CAM.yaw),sy=Math.sin(CAM.yaw);CAM.tx=clamp(CAM.tx-(dx*cy)*s,-40,40);CAM.tz=clamp(CAM.tz-(-dx*sy)*s,-40,40);CAM.ty=clamp(CAM.ty+dy*s,-20,20);p.x=e.clientX;p.y=e.clientY}
      else{CAM.yaw-=dx*.0085;CAM.pitch=clamp(CAM.pitch+dy*.0075,-.45,1.5);p.x=e.clientX;p.y=e.clientY}
      dirtyAll()});
    cv.addEventListener('wheel',e=>{e.preventDefault();F3.spinOff=true;camAnim=null;CAM.dist=clamp(CAM.dist*Math.exp(e.deltaY*(e.deltaMode?.05:.0012)),30,190);dirtyAll();hide()},{passive:false});
    cv.addEventListener('dblclick',()=>resetCam());
    cv.addEventListener('keydown',e=>{const k=e.key;let h=true;if(k==='ArrowLeft')CAM.yaw+=.12;else if(k==='ArrowRight')CAM.yaw-=.12;else if(k==='ArrowUp')CAM.pitch=clamp(CAM.pitch+.08,-.45,1.5);else if(k==='ArrowDown')CAM.pitch=clamp(CAM.pitch-.08,-.45,1.5);
      else if(k==='+'||k==='=')CAM.dist=clamp(CAM.dist*.9,30,190);else if(k==='-'||k==='_')CAM.dist=clamp(CAM.dist*1.1,30,190);else if(k==='0'||k==='Home')resetCam();else h=false;if(h){e.preventDefault();dirtyAll();hide()}})}
}

/* ---------- render loop: only draws canvases that are on the page and changed (or raining) ---------- */
let lastNow=0;
function loop(now){const dt=Math.min(.05,(now-(lastNow||now))/1000);lastNow=now;
  /* while the simulation plays, the camera turns slowly (stops once you drag or zoom; off with reduced motion) */
  if(F3.playing&&!F3.spinOff&&!camAnim&&!(window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)){CAM.yaw-=dt*.09;dirtyAll()}
  if(camAnim){const f=clamp((now-camAnim.t0)/550,0,1),e=f<.5?2*f*f:1-Math.pow(-2*f+2,2)/2;let dy=HOME.yaw-camAnim.from.yaw;dy=Math.atan2(Math.sin(dy),Math.cos(dy));
    for(const k in HOME)CAM[k]=camAnim.from[k]+((k==='yaw'?camAnim.from.yaw+dy:HOME[k])-camAnim.from[k])*e;if(f>=1)camAnim=null;dirtyAll()}
  if(!document.hidden)RENDS.forEach(r=>{if(r.canvas.isConnected)r.draw(now)});requestAnimationFrame(loop)}

/* ---------- glue: fieldSVG() now returns a placeholder that a persistent 3D canvas moves into ---------- */
let ok=null;const R={},PEND={},CACHE=new Map(),EID=new WeakMap();let eidN=0;
function webgl(){if(ok!=null)return ok;try{const c=document.createElement('canvas');ok=!!(window.WebGLRenderingContext&&c.getContext('webgl'))}catch(e){ok=false}return ok}
function sceneFor(p){if(!EID.has(p.E))EID.set(p.E,++eidN);const key=p.k+'|'+p.t+'|'+EID.get(p.E)+'|'+(p.Sk?Math.round(p.Sk.soil):'');
  let s=CACHE.get(key);if(!s){s=buildScene(p.k,p.Sk,p.E,p.t);CACHE.set(key,s);if(CACHE.size>80)CACHE.delete(CACHE.keys().next().value)}return s}
function mount(){document.querySelectorAll('.f3d:not([data-m])').forEach(el=>{el.dataset.m='1';const k=el.dataset.k,p=PEND[k];if(!p)return;
  try{const r=R[k]||(R[k]=new Renderer());el.prepend(r.canvas);r.place();r.setScene(sceneFor(p));r.place();r.canvas.setAttribute('aria-label',el.dataset.aria||'3D field');r.dirty=true}
  catch(e){console.warn('3D field view unavailable, using 2D',e);ok=false;el.outerHTML=fieldSVG2D(p.k,p.Sk,p.E,p.t)}})}

function field3D(k,Sk,E,t){
  if(!webgl())return fieldSVG2D(k,Sk,E,t);
  PEND[k]={k,Sk,E,t};queueMicrotask(mount);
  const r=E[k].first[t-1],row=r.rows[0],slot=r.slot,cr=slot.crop&&CROPS_G[slot.crop],modeled=cr&&!row.unmodeled,Y=modeled?row.Y:null,pidx=r.pidx,wet=pidx>1.3,dry=pidx<.75;
  const miss=modeled?clamp((1-(row.pestF==null?1:row.pestF))*1.5+(1-(Y>0||!cr.bear?Y:.55))*.12,0,.5):0,tags=[];
  tags.push(wet?'<span class="fpt wet">Wet year</span>':dry?'<span class="fpt dry">Dry year</span>':'<span class="fpt">Typical rain</span>');
  if(modeled){if(row.wsF<.92)tags.push('<span class="fpt dry">Water short</span>');if(row.heatF<.93)tags.push('<span class="fpt dry">Heat stress</span>');if(row.frostF<.95)tags.push('<span class="fpt wet">Frost</span>');if(miss>.08)tags.push('<span class="fpt bad">Pest gaps</span>')}
  {const run=E[k].first;let pos=0,len=1;if(cr){for(let j=t-2;j>=0&&run[j]&&run[j].slot.crop===cr.id;j--)pos++;len=pos+1;for(let j=t;j<run.length&&run[j]&&run[j].slot.crop===cr.id;j++)len++}
    const per=!!(cr&&cr.perennial&&cr.id!=='alfalfa'),m=row&&row.mat;
    if(per&&modeled)tags.push(`<span class="fpt grow">${pxe('sprout')} ${m>=1?'Full production':m>0?`Growing · ${Math.round(m*100)}% of a full crop`:'Young · not bearing yet'}</span>`);
    else if(len>1&&modeled)tags.push(`<span class="fpt grow">${pxe('sprout')} Year ${pos+1} of ${len} · ${pos+1<len?'still growing':'full size'}</span>`)}
  if(slot.cover)tags.push('<span class="fpt ok">Winter cover</span>');
  const yp=!cr?'fallow':!modeled?'n/a':Y==null?'–':Y===0?'not bearing':fmt(Y*100)+'%',ycol=Y==null?'#888':scol(Y*100),wetv=row&&row.wet!=null?row.wet:null;
  const aria=`3D field for ${cr?cr.name:'fallow'}, yield ${yp}. Drag to rotate, scroll to zoom.`;
  return`<div class="f3d" data-k="${k}" data-aria="${esc(aria)}">
   <div class="fpb tl">${cr?cropIco(cr.id,22)+' '+esc(cr.name):'Fallow (bare soil)'}</div><div class="fpb tr" style="--c:${ycol}">Yield <b>${yp}</b></div>
   <div class="fpb bl">${tags.join('')}</div>
   <div class="f3dsoil">${Sk?'Soil score '+Math.round(Sk.soil):''}${wetv!=null?(Sk?' · ':'')+'<i></i>NASA soil wetness '+wetv.toFixed(2):''}</div>
   ${modeled||!cr?'':'<div class="f3dnm">Crop not modeled — no plants drawn</div>'}
   <button type="button" class="f3dreset" title="Reset view (double-click the field)" aria-label="Reset 3D view">${window.pxe?pxe('reset',16):'⟲'}</button>
   <div class="f3dhint${HINTED?' gone':''}" aria-hidden="true">Drag to turn · scroll to zoom</div></div>`}

if(typeof fieldSVG2D==='function'){
  window.fieldSVG=field3D;
  document.addEventListener('click',e=>{if(e.target.closest&&e.target.closest('.f3dreset'))resetCam()});
  new MutationObserver(()=>{if(document.querySelector('.f3d:not([data-m])'))mount()}).observe(document.documentElement,{childList:true,subtree:true});
  requestAnimationFrame(loop);
}
Object.assign(F3,{buildScene,CAM,resetCam,prefetch:(k,Sk,E,t)=>{if(webgl())sceneFor({k,Sk,E,t})}});window.FIELD3D=F3;
})();

'use strict';
/* Pixel-art crop & cover icons (original artwork, 20×20 grid).
   Each sprite is a stack of layers; every layer is filled, auto-shaded (light top-left, shadow bottom-right)
   and given a 1-px dark outline, which gives the chunky "game sprite" look. Load after icons.js:
   the sprites replace the vector CROP_ICO / COVER_ICO drawings, so ico('crop',id) returns pixel art everywhere. */
(function(){
const N=20,K='#1d1420',S=48/N;
/* shapes: functions (x,y) -> inside?  Coordinates are continuous; pixel i has its centre at i+.5 */
const E=(cx,cy,rx,ry,a=0)=>{const r=a*Math.PI/180,c=Math.cos(r),s=Math.sin(r);return(x,y)=>{const dx=x-cx,dy=y-cy,u=dx*c+dy*s,v=-dx*s+dy*c;return u*u/(rx*rx)+v*v/(ry*ry)<=1}};
const C=(cx,cy,r)=>E(cx,cy,r,r);
const R=(x0,y0,x1,y1)=>(x,y)=>x>=x0&&x<=x1&&y>=y0&&y<=y1;
const P=pts=>(x,y)=>{let c=false;for(let i=0,j=pts.length-1;i<pts.length;j=i++){const[xi,yi]=pts[i],[xj,yj]=pts[j];if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)c=!c}return c};
const U=(...f)=>(x,y)=>f.some(g=>g(x,y));
const I=(a,b)=>(x,y)=>a(x,y)&&b(x,y);
const X=(a,b)=>(x,y)=>a(x,y)&&!b(x,y);
const L=(x0,y0,x1,y1,w=.55)=>(x,y)=>{const dx=x1-x0,dy=y1-y0,t=Math.max(0,Math.min(1,((x-x0)*dx+(y-y0)*dy)/(dx*dx+dy*dy||1)));const ex=x0+t*dx-x,ey=y0+t*dy-y;return ex*ex+ey*ey<=w*w};
/* palettes: [light, base, shadow] */
const RED=['#ff7d68','#e2342a','#9c1b1f'],ORANGE=['#ffc061','#f3891d','#b45a0f'],YEL=['#fff29c','#f5cf33','#b88f1b'],GOLD=['#fbe7a0','#e0b13f','#9c7418'],
 GRN=['#aee66f','#5ab53a','#2c7524'],DKG=['#76c24e','#2f8a2a','#185a1c'],LGRN=['#eef8b6','#c3e47f','#82b04a'],STEM=['#9fd36a','#4f9a34','#2a5f1c'],
 BRN=['#c98f57','#8b5a2d','#55331a'],TAN=['#f0c792','#c58d52','#80532a'],PUR=['#b97fdb','#7d3bab','#4a1a6c'],WHT=['#ffffff','#ece8df','#b6ae9f'],
 CREAM=['#fbf0cf','#e3cd98','#a89060'],PEACH=['#ffc6a0','#f4875c','#bf4f38'],MAROON=['#ff7a86','#c8283a','#7a1022'];
const W='#ffffff';
/* layer helpers */
const lay=(s,c,o={})=>({s,c,...o});
const dots=(list,c)=>({d:list.map(p=>[p[0],p[1],p[2]||c])});
function build(layers){
  const g=Array.from({length:N},()=>Array(N).fill(null));
  for(const l of layers){
    if(l.d){for(const[x,y,c]of l.d)if(x>=0&&y>=0&&x<N&&y<N)g[y][x]=c;continue}
    const ins=(x,y)=>x>=0&&y>=0&&x<N&&y<N&&l.s(x+.5,y+.5);
    let x0=N,y0=N,x1=-1,y1=-1;
    for(let y=0;y<N;y++)for(let x=0;x<N;x++)if(ins(x,y)){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y)}
    if(x1<0)continue;
    if(l.o!==false)for(let y=0;y<N;y++)for(let x=0;x<N;x++)if(!ins(x,y)&&(ins(x-1,y)||ins(x+1,y)||ins(x,y-1)||ins(x,y+1)))g[y][x]=K;
    const cx=(x0+x1+1)/2,cy=(y0+y1+1)/2,hw=Math.max(1,(x1-x0+1)/2),hh=Math.max(1,(y1-y0+1)/2),pal=Array.isArray(l.c)?l.c:[l.c,l.c,l.c];
    for(let y=0;y<N;y++)for(let x=0;x<N;x++)if(ins(x,y)){
      const d=((x+.5-cx)/hw+(y+.5-cy)/hh)/2,br=!ins(x+1,y)||!ins(x,y+1),tl=!ins(x-1,y)||!ins(x,y-1);
      let c=pal[1];if(d>.42||(br&&d>.05))c=pal[2];else if(tl&&d<-.2)c=pal[0];g[y][x]=c}
    if(l.shine){const sx=Math.round(x0+(x1-x0)*.28),sy=Math.round(y0+(y1-y0)*.28);if(ins(sx,sy)){g[sy][sx]=W;if(ins(sx,sy+1)&&y1-y0>5)g[sy+1][sx]=W;if(ins(sx+1,sy)&&x1-x0>7)g[sy][sx+1]=W}}
  }
  let out='';
  for(let y=0;y<N;y++){let x=0;while(x<N){const c=g[y][x];if(!c){x++;continue}let e=x;while(e+1<N&&g[y][e+1]===c)e++;
    out+=`<rect x="${(x*S).toFixed(1)}" y="${(y*S).toFixed(1)}" width="${((e-x+1)*S).toFixed(1)}" height="${S.toFixed(1)}" fill="${c}"/>`;x=e+1}}
  return`<g shape-rendering="crispEdges">${out}</g>`}

/* reusable parts */
const leafPair=(cx,cy,c=GRN)=>[lay(E(cx-2.6,cy,2.8,1.2,-25),c),lay(E(cx+2.6,cy,2.8,1.2,25),c)];
const stem=(x,y0,y1,c=BRN)=>lay(R(x,y0,x+1,y1),c);
const grain=(x,y,c)=>[lay(E(x-1.6,y,1.7,1.05,-35),c),lay(E(x+1.6,y,1.7,1.05,35),c)];
const wheatLike=c=>[stem(9.5,8,19,c),...grain(10,15.5,c),...grain(10,12.5,c),...grain(10,9.5,c),...grain(10,6.5,c),lay(E(10,3.8,1.1,1.9),c)];
const grapes=c=>[stem(9.5,1.5,4.5),lay(E(13.6,4,3,1.4,-20),GRN),
  ...[[5.6,7],[10,7],[14.4,7],[7.8,10.8],[12.2,10.8],[5.6,14.6],[10,14.6],[14.4,14.6],[7.8,18],[12.2,18]].filter((p,i)=>i!==5&&i!==7).map(([x,y])=>lay(C(x,y,2.25),c,{shine:true}))];
const poppy=(cx,cy,s=1)=>[lay(E(cx-2.4*s,cy,2.6*s,3.4*s,-20),ORANGE),lay(E(cx+2.4*s,cy,2.6*s,3.4*s,20),ORANGE),lay(E(cx,cy-.6*s,2.2*s,3.2*s),['#ffd47a','#f7a02a','#c4650f'])];

const SPR={
 tomato:[lay(E(10,12.2,7.6,6.6),RED,{shine:true}),lay(E(7.2,6.6,2.9,1.2,-15),GRN),lay(E(12.8,6.6,2.9,1.2,15),GRN),lay(E(10,6.6,1.3,2.2),GRN),stem(9.5,3,5,STEM)],
 strawberry:[lay(U(P([[3,8],[17,8],[15.5,13.5],[10,19.2],[4.5,13.5]]),E(10,9,7,3.2)),RED,{shine:true}),
  dots([[6,10],[10,10],[14,10],[8,12],[12,12],[6,14],[10,14],[13,14],[8,16],[11,16]],'#ffe27a'),
  lay(E(6.8,6.4,3.2,1.3,-20),GRN),lay(E(13.2,6.4,3.2,1.3,20),GRN),lay(E(10,5.6,1.4,2.4),GRN),stem(9.5,2,4,STEM)],
 lettuce:[lay(E(10,12,8.4,7),DKG),lay(E(10,11.4,6.6,5.6),GRN),lay(E(10,10.6,4.2,3.8),LGRN,{shine:true}),dots([[10,14],[10,15],[9,16],[11,16],[7,12],[13,12]],'#2c7524')],
 broccoli:[lay(P([[7.5,11],[12.5,11],[13.5,19],[6.5,19]]),LGRN),lay(C(5.5,9.5,3.8),DKG),lay(C(14.5,9.5,3.8),DKG),lay(C(10,6.2,4.4),DKG,{shine:true}),lay(C(10,10.6,3.4),DKG),
  dots([[4,8],[9,4],[11,6],[14,8],[16,10],[6,11],[10,10]],'#7fca52')],
 spinach:[stem(9.5,14,19,STEM),lay(E(10,9,6.4,8,0),DKG,{shine:true}),dots([[10,3],[10,4],[10,5],[10,6],[10,7],[10,8],[10,9],[10,10],[10,11],[10,12],[10,13],[8,7],[7,6],[12,7],[13,6],[8,11],[7,10],[12,11],[13,10]],'#9ad66a')],
 carrot:[lay(E(7.5,4,1.3,3,-28),GRN),lay(E(10,3.4,1.3,3.2),GRN),lay(E(12.5,4,1.3,3,28),GRN),
  lay(P([[5.5,7],[14.5,7],[10.6,19.4],[9.4,19.4]]),ORANGE,{shine:true}),dots([[7,9],[8,9],[12,11],[13,11],[8,13],[9,13],[11,15],[10,17]],'#b45a0f')],
 garlic:[lay(P([[8.6,3],[11.4,3],[13,9],[7,9]]),CREAM),lay(E(10,13,7.4,5.8),WHT,{shine:true}),dots([[7,10],[7,11],[7,12],[7,13],[7,14],[10,9],[10,10],[10,11],[10,12],[10,13],[10,14],[10,15],[13,10],[13,11],[13,12],[13,13],[13,14]],'#cfc6b6'),
  dots([[7,19],[9,19],[11,19],[13,19],[8,18],[12,18]],'#8b6a44')],
 onion:[lay(E(8.6,3.4,1.1,3,-15),GRN),lay(E(11.4,3.4,1.1,3,15),GRN),lay(U(C(10,12.2,7),P([[8,5],[12,5],[14,8],[6,8]])),['#f6cf8f','#c98a45','#8a5420'],{shine:true}),
  dots([[7,8],[6,10],[6,12],[6,14],[13,8],[14,10],[14,12],[14,14],[10,7],[10,9],[10,11],[10,13],[10,15]],'#a76a32'),dots([[8,19],[10,19],[12,19]],'#6e4a26')],
 melon:[/* cantaloupe / melons: a netted cantaloupe behind, a watermelon slice in front */
  lay(C(7.6,9,6.6),['#f1e2b4','#c9ae74','#8a7042'],{shine:true}),dots([[4,6],[6,5],[8,4],[10,5],[5,8],[7,7],[9,7],[11,8],[4,10],[6,10],[8,9],[10,10],[5,12],[7,12],[9,12]],'#f8efd2'),stem(7.5,1.6,2.8,BRN),
  lay(I(C(13,11.4,6.6),(x,y)=>y>12),['#9be07a','#3f9a32','#1f5a1c']),lay(I(C(13,11.4,5.3),(x,y)=>y>12),['#ffa3a3','#ee4a5a','#b8243a'],{o:false}),
  dots([[10,14],[13,14],[16,14],[11,16],[15,16],[13,17]],'#2a1a1a')],
 artichoke:[stem(9,16,19,STEM),lay(E(10,14.6,5.6,3),['#b9d48a','#6f9a45','#3e5f23']),lay(E(6.4,11.4,3.2,3.2,-20),['#c6dd98','#7aa64c','#43662a']),lay(E(13.6,11.4,3.2,3.2,20),['#c6dd98','#7aa64c','#43662a']),
  lay(E(10,9.6,3.6,3.4),['#cfe3a2','#84b056','#4a6e2e']),lay(E(7.6,6.4,2.2,2.6,-15),['#d8eab0','#8ebb60','#52783a']),lay(E(12.4,6.4,2.2,2.6,15),['#d8eab0','#8ebb60','#52783a']),lay(E(10,4,1.8,2.2),['#e2f0bc','#9bc56c','#5c8240']),
  dots([[10,2],[7,5],[13,5]],'#a24fa8')],
 corn:[lay(E(10,10,4.4,8),YEL,{shine:true}),dots([[8,6],[10,6],[12,6],[9,8],[11,8],[8,10],[10,10],[12,10],[9,12],[11,12],[8,14],[10,14],[12,14],[9,16],[11,16]],'#d9a61f'),
  lay(P([[2.5,19],[6.5,8],[8.8,19.4]]),GRN),lay(P([[17.5,19],[13.5,8],[11.2,19.4]]),GRN)],
 cotton:[stem(9.5,15,19.5),lay(P([[3.5,13.5],[10,11],[16.5,13.5],[10,18]]),BRN),lay(C(6.4,10.6,3.6),WHT),lay(C(13.6,10.6,3.6),WHT),lay(C(10,6.4,3.8),WHT,{shine:true}),lay(C(10,11.2,3.4),WHT)],
 wheat:wheatLike(GOLD),
 safflower:[stem(9.5,12,19.5,STEM),lay(E(6,15.5,2.8,1.1,-30),GRN),lay(E(14,14,2.8,1.1,30),GRN),
  ...[[-3.2,-3.5],[0,-5],[3.2,-3.5],[-4.5,-.5],[4.5,-.5]].map(([dx,dy])=>lay(E(10+dx*.8,7+dy*.8,1.3,2.6,Math.atan2(dx,-dy)*180/Math.PI),['#ffd36b','#f28a1e','#c4461a'])),
  lay(E(10,10,3.4,2.8),GRN,{shine:true})],
 sunflower:[stem(9.5,13,19.5,STEM),lay(E(14,15.5,3,1.3,25),GRN),
  ...Array.from({length:8},(_,i)=>{const a=i*Math.PI/4;return lay(E(10+Math.cos(a)*4.6,8+Math.sin(a)*4.6,1.8,3,a*180/Math.PI+90),YEL)}),
  lay(C(10,8,3.2),BRN,{shine:true}),dots([[9,7],[11,8],[10,9]],'#3a2210')],
 garbanzo:[lay(C(6.6,13,3.8),['#f9e4b4','#ddb77a','#a07a42'],{shine:true}),lay(C(13.4,13,3.8),['#f9e4b4','#ddb77a','#a07a42'],{shine:true}),lay(C(10,7.4,3.8),['#f9e4b4','#ddb77a','#a07a42'],{shine:true}),
  dots([[8,10],[11,6],[15,12]],'#b88c50')],
 drybean:[lay(X(E(7,10.6,3.4,5.4,-18),C(9.8,10.4,1.2)),['#e9a283','#a3472b','#5f1f10'],{shine:true}),lay(X(E(13.4,10,3.4,5.4,18),C(10.8,9.8,1.2)),['#e9a283','#a3472b','#5f1f10'],{shine:true}),
  dots([[6,13],[7,9],[14,13],[13,8],[5,11]],'#f2dcc0')],
 sorghum:[stem(9.5,12,19.5,['#c4d98a','#8aa84a','#55702a']),lay(E(5.4,15,3.6,1.2,-30),GRN),lay(E(14.6,13,3.6,1.2,30),GRN),
  ...[[10,2.6],[8.4,4.6],[11.6,4.6],[10,6.4],[7.6,7.2],[12.4,7.2],[9,9],[11,9],[10,10.8]].map(([x,y])=>lay(C(x,y,1.55),['#eaa070','#b8622e','#6e3214']))],
 rice:[lay(P([[10,19.5],[10,8],[11,8],[11,19.5]]),['#d8e58a','#9cb84a','#5f7a26']),lay(E(6.4,15,3.6,1,-35),GRN),
  ...[[11.5,3.5],[13.5,5],[15,7],[15.8,9.4],[16,12]].map(([x,y])=>lay(E(x,y,1.25,1.8,-30),['#fbf0a8','#e3c95a','#9a8226'])),
  lay(L(10.5,9,11.5,3.5),['#c9c060','#a19a40','#6a6524']),lay(E(9,6,1.2,1.7,20),['#fbf0a8','#e3c95a','#9a8226']),lay(E(8.4,9,1.2,1.7,10),['#fbf0a8','#e3c95a','#9a8226'])],
 alfalfa:[stem(9.5,9,19.5,STEM),lay(C(6.6,14,2),GRN),lay(C(13.4,13,2),GRN),lay(C(10,15.4,1.8),GRN),
  ...[[10,3.4],[8,5.4],[12,5.4],[10,7],[8.4,8.6],[11.6,8.6]].map(([x,y])=>lay(C(x,y,1.75),PUR,{shine:false}))],
 almond:[lay(E(10,11.6,5.6,7.6,18),TAN,{shine:true}),dots([[8,9],[11,8],[9,12],[12,12],[10,15],[13,15],[8,14]],'#9e6a36'),lay(E(14.6,3.8,3,1.3,-30),GRN),stem(10.5,3,5)],
 walnut:[lay(C(10,11,7.6),['#e0b07a','#9a6a3c','#5a3a1c'],{shine:true}),dots([[10,4],[10,5],[10,6],[10,7],[10,8],[10,9],[10,10],[10,11],[10,12],[10,13],[10,14],[10,15],[10,16],[10,17]],'#4a2d14'),
  dots([[6,8],[7,9],[6,12],[7,13],[13,9],[14,10],[13,13],[14,14],[7,16],[13,16]],'#7a4f28')],
 pistachio:[lay(E(10,11.4,5.6,7.6,22),['#f8ecce','#d9c08e','#9c8150'],{shine:true}),lay(E(11.2,10.6,2.4,4.6,22),['#d8f08a','#86b23a','#4f7a1c']),dots([[12,9],[11,12]],'#5c3d6a')],
 peach:[/* peaches / plums: a peach behind, a plum in front */
  stem(7.5,2,4.6,BRN),lay(E(10.8,3.4,2.9,1.2,-25),GRN),lay(C(7.6,10.4,6.2),PEACH,{shine:true}),dots([[7,5],[7,6],[6,7],[6,8],[6,9]],'#c25640'),dots([[4,12],[5,13],[3,10]],'#e2654a'),
  lay(E(13.4,13.8,4.8,5.4,12),PUR,{shine:true}),dots([[14,9],[14,10],[15,11]],'#4a1a6c'),dots([[12,12],[11,14],[12,15]],'#c9a6e8')],
 citrus:[lay(C(10,11.6,7.8),ORANGE,{shine:true}),dots([[7,13],[12,9],[14,13],[9,16],[12,15],[6,9]],'#e07612'),lay(E(13.8,4,3.2,1.4,-25),DKG),stem(9.5,2,5)],
 avocado:[lay(U(E(10,12.4,6.6,6.8),E(10,6.8,4.4,5)),['#6f9a3a','#3f6a1c','#1f3a0c']),lay(U(E(10,12.6,5,5.2),E(10,7.4,3,3.8)),['#f4f8b8','#d7e486','#a6bb5a'],{o:false}),
  lay(C(10,13,2.9),['#c48a52','#8b5a2d','#55331a'],{shine:true})],
 olive:[lay(E(14,3.8,3.4,1.2,-20),['#d4dcae','#93a46a','#5b6a3a']),stem(10,2.5,6),lay(E(7.6,12,3.8,5,-18),['#cdd57a','#8a9a35','#4d5a1c'],{shine:true}),lay(E(12.8,11.4,3.6,4.8,18),['#8e6aa0','#4a3058','#211429'],{shine:true})],
 pomegranate:[lay(P([[7.5,2.5],[9,5],[10,2],[11,5],[12.5,2.5],[12.5,7],[7.5,7]]),MAROON),lay(C(10,12,7.6),MAROON,{shine:true}),dots([[13,15],[14,14],[12,16]],'#9a1a2c')],
 date:[stem(9.5,1,5),lay(L(10,4,6,7),BRN),lay(L(10,4,14,6),BRN),
  lay(E(6.6,10.6,2.6,4.2,-12),['#e8a466','#9a4c1c','#55240a'],{shine:true}),lay(E(13.6,10,2.6,4.2,12),['#e8a466','#9a4c1c','#55240a'],{shine:true}),lay(E(10,14.4,2.6,4.2),['#e8a466','#9a4c1c','#55240a'],{shine:true})],
 jojoba:[lay(E(6,5,4,1.6,-25),['#d4e0ac','#94a86a','#5b6e3e']),lay(E(14,5,4,1.6,25),['#d4e0ac','#94a86a','#5b6e3e']),stem(9.5,3,9,['#a7b08a','#6f7a52','#434a30']),
  lay(E(7.6,13.4,3.4,4.4,-15),['#cfa070','#7a4f2a','#40260e'],{shine:true}),lay(E(12.6,13,3.4,4.4,15),['#b6c87e','#7b934a','#495c26'],{shine:true})],
 winegrape:grapes(PUR),
 tablegrape:grapes(['#ecf8ad','#a9cf4a','#64912a']),
 wildflower:[stem(9.5,10,19.5,STEM),lay(E(6,16,3,1.2,-30),GRN),lay(E(14,14.6,3,1.2,30),GRN),...poppy(10,7),dots([[10,9],[10,10]],'#f9e27a')],
 bunchgrass:[...[[-6,-28,7],[-3,-14,8],[0,0,8.6],[3,14,8],[6,28,7],[-1,-6,6.4],[2,8,6.6]].map(([dx,a,h])=>lay(E(10+dx*.9,19.5-h,.85,h,a),['#e2ea9a','#a7bf52','#61792a'])),
  dots([[4,6],[16,6],[10,3],[7,4],[13,4]],'#9a5ab4')],
 elderberry:[lay(E(5,16,3.4,1.3,-25),GRN),lay(E(15,16,3.4,1.3,25),GRN),stem(9.5,10,19.5,['#c0786a','#8a3b2b','#55201a']),
  ...[[4.5,8.5],[7.5,6],[10,5],[12.5,6],[15.5,8.5],[6,10],[9,8],[11,8],[14,10],[8,11.2],[12,11.2],[10,10.4],[5.5,6.2],[14.5,6.2],[10,2.6],[7.5,3.4],[12.5,3.4]].map(([x,y])=>lay(C(x,y,1.35),['#8a7ad0','#3d2f80','#1e1545']))]
};
const COV={
 rye:wheatLike(['#dcf0a0','#8cbf4a','#4f7f22']),
 vetch:[lay(L(6,19,8,6,.6),STEM),lay(L(14,19,12,8,.6),STEM),lay(E(5,13,2.4,1.1,-30),GRN),lay(E(10,11,2.4,1.1,30),GRN),lay(E(15.4,14,2.4,1.1,30),GRN),
  ...[[8,4],[6,6],[9.6,6.6],[12,4.8],[14,6.6],[11.6,8.6]].map(([x,y])=>lay(E(x,y,1.5,1.9),['#c79bf0','#8a4fc4','#4f2482']))],
 mustard:[stem(9.5,9,19.5,STEM),lay(E(6.4,15,3.4,1.5,-35),GRN),lay(E(13.6,12.6,3.4,1.5,35),GRN),
  ...[[10,3],[7.4,4.6],[12.6,4.6],[10,6.4],[6.4,7.8],[13.6,7.8],[8.6,9],[11.4,9]].map(([x,y])=>lay(C(x,y,1.6),YEL))],
 clover:[stem(9.5,11,19.5,STEM),lay(C(5.6,15.4,1.9),GRN),lay(C(7.6,13.4,1.9),GRN),lay(C(14.4,15.4,1.9),GRN),lay(C(12.4,13.4,1.9),GRN),
  lay(E(10,6.6,3.8,5.6),['#ff8a9a','#d8304a','#8a1428'],{shine:true}),dots([[8,5],[11,6],[9,8],[12,9],[10,10],[8,10]],'#a81e36')],
 nativemix:[stem(5.5,8,19.5,STEM),stem(13.5,11,19.5,STEM),...[2,4,6,8].map(y=>lay(C(6,y+1,1.6),['#a8b4f4','#5d67d0','#2f3584'])),...poppy(14,8,.75)]
};
/* crops outside California get their own sprites too (they used to borrow a look-alike's art) */
const awn=(x0,y0,x1,y1,c)=>lay(L(x0,y0,x1,y1,.42),c,{o:false});
const OAT=['#f8f2cc','#dccf88','#9c904e'],BARLEY=['#f6efb0','#d4c260','#8f7f2e'],RYE=['#dfe6c6','#a3b27c','#66744a'],
 SOY=['#d3e29a','#94b04e','#58702a'],NUT=['#f3d9a6','#cfa266','#8a6232'],BLU=['#9fb4f4','#4561c8','#1f2d78'],BEET=['#fffaf0','#ecdcc0','#ad9670'];
Object.assign(SPR,{
 graincorn:[lay(E(10,9.6,4.2,7.6),['#ffd36b','#e8961c','#a8600c'],{shine:true}),
  dots([[8,5],[10,5],[12,5],[9,7],[11,7],[8,9],[10,9],[12,9],[9,11],[11,11],[8,13],[10,13],[12,13]],'#b8680e'),
  lay(P([[10,19.5],[3.5,9],[5.5,8],[10.4,15.5]]),TAN),lay(P([[10,19.5],[16.5,9],[14.5,8],[9.6,15.5]]),TAN),stem(9.5,17,19.5,TAN)],
 soybean:[stem(9.5,1.5,4,STEM),lay(E(10.5,10.5,3.4,8.4,28),SOY,{shine:true}),
  ...[[8,5.2],[10.5,10.5],[13,15.8]].map(([x,y])=>lay(C(x,y,2.5),SOY,{shine:true})),
  dots([[6,4],[7,8],[9,13],[12,18],[15,13],[14,9]],'#c9a35a')],
 peanut:[lay(U(C(7.6,7,4.4),C(12.4,13.6,4.4),E(10,10.3,2.8,3.6,-35)),NUT,{shine:true}),
  dots([[6,5],[8,6],[6,8],[9,9],[11,12],[13,12],[12,15],[14,15],[10,14]],'#a87c45')],
 oats:[stem(9.5,3,19.5,STEM),awn(10,5,5.5,8.5,STEM[1]),awn(10,5,14.5,8.5,STEM[1]),awn(10,9,4.5,13,STEM[1]),awn(10,9,15.5,13,STEM[1]),
  ...[[5.2,10.2,-12],[14.8,10.2,12],[4.2,14.6,-8],[15.8,14.6,8],[10,3,0]].map(([x,y,a])=>lay(E(x,y,1.25,2.4,a),OAT))],
 barley:[stem(9.5,11,19.5,['#e6eba8','#b3c262','#6f7d32']),
  ...[3.4,6.4,9.4,12.4].flatMap(y=>[lay(E(8.6,y+1,1.5,1.2,-30),BARLEY),lay(E(11.4,y+1,1.5,1.2,30),BARLEY)]),
  awn(8,4,3.5,.3,'#c9b55a'),awn(12,4,16.5,.3,'#c9b55a'),awn(7.6,7,2.6,4.2,'#c9b55a'),awn(12.4,7,17.4,4.2,'#c9b55a'),awn(10,3,10,0,'#c9b55a')],
 rye:[stem(9.5,12,19.5,RYE),lay(E(10.8,7.2,1.7,6,14),RYE,{shine:true}),
  awn(9.6,2.6,7.4,0,'#8c9a64'),awn(11.6,2.2,13.4,0,'#8c9a64'),awn(9.2,6,6.4,3.6,'#8c9a64'),awn(12.4,6,15,3.4,'#8c9a64'),
  lay(E(6,16,2.8,1,-30),SOY),lay(E(14,15,2.8,1,30),SOY)],
 canola:[stem(9.5,8,19.5,STEM),awn(10,14,5.5,11.5,DKG[1]),awn(10,16,14.5,13.5,DKG[1]),
  ...[[10,4.4],[6.2,7.6],[13.8,7.6]].flatMap(([x,y])=>[...[[0,-1.4],[1.4,0],[0,1.4],[-1.4,0]].map(([dx,dy])=>lay(C(x+dx,y+dy,1.25),YEL,{o:false})),lay(C(x,y,.7),'#c98a10',{o:false})])],
 lentil:[...[[6.4,15.2,-10],[13.4,15.4,12],[10,12.4,0],[5.6,10.4,8],[14.2,10.2,-8],[10,7.4,4],[8,17.6,0],[12.2,17.8,0]].map(([x,y,a])=>lay(E(x,y,2.6,1.6,a),['#f9bf8a','#dc7a3e','#9a4418'],{shine:true}))],
 potato:[lay(U(E(10.6,11.4,7.4,5.6,-18),C(6,9.2,3.6)),['#e6be86','#b37d44','#6e4620'],{shine:true}),
  dots([[6,8],[9,10],[13,9],[12,13],[15,11],[8,14]],'#6e4620')],
 sugarbeet:[lay(E(7.2,4.4,1.9,3.6,-30),DKG),lay(E(12.8,4.4,1.9,3.6,30),DKG),lay(E(10,3.4,1.5,3.4),GRN),
  lay(U(E(10,10.4,5.4,3.4),P([[4.8,10.4],[15.2,10.4],[10.5,19.5],[9.5,19.5]])),BEET,{shine:true}),dots([[7,12],[12,13],[9,15],[11,17]],'#c8b28a')],
 tobacco:[lay(E(9.4,11.4,5.8,8.2,28),['#dcec8e','#93c23c','#517f22'],{shine:true}),lay(L(5.6,18.4,13,4.4,.45),'#eef5b8',{o:false}),
  dots([[8,13],[7,12],[10,10],[9,9],[11,8],[12,9],[10,14],[11,14]],'#6f9a30'),stem(15.5,4,8,STEM),lay(C(15.8,3,2),['#ffc8da','#f07aa6','#a83c6c'])],
 pecan:[lay(E(10,10.6,4.4,8.2,22),['#dd9a5e','#9c5a2a','#5a2e12'],{shine:true}),
  dots([[9,4],[10,6],[10,8],[11,10],[11,12],[12,14],[12,16],[8,8],[8,11],[9,14],[13,8],[13,11]],'#3e1f0a')],
 apple:[lay(U(C(7.2,12,5.4),C(12.8,12,5.4),E(10,14.4,6,5)),['#ff8f7c','#d42a3a','#8a1222'],{shine:true}),stem(9.5,3,7,BRN),
  lay(E(13.2,4.4,2.9,1.3,-25),GRN),dots([[14,10],[15,12],[13,15]],'#f6c23a')],
 cherry:[lay(L(6.6,10.6,11,2.6,.5),STEM,{o:false}),lay(L(13.4,11,11,2.6,.5),STEM,{o:false}),lay(E(14.2,3.4,2.7,1.2,-20),GRN),
  lay(C(6.4,14,3.7),MAROON,{shine:true}),lay(C(13.6,14.6,3.7),MAROON,{shine:true})],
 blueberry:[lay(E(14.4,4.2,3,1.3,-25),GRN),stem(9.5,2,5,BRN),
  ...[[6.8,13.6],[13.2,13.6],[10,8.2]].map(([x,y])=>lay(C(x,y,3.9),BLU,{shine:true})),
  dots([[6,11],[7,11],[6.5,10],[12,11],[13,11],[12.5,10],[9,6],[10,6],[9.5,5]].map(([x,y])=>[Math.round(x),Math.round(y)]),'#162050')]
});
const pixel=spr=>()=>build(spr);
for(const id in SPR)if(typeof CROP_ICO!=='undefined')CROP_ICO[id]=pixel(SPR[id]);
for(const id in COV)if(typeof COVER_ICO!=='undefined')COVER_ICO[id]=pixel(COV[id]);
/* logo: pixel wheat on a round field badge */
if(typeof UI_ICO!=='undefined'){const w=build(SPR.wheat);UI_ICO.logo=()=>`<circle cx="24" cy="24" r="23" fill="#3a2a1d"/><circle cx="24" cy="24" r="20.5" fill="none" stroke="#e8b84a" stroke-width="1.4"/><g transform="translate(3.6 3.2) scale(.85)">${w}</g>`}

/* ---------- pixel stand-ins for interface emoji (same 20×20 grid, shading and outline as the crops) ---------- */
const BLUE=['#9fd8ff','#3a8fe0','#1f5aa0'],SKY=['#e6f6ff','#a9d8f3','#5d9cc4'],GREY=['#f2f4f5','#c4cbd0','#7d878f'],STEEL=['#dfe6ea','#98a6af','#56636b'],
 DGREY=['#aab4bb','#6b7780','#3b444b'],SILV=['#ffffff','#d9dee2','#9aa4ab'],CASH=['#c8f0b0','#69b84a','#2f6e23'];
const EMO={
 drop:[lay(U(C(10,12.6,5.2),P([[10,1.6],[5.2,10.6],[14.8,10.6]])),BLUE,{shine:true})],
 drops:[lay(U(C(7,13.4,3.6),P([[7,5.6],[3.6,12],[10.4,12]])),BLUE,{shine:true}),lay(U(C(14,8.4,2.8),P([[14,2.4],[11.4,7.4],[16.6,7.4]])),BLUE)],
 rain:[lay(U(C(6.4,8.6,3.4),C(11,6.6,4.4),C(15,9,3.2),R(4,9,16.6,12)),WHT),
  lay(L(6,14.4,5,17.6,.6),BLUE),lay(L(10.4,14.4,9.4,17.6,.6),BLUE),lay(L(14.8,14.4,13.8,17.6,.6),BLUE)],
 storm:[lay(U(C(6.4,7.6,3.4),C(11,5.6,4.4),C(15,8,3.2),R(4,8,16.6,11)),DGREY),lay(P([[11,10],[7.4,15],[10,15],[8.4,19],[13.6,13.2],[10.8,13.2],[12.6,10]]),YEL)],
 sat:[lay(R(2,7.5,6.5,12.5),BLUE),lay(R(13.5,7.5,18,12.5),BLUE),lay(R(6.5,9.4,13.5,10.6),STEEL),lay(R(7.8,6.6,12.2,13.4),SILV,{shine:true}),
  lay(L(10,6.6,10,3.4,.5),STEEL),lay(C(10,3,1.3),RED)],
 warn:[lay(P([[10,1.6],[1.6,17.6],[18.4,17.6]]),YEL),dots([[10,7],[10,8],[10,9],[10,10],[10,11],[10,14]],'#1d1420')],
 stop:[lay(P([[7,2],[13,2],[18,7],[18,13],[13,18],[7,18],[2,13],[2,7]]),RED),lay(R(5.5,8.6,14.5,11.4),[W,W,'#f3d6d6'],{o:false})],
 check:[lay(C(10,10,8),GRN,{shine:true}),lay(U(L(6,10.4,8.8,13.2,.9),L(8.8,13.2,14.2,7,.9)),[W,W,W],{o:false})],
 info:[lay(C(10,10,8),BLUE,{shine:true}),lay(U(R(9,8.6,11,14.6),R(9,5,11,6.8)),[W,W,W],{o:false})],
 cycle:[lay(X(C(10,10,7.6),C(10,10,4.4)),GRN),lay(P([[13,1.8],[18.6,5.4],[12.4,7.8]]),GRN),lay(P([[7,18.2],[1.4,14.6],[7.6,12.2]]),GRN)],
 calendar:[lay(R(2.5,4,17.5,17.5),WHT),lay(R(2.5,4,17.5,7.5),RED),lay(R(5.5,2,7.5,5.5),STEEL),lay(R(12.5,2,14.5,5.5),STEEL),
  dots([[6,10],[9,10],[12,10],[15,10],[6,13],[9,13],[12,13],[6,15],[9,15]],'#6b7780')],
 bulb:[lay(C(10,8,6),YEL,{shine:true}),lay(R(7.6,13,12.4,17.6),STEEL),dots([[8,15],[9,15],[10,15],[11,15]],'#56636b')],
 bug:[lay(L(4,8,8,10,.5),'#3b2a1d'),lay(L(16,8,12,10,.5),'#3b2a1d'),lay(L(3.6,14,8,13,.5),'#3b2a1d'),lay(L(16.4,14,12,13,.5),'#3b2a1d'),
  lay(E(10,12.6,4.6,5.8),GRN,{shine:true}),lay(C(10,5.6,2.8),DKG),lay(L(8.4,3.4,6.6,1.4,.4),'#3b2a1d'),lay(L(11.6,3.4,13.4,1.4,.4),'#3b2a1d'),dots([[10,9],[10,11],[10,13],[10,15]],'#185a1c')],
 basket:[lay(C(7,8.4,2.6),RED,{shine:true}),lay(C(12.6,8,2.6),GRN,{shine:true}),lay(C(10,6.4,2.2),ORANGE),
  lay(X(E(10,10,7.4,6.4),E(10,10,5.6,4.8)),TAN),lay(P([[2,10],[18,10],[15.6,18],[4.4,18]]),BRN),dots([[5,12],[8,12],[11,12],[14,12],[6,15],[9,15],[12,15],[15,14]],'#c98f57')],
 hourglass:[lay(R(3,1.6,17,3.6),BRN),lay(R(3,16.4,17,18.4),BRN),lay(U(P([[4.6,3.6],[15.4,3.6],[10,10]]),P([[10,10],[4.6,16.4],[15.4,16.4]])),SKY),
  lay(U(P([[7.6,6],[12.4,6],[10,9]]),P([[10,12.6],[6.4,16.4],[13.6,16.4]])),GOLD,{o:false})],
 cash:[lay(R(1.6,5,18.4,15),CASH),lay(C(10,10,2.8),LGRN,{o:false}),dots([[4,7],[16,13],[4,13],[16,7]],'#2f6e23')],
 scale:[lay(R(9.2,4,10.8,16.6),BRN),lay(R(4,16,16,18),BRN),lay(R(2.6,4.4,17.4,6),GOLD),lay(L(4,6,2.6,11,.4),'#9c7418'),lay(L(4,6,5.4,11,.4),'#9c7418'),
  lay(L(16,6,14.6,11,.4),'#9c7418'),lay(L(16,6,17.4,11,.4),'#9c7418'),lay(I(C(4,10.6,3.2),R(0,10.6,8,14)),GOLD),lay(I(C(16,10.6,3.2),R(12,10.6,20,14)),GOLD),lay(C(10,3.6,1.6),GOLD)],
 thermo:[lay(U(R(8.4,2,11.6,13),C(10,2.4,1.6)),WHT),lay(C(10,15,3.6),RED,{shine:true}),lay(R(9.2,7,10.8,13),RED,{o:false}),dots([[13,4],[13,7],[13,10]],'#7d878f')],
 mask:[lay(U(E(10,9.6,7.4,8),R(2.6,3,17.4,8)),GOLD,{shine:true}),dots([[6,7],[7,7],[12,7],[13,7],[6,8],[7,8],[12,8],[13,8],[6,12],[7,13],[8,13],[9,13],[10,13],[11,13],[12,13],[13,12]],'#1d1420')],
 fire:[lay(P([[10,1.6],[16,9],[16.4,13.6],[13.6,17.6],[6.4,17.6],[3.6,13.6],[4.4,8.6],[7,11],[7.4,5.6]]),ORANGE),lay(P([[10,8],[13,12.6],[12.4,16.4],[7.6,16.4],[7,12.6]]),YEL,{o:false})],
 snow:[lay(L(10,1.6,10,18.4,.75),SKY),lay(L(2.8,5.8,17.2,14.2,.75),SKY),lay(L(2.8,14.2,17.2,5.8,.75),SKY),lay(C(10,10,2),[W,W,W])],
 flask:[lay(R(7.6,1.6,12.4,7.6),WHT),lay(P([[7.6,7],[12.4,7],[18,18],[2,18]]),WHT),lay(P([[5.6,12],[14.4,12],[17.2,17.2],[2.8,17.2]]),GRN,{o:false}),dots([[9,15],[12,14]],'#eef8b6')],
 sprout:[lay(L(10,18.4,10,9,.7),STEM),lay(E(6,8.6,4.2,2.2,25),GRN,{shine:true}),lay(E(14,6.6,4.2,2.2,-25),DKG),lay(R(4,17.4,16,18.6),BRN)],
 scope:[lay(X(E(10,6.6,6.4,6),U(E(10,6.6,4.6,4.2),R(0,0,20,6.6))),STEEL),lay(L(10,12.6,10,15,.6),STEEL),lay(C(10,16,2.8),SILV,{shine:true}),lay(C(3.6,6,1.4),DGREY),lay(C(16.4,6,1.4),DGREY)],
 magnifier:[lay(L(12.6,12.6,18,18,1.1),BRN),lay(X(C(8.4,8.4,6.6),C(8.4,8.4,4.4)),STEEL),lay(C(8.4,8.4,4.4),SKY,{o:false,shine:true})]
};
/* controls, stars and score categories (the simulation page uses these instead of text symbols and drawn icons) */
const BTN=[W,'#f4efe4','#cfc6b4'];
Object.assign(EMO,{
 play:[lay(P([[5,2.6],[17,10],[5,17.4]]),BTN)],
 pause:[lay(R(4.4,3,8.4,17),BTN),lay(R(11.6,3,15.6,17),BTN)],
 prev:[lay(R(3,3,6,17),BTN),lay(P([[17,2.6],[7,10],[17,17.4]]),BTN)],
 next:[lay(R(14,3,17,17),BTN),lay(P([[3,2.6],[13,10],[3,17.4]]),BTN)],
 replay:[lay(X(X(C(10,10.6,7.4),C(10,10.6,4.2)),P([[10,10.6],[20,0],[20,10.6]])),BTN),lay(P([[11,0.6],[17.8,4.6],[11,8.6]]),BTN)],
 reset:[lay(X(X(C(10,10.6,7.4),C(10,10.6,4.2)),P([[10,10.6],[20,0],[20,10.6]])),STEEL),lay(P([[11,0.6],[17.8,4.6],[11,8.6]]),STEEL)],
 star:[lay(P([[10,1.2],[12.6,7],[18.8,7.4],[14,11.4],[15.6,17.8],[10,14.4],[4.4,17.8],[6,11.4],[1.2,7.4],[7.4,7]]),YEL,{shine:true})],
 tick:[lay(U(L(4.2,10.4,8.4,14.6,1.35),L(8.4,14.6,15.8,5.6,1.35)),[W,W,'#e8efe2'])],
 soilcat:[lay(R(1.6,11,18.4,18.4),BRN),lay(R(1.6,11,18.4,12.6),['#6e4626','#5a3a1e','#4a2c12'],{o:false}),dots([[4,15],[8,16],[12,14],[16,16],[6,17],[14,17]],'#c98f57'),
  lay(L(10,11,10,5.6,.7),STEM),lay(E(6.6,5.4,3.4,1.8,25),GRN,{shine:true}),lay(E(13.4,4,3.4,1.8,-25),DKG)],
 coin:[lay(C(10,10,8.2),GOLD,{shine:true}),lay(X(C(10,10,6.2),C(10,10,5.4)),['#b88a10','#b88a10','#9c7418'],{o:false}),
  dots([[10,5],[11,6],[10,6],[9,6],[8,7],[9,8],[10,9],[11,10],[12,11],[11,12],[10,12],[9,12],[8,12],[10,13],[10,14],[10,15]],'#7a5a10')],
 shield:[lay(P([[10,1.4],[17.4,4.2],[17.4,10],[10,18.6],[2.6,10],[2.6,4.2]]),BLUE,{shine:true}),lay(U(L(6,9.8,8.8,12.8,1),L(8.8,12.8,14,6.8,1)),[W,W,W],{o:false})]
});
for(const id in EMO)if(typeof UI_ICO!=='undefined')UI_ICO['px-'+id]=pixel(EMO[id]);
/* score-category icons and the field sprout become pixel art everywhere they appear */
if(typeof CAT_ICO!=='undefined')Object.assign(CAT_ICO,{water:pixel(EMO.drop),soil:pixel(EMO.soilcat),n:pixel(EMO.flask),pest:pixel(EMO.bug),income:pixel(EMO.coin),resil:pixel(EMO.shield)});
if(typeof UI_ICO!=='undefined')UI_ICO.sprout=pixel(EMO.sprout);
/* pxe(name,px): a pixel icon sized to sit in a line of text, in place of an emoji */
window.pxe=(name,px=18)=>typeof ico==='function'&&UI_ICO['px-'+name]?`<span class="pxe">${ico('ui','px-'+name,px)}</span>`:'';
window.PIXEL_SPRITES=Object.keys(SPR).concat(Object.keys(COV));
})();

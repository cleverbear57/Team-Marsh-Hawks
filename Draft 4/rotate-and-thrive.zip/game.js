'use strict';
/* California Rotation Lab — compact one-page rotation explorer */
const U={loc:null,rec:null,recMsg:'',recState:'none',zone:null,soil:'loam',horizon:9,priority:'soil',alloc:100,seed:57,N:30,
  rots:{cur:[],prop:[]},sel:null,cq:{cur:'',prop:''},q:'',matches:[],nearby:null,msgSetup:'',mg:{equip:[],fert:'standard',irrig:'full'},msg:{cur:'',prop:''},
  sim:null,t:0,timer:null,sugRes:null,busy:false};
const PRI={soil:'Soil',water:'Water',output:'Income',resil:'Resilience'};
const RK={cur:{n:'Current',c:'#b5651d'},prop:{n:'Proposed',c:'#1b7f8c'}};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const money=x=>x==null?'n/a':usd(x);
const scol=v=>v==null?'#999':v<40?'#b42318':v<60?'#c87a1a':'#1d6b3c';
const ready=()=>U.rec&&(U.recState==='ready'||U.recState==='illustrative');
const copy=o=>JSON.parse(JSON.stringify(o));
const setup=()=>({zone:U.zone,soil:U.soil,horizon:U.horizon,priority:U.priority,allocPct:U.alloc,seed:U.seed});
function dataStatus(){const r=U.rec;return[['Weather',r?(r.status==='available'?'ok':'bad'):'warn',r?`${r.source} · ${r.years[0]}–${r.years[r.years.length-1]} (${r.n} complete years)`:'not loaded'],['Soil moisture',r&&r.Sw?'ok':'warn',r&&r.Sw?'NASA MERRA-2 root-zone soil wetness (via POWER), monthly 2001–2025 — sets starting soil water':'not available for this weather source'],['Soil texture','warn','Regional texture default — edit it; SSURGO lookup not wired in'],['Satellite fields (SMAP, GPM, ECOSTRESS, GRACE)','warn','Context only; not used inside the game model'],['Current rotation','warn','Default is an illustrative example']]}
function reset(){stop();U.sim=null;U.t=0;U.sugRes=null}
function stop(){if(U.timer){clearInterval(U.timer);U.timer=null}}

/* ---------- location ---------- */
function search(q){q=q.trim().toLowerCase();if(!q)return[];return GAZ.filter(g=>g.name.toLowerCase().includes(q)||g.county.toLowerCase().includes(q)).slice(0,8)}
function parseLL(q){const m=q.match(/^\s*(-?\d+(\.\d+)?)\s*[, ]\s*(-?\d+(\.\d+)?)\s*$/);return m?{lat:+m[1],lon:+m[3]}:null}
function distKm(a,b){return Math.hypot(a.lat-b.lat,(a.lon-b.lon)*Math.cos(a.lat*Math.PI/180))*111}
async function loadLoc(loc){
  reset();U.msgSetup='';U.nearby=null;U.matches=[];
  if(!inCalifornia(loc.lat,loc.lon)){U.loc=null;U.rec=null;U.recState='none';U.msgSetup='Outside California — pick a California place.';render();return}
  U.loc=loc;U.zone=zoneOf(loc.lat,loc.lon);U.soil=ZONE_SOIL[U.zone];U.recState='loading';render();
  let rec=null;if(loc.id)rec=cachedRecord(loc.id,loc.lat);
  if(!rec){try{rec=await liveRecord(loc.lat,loc.lon)}catch(e){U.nearby=GAZ.map(g=>({g,d:distKm(g,loc)})).sort((a,b)=>a.d-b.d)[0];U.recMsg='NASA POWER request failed.'}}
  if(rec){U.rec=rec;U.recState='ready';defaultRots()}else{U.rec=null;U.recState='failed'}
  render()}
function defaultRots(){U.rots.cur=[{crop:DEFAULT_CROP[U.zone],cover:null}];U.rots.prop=suggestRotation(U.rots.cur,U.zone);U.sel=null;U.cq={cur:'',prop:''}}
function runSearch(){if(!ready()||!U.rots.cur.length)return;U.busy=true;render();setTimeout(()=>{try{const r=searchRotations(U.rots.cur,setup(),U.rec,U.mg);reset();U.sugRes=r;if(r.list.length)U.rots.prop=copy(r.list[0].rot)}finally{U.busy=false;render()}},40)}
function useNearby(){const n=U.nearby;U.rec=cachedRecord(n.g.id,U.loc.lat);U.rec.source=`NASA POWER (cached for ${n.g.name}, ${fmt(n.d)} km away)`;U.recState='ready';defaultRots();render()}
function useSynthetic(){U.rec=syntheticRecord(U.zone,U.loc.lat,U.seed);U.recState='illustrative';defaultRots();render()}

/* ---------- crop search ---------- */
const FITORD={good:0,ok:1,poor:2,unmodeled:3};
function cropMatches(q){q=q.trim().toLowerCase();let L=Object.values(CROPS_G);
  if(!q)return L.filter(c=>fitOf(c.id,U.zone)==='good').slice(0,10);
  L=L.filter(c=>(c.name+' '+c.fam+' '+CAT_LABEL[c.cat]+' '+c.id+(c.cat==='native'?' california native':'')).toLowerCase().includes(q));
  const rank=c=>{const t=(c.name+' '+(c.cat==='native'?'california native':'')).toLowerCase(),ws=t.split(/[\s\/(),-]+/);return(ws.some(w=>w.startsWith(q))?0:10)+FITORD[fitOf(c.id,U.zone)]};
  return L.sort((a,b)=>rank(a)-rank(b)).slice(0,8)}
const sugBtn=(c,k)=>{const f=fitOf(c.id,U.zone);return`<button class="sug" draggable="true" data-drag="crop:${c.id}" data-act="addcrop" data-rot="${k}" data-id="${c.id}"><span class="e">${c.emoji}</span><span><b>${c.name}</b><small class="fit-${f}">${FIT_LABEL[f]}${c.cat==='native'?' · CA native':''}</small></span></button>`};

/* ---------- map ---------- */
function mapSVG(){const k=53.6,P=([lo,la])=>[(lo+124.6)*.8*k,(42.1-la)*k];const poly=CA_OUTLINE.map(p=>P(p).join(',')).join(' ');
  const dots=GAZ.map(g=>{const[x,y]=P([g.lon,g.lat]);return`<circle cx="${x}" cy="${y}" r="2.6" fill="#2d6a4f" opacity=".6"/>`}).join('');let pin='';if(U.loc){const[x,y]=P([U.loc.lon,U.loc.lat]);pin=`<circle cx="${x}" cy="${y}" r="8" fill="#c87a1a" stroke="#fff" stroke-width="2"/>`}
  return`<svg id="camap" viewBox="0 0 500 520" width="100%" style="max-width:240px;cursor:crosshair" role="img" aria-label="California map: click to place a pin"><polygon points="${poly}" fill="#eaf3ee" stroke="#2d6a4f" stroke-width="2"/>${dots}${pin}</svg>`}

/* ---------- sections ---------- */
function secLocation(){
  return`<div class="card"><div class="row" style="align-items:center"><h2 style="margin:0"><span class="num">1</span> Location</h2><div style="flex:0 0 auto"><button class="btn amber sm" data-act="demo">⚡ Demo</button></div></div>
  <input type="text" id="q" value="${esc(U.q)}" placeholder="Search a California town or county, or “lat, lon”" aria-label="Search location" autocomplete="off" style="margin-top:8px">
  <div id="res" class="results" ${U.matches.length?'':'hidden'}>${U.matches.map(g=>`<button data-act="pick" data-id="${g.id}">📍 ${esc(g.name)} <span class="mute">· ${esc(g.county)}</span></button>`).join('')}</div>
  ${U.msgSetup?`<div class="warnb">${esc(U.msgSetup)}</div>`:''}
  ${U.loc?`<div class="loc">📍 <b>${esc(U.loc.name||'Pin')}${U.loc.county?', '+esc(U.loc.county):''}</b> · ${ZONES[U.zone].name}</div>`:''}
  ${U.recState==='loading'?'<p>⏳ Loading…</p>':''}
  ${U.recState==='failed'?`<div class="warnb">${U.recMsg} ${U.nearby?`<button class="btn sm alt" data-act="nearby">Use ${esc(U.nearby.g.name)} data (${fmt(U.nearby.d)} km away)</button>`:''} <button class="btn sm alt" data-act="synth">Use illustrative weather (not NASA)</button></div>`:''}
  ${U.recState==='illustrative'?'<div class="warnb">Illustrative weather — not NASA data.</div>':''}
  ${U.rec&&U.recState==='ready'?`<div class="tiny">✔ ${esc(U.rec.source)} · ${U.rec.years[0]}–${U.rec.years[U.rec.years.length-1]}</div>`:''}
  <details><summary class="tiny">Map</summary>${mapSVG()}</details></div>`}

function slotHTML(k,i,s){const cr=s.crop&&CROPS_G[s.crop],sel=U.sel&&U.sel.rot===k&&U.sel.i===i;
  const opts=[['','No cover'],...Object.keys(COVERS).map(c=>[c,COVERS[c].emoji+' '+COVERS[c].name])];
  return`<div class="slot ${sel?'sel':''}" draggable="true" data-drag="slot:${k}:${i}" data-slot="${k}:${i}" tabindex="0" role="button" aria-label="Year ${i+1}: ${cr?cr.name:'empty'}" aria-pressed="${sel}">
    <div class="yr">Yr ${i+1}</div><div class="em">${cr?cr.emoji:'🟫'}</div><div class="nm">${cr?cr.name:'Fallow'}</div>
    <select class="cvsel" data-cv="${k}:${i}" aria-label="Winter cover year ${i+1}">${opts.map(([v,l])=>{const bad=v&&coverConflict(s.crop,v,U.zone);return`<option value="${v}" ${s.cover===v?'selected':''} ${bad?'disabled':''}>${l}</option>`}).join('')}</select>
    <div class="ctl"><button data-act="mvleft" data-rot="${k}" data-i="${i}" aria-label="Earlier" ${i===0?'disabled':''}>◀</button><button data-act="mvright" data-rot="${k}" data-i="${i}" aria-label="Later" ${i===U.rots[k].length-1?'disabled':''}>▶</button><button data-act="rmslot" data-rot="${k}" data-i="${i}" aria-label="Remove">✕</button></div></div>`}
function tagsHTML(rot){if(!rot.length)return'';const f=rotationFacts(rot,U.zone);let t=`<span class="tag">${f.len} yr · ${f.legumes} legume · ${f.covers} cover</span>`;
  if(f.perennial===f.len)t+=`<span class="tag">🌳 perennial</span>`;else if(f.minGap<2)t+=`<span class="tag bad">⚠ ${esc(f.worst)} every year</span>`;else if(f.minGap<3)t+=`<span class="tag warn">${esc(f.worst)} every ${f.minGap} yrs</span>`;else t+=`<span class="tag ok">✔ family repeats every ${f.minGap}+ yrs</span>`;
  if(f.unmodeled)t+=`<span class="tag warn">⚠ unmodeled crop</span>`;return t}
function editorHTML(k){const rot=U.rots[k],sel=U.sel&&U.sel.rot===k?U.sel:null,q=U.cq[k],sug=q?cropMatches(q):[],rec=!q?cropMatches(''):[];
  return`<div class="rotcard" style="--c:${RK[k].c}"><div class="row" style="align-items:center"><h3 style="margin:0;color:${RK[k].c}">${RK[k].n} rotation</h3>
   <div style="flex:0 0 auto;display:flex;gap:6px">${k==='prop'?`<button class="btn sm alt" data-act="usesug" ${U.busy?'disabled':''}>${U.busy?'⏳ Searching…':'✨ Suggest'}</button>`:''}<select data-preset="${k}" aria-label="Example rotation" style="width:auto"><option value="">Example…</option>${Object.keys(ROT_PRESETS).map(p=>`<option value="${p}">${ROT_PRESETS[p][0]}</option>`).join('')}</select></div></div>
  <div>${tagsHTML(rot)}</div>
  <div class="slots">${rot.map((s,i)=>slotHTML(k,i,s)).join('')}<button class="slot add" data-act="focussearch" data-rot="${k}" data-drag-add="${k}" aria-label="Add a year">＋</button></div>
  <input type="text" id="cq-${k}" data-cq="${k}" value="${esc(q)}" placeholder="${sel?`Replace year ${sel.i+1} with…`:'Add a crop (try “tom”, “almond”, “native”)'}" aria-label="Search crops" autocomplete="off">
  ${q?`<div class="results">${sug.length?sug.map(c=>sugBtn(c,k)).join(''):'<div style="padding:8px" class="mute">No match</div>'}</div>`:''}
  ${U.msg[k]?`<div class="note">${esc(U.msg[k])}</div>`:''}</div>`}
function sugPanel(){const r=U.sugRes;if(!r)return'';if(!r.list.length)return'<div class="note">No better rotation found for this location and priority.</div>';
  const emo=rot=>rot.map(s=>(CROPS_G[s.crop].emoji)+(s.cover?'<sup>'+COVERS[s.cover].emoji+'</sup>':'')).join(' → ');
  const dl=v=>v==null?'':`<span class="${v>=0?'up':'dn'}">${sgn(v,0)}</span>`;
  return`<div class="sugbox"><div class="tiny">Best of <b>${fmt(r.tested)}</b> rotations tested on ${esc(U.loc.name||'this')} NASA weather (${U.priority==='output'?'income':PRI[U.priority].toLowerCase()} first, income kept close to current):</div>${r.list.map((x,i)=>`<div class="cand"><span class="seq">${emo(x.rot)}</span><span class="tiny">${SCORE_CATS.filter(c=>['soil','water','income','resil'].includes(c[0])).map(c=>c[1]+dl(x.vs[c[0]])).join(' ')}</span><b style="color:${scol(x.ov)}">${Math.round(x.ov)}</b><button class="btn sm ${U.rots.prop&&JSON.stringify(U.rots.prop)===JSON.stringify(x.rot)?'':'alt'}" data-act="usecand" data-i="${i}">${JSON.stringify(U.rots.prop)===JSON.stringify(x.rot)?'In use':'Use'}</button></div>`).join('')}<div class="tiny">Numbers = change vs current. Searched in ${(r.ms/1000).toFixed(1)}s.</div></div>`}
function secRotations(){return`<div class="card"><h2><span class="num">2</span> Rotations</h2>${editorHTML('cur')}${editorHTML('prop')}${sugPanel()}</div>`}
function secRun(){const can=U.rots.cur.length&&U.rots.prop.length;
  return`<div class="card"><h2><span class="num">3</span> Run</h2>
  <div class="row" style="align-items:flex-end"><div class="sl"><div class="t"><label for="hz">Years</label><b>${U.horizon}</b></div><input type="range" id="hz" min="3" max="20" value="${U.horizon}" style="width:100%"></div>
  <div><div class="tiny">Priority</div><div class="seg wrap">${Object.keys(PRI).map(k=>`<button data-act="pri" data-v="${k}" class="${U.priority===k?'on':''}">${PRI[k]}</button>`).join('')}</div></div></div>
  <details><summary class="tiny">More settings</summary><div class="grid2" style="margin-top:8px"><div>
   <label for="soil" class="tiny">Soil texture</label><select id="soil">${Object.keys(SOILG).map(s=>`<option ${s===U.soil?'selected':''}>${s}</option>`).join('')}</select>
   <label for="alloc" class="tiny">Water limit ${U.alloc}%</label><input type="range" id="alloc" min="50" max="120" step="5" value="${U.alloc}" style="width:100%">
   <label for="fert" class="tiny">Fertilizer</label><select id="fert">${Object.keys(FERT).map(k=>`<option value="${k}" ${U.mg.fert===k?'selected':''}>${FERT[k].name}</option>`).join('')}</select>
   <label for="irrig" class="tiny">Irrigation</label><select id="irrig">${[['full','Full'],['deficit','Deficit 80%'],['drought','Drought-saver 60%']].map(([k,n])=>`<option value="${k}" ${U.mg.irrig===k?'selected':''}>${n}</option>`).join('')}</select></div>
   <div><div class="tiny">Equipment</div>${Object.keys(EQUIP).map(k=>{const e=EQUIP[k],o=U.mg.equip.includes(k);return`<label class="eq ${o?'own':''}" title="${esc(e.desc)}"><input type="checkbox" data-eq="${k}" ${o?'checked':''}><span class="e">${e.emoji}</span><div><b>${e.name}</b> ${money(e.price)}</div></label>`}).join('')}</div></div></details>
  <div style="margin-top:10px"><button class="btn big" data-act="run" ${can?'':'disabled'}>▶ Run simulation</button></div></div>`}

/* ---------- scoreboard (appears after Run, steps through the years) ---------- */
function yieldCol(y){if(y==null)return'#e5e5e5';const t=clamp((y-.4)/.6,0,1);return`hsl(${Math.round(t*115)},55%,${86-t*18}%)`}
function scoresAtT(k){const reps=U.sim.E[k].first.slice(0,U.t);return avgScores(reps,U.zone)}
function secScore(){
  if(!U.sim)return'';const E=U.sim.E,H=U.horizon,t=U.t,rec=U.rec,idx=E.cur.idx,ks=['cur','prop'],W=weightsFor(U.priority),S={cur:scoresAtT('cur'),prop:scoresAtT('prop')},ov={cur:overallOf(S.cur,U.priority),prop:overallOf(S.prop,U.priority)};
  const cell=v=>v==null?'<td class="sc">–</td>':`<td class="sc"><b style="color:${scol(v)}">${Math.round(v)}</b><span class="mb"><i style="width:${v}%;background:${scol(v)}"></i></span></td>`;
  const done=t>=H,pid=idx.map(i=>rec.annualP[i]/rec.meanP);
  const strip=`<div class="yrs">${idx.map((i,j)=>`<div class="yc ${j<t?'':'fut'}"><div class="wb"><i style="height:${clamp(pid[j]/1.8*100,6,100)}%;background:${pid[j]<.7?'#c87a1a':pid[j]>1.3?'#1b6f8c':'#8aa7b5'}"></i></div><small>${rec.years[i]}</small></div>`).join('')}</div>`;
  const swStrip=rec.Sw?`<div class="lane"><div class="ln" title="NASA MERRA-2 root-zone soil wetness in March (0 = dry, 1 = saturated)"><b>Soil wet</b></div><div class="yrs">${idx.map((i,j)=>{const v=rec.Sw[i][2];return`<div class="yc ${j<t?'':'fut'}" title="Year ${j+1}: March root-zone wetness ${v.toFixed(2)} (NASA)"><div class="wb"><i style="height:${clamp(v*100,6,100)}%;background:#8b6a43"></i></div><small>${v.toFixed(2)}</small></div>`}).join('')}</div></div>`:'';
  const lane=k=>`<div class="lane"><div class="ln" style="color:${RK[k].c}"><b>${RK[k].n}</b></div><div class="yrs">${E[k].first.map((r,j)=>{const cr=r.slot.crop&&CROPS_G[r.slot.crop],w=r.rows[0];return`<div class="yc ${j<t?'':'fut'} ${j===t-1?'now':''}" style="background:${j<t?(w.unmodeled?'#e9e2f7':yieldCol(w.Y)):'#f3f3f3'}" title="Year ${j+1}: ${cr?cr.name:'fallow'}${w.Y!=null?' · yield '+fmt(w.Y*100)+'%':''}">${cr?cr.emoji:'🟫'}${r.slot.cover?'<sup>'+COVERS[r.slot.cover].emoji+'</sup>':''}<small>${j<t?(w.unmodeled?'n/a':w.Y==null?'–':fmt(w.Y*100)+'%'):''}</small></div>`}).join('')}</div></div>`;
  const best=ov.prop==null||ov.cur==null?null:ov.prop>ov.cur+1?'prop':ov.cur>ov.prop+1?'cur':null;
  let end='';if(done){const o=outcome(S),pP=E.prop.ov.all.filter((v,i)=>v!=null&&E.cur.ov.all[i]!=null&&v>E.cur.ov.all[i]).length/U.N;
    end=`<div class="final"><span class="badge">${o.cat}</span> <span class="tiny">${esc(o.why)}</span><div class="tiny" style="margin-top:4px">Proposed beats Current in <b>${fmt(pP*100)}%</b> of ${U.N} other weather sequences.</div><div style="margin-top:6px"><button class="btn sm" data-act="export-json">⬇ JSON</button> <button class="btn sm alt" data-act="export-csv">⬇ CSV</button> <button class="btn sm alt" data-act="replay">↻ Replay</button> <button class="btn sm alt" data-act="newweather">🎲 New weather</button></div></div>`}
  return`<div class="card score" id="score"><div class="row" style="align-items:center"><h2 style="margin:0">📊 Scoreboard</h2><div class="ctlbar"><button class="btn sm alt" data-act="tprev" ${t<=1?'disabled':''} aria-label="Previous year">◀</button><button class="btn sm" data-act="tplay">${U.timer?'⏸ Pause':done?'↻ Replay years':'▶ Play'}</button><button class="btn sm alt" data-act="tnext" ${done?'disabled':''} aria-label="Next year">▶</button><b>Year ${t} / ${H}</b></div></div>
  <input type="range" id="tr" min="1" max="${H}" value="${t}" style="width:100%" aria-label="Year">
  <table class="sb"><tr><th></th><th style="color:${RK.cur.c}">Current</th><th style="color:${RK.prop.c}">Proposed</th></tr>
  ${SCORE_CATS.map(([c,e,l,d])=>`<tr title="${esc(d)}"><th>${e} ${l}${W[c]>.3?' ★':''}</th>${cell(S.cur&&S.cur[c])}${cell(S.prop&&S.prop[c])}</tr>`).join('')}
  <tr class="tot"><th>OVERALL</th>${['cur','prop'].map(k=>`<td class="sc">${ov[k]==null?'–':`<b style="font-size:24px;color:${scol(ov[k])}">${Math.round(ov[k])}</b>${best===k?'<div class="tiny">★ higher</div>':''}`}</td>`).join('')}</tr></table>
  <div class="lane"><div class="ln"><b>Rain</b></div>${strip}</div>${swStrip}${ks.map(lane).join('')}${end}
  <div class="tiny" style="margin-top:6px">0–100, higher is better · hover a row for its formula · ★ = your priority · <button class="lnk2" id="evBtn2">model &amp; limits</button></div></div>`}
function outcome(S){const c=S.cur,p=S.prop,key={soil:'soil',water:'water',output:'income',resil:'resil'}[U.priority],lab={soil:'Soil Builder',water:'Water Saver',income:'Harvest Booster',resil:'Resilience Builder'}[key];
  if(!c||!p)return{cat:'Insufficient evidence',why:'Outputs unavailable (unmodeled crop).'};
  if(JSON.stringify(U.rots.cur)===JSON.stringify(U.rots.prop))return{cat:'Same rotation',why:'Both rotations are identical.'};
  const dp=p[key]-c[key],di=p.income-c.income,nm=SCORE_CATS.find(x=>x[0]===key)[2];
  if(dp>=5&&di>=-5)return{cat:lab,why:`${nm} ${sgn(dp,0)}, income ${sgn(di,0)}.`};
  if(dp>=5)return{cat:'Tradeoff',why:`${nm} ${sgn(dp,0)} but income ${sgn(di,0)}.`};
  if(dp<=-5)return{cat:'Worse on your priority',why:`${nm} ${sgn(dp,0)}.`};
  return{cat:'No clear difference',why:`${nm} ${sgn(dp,0)} (within ±5).`}}

/* ---------- render ---------- */
function render(){
  const a=document.getElementById('app'),fid=document.activeElement&&document.activeElement.id,pos=window.scrollY;
  let h=secLocation();if(ready())h+=secRotations()+secRun()+secScore();else h+='<div class="card mute">Pick a location to start.</div>';
  a.innerHTML='<div class="narrow">'+h+'</div>';
  if(fid&&(fid==='q'||fid.startsWith('cq-'))){const q=document.getElementById(fid);if(q){q.focus();q.setSelectionRange(q.value.length,q.value.length)}}
  window.scrollTo(0,pos);
  const cm=document.getElementById('camap');if(cm)cm.onclick=e=>{const b=cm.getBoundingClientRect(),x=(e.clientX-b.left)/b.width*500,y=(e.clientY-b.top)/b.height*520;loadLoc({name:'Map pin',lat:+(42.1-y/53.6).toFixed(3),lon:+(x/(.8*53.6)-124.6).toFixed(3)})};
  const e2=document.getElementById('evBtn2');if(e2)e2.onclick=showEvidence}
function change(){reset();render()}
function runSim(){reset();U.sim={E:ensembleRotations({cur:U.rots.cur,prop:U.rots.prop},setup(),U.rec,U.mg,U.N)};U.t=1;render();play();setTimeout(()=>{const s=document.getElementById('score');s&&s.scrollIntoView({behavior:'smooth',block:'start'})},60)}
function play(){stop();if(!U.sim)return;if(U.t>=U.horizon)U.t=1;U.timer=setInterval(()=>{if(U.t>=U.horizon){stop();render();return}U.t++;render()},1100);render()}

/* ---------- exports ---------- */
function download(name,text,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)}
function exportJSON(){const E=U.sim.E,S={cur:scoresAtT('cur'),prop:scoresAtT('prop')};download('rotate-and-thrive-run.json',JSON.stringify({app:'Rotate & Thrive',version:4,exported:new Date().toISOString(),setup:setup(),management:U.mg,location:U.loc,dataStatus:dataStatus(),weather:{source:U.rec.source,sha256:U.rec.sha,exampleSourceYears:E.cur.idx.map(i=>U.rec.years[i]),resamplings:U.N},rotations:{current:U.rots.cur,proposed:U.rots.prop},scoresFinalYear:S,ensemble:Object.fromEntries(['cur','prop'].map(k=>[k,{overall:E[k].ov,categories:E[k].cat,numbers:E[k].num}])),outcome:outcome(S),caveats:ASSUMPTIONS},null,1),'application/json')}
function exportCSV(){const E=U.sim.E,L=['rotation,year,source_year,crop,cover,yield_fraction,net_usd_per_acre,water_af_per_acre'];['cur','prop'].forEach(k=>E[k].first.forEach((r,j)=>{const w=r.rows[0];L.push([k,j+1,r.srcYear,r.slot.crop,r.slot.cover||'',w.Y==null?'':w.Y.toFixed(3),w.net==null||w.unmodeled?'':(w.net/PLOT_AC).toFixed(0),w.pull==null?'':(w.pull/304.8).toFixed(3)].join(','))}));download('rotate-and-thrive-run.csv',L.join('\n'),'text/csv')}
function showEvidence(){const r=U.rec;document.getElementById('evBody').innerHTML=`<h2>Model &amp; limits</h2><ul>${dataStatus().map(([a,c,t])=>`<li><b>${a}</b> (${c==='ok'?'available':c==='bad'?'unavailable':'partial'}): ${esc(t)}</li>`).join('')}</ul>${r?`<p class="tiny">${esc(r.source)}${r.retrieved?', retrieved '+r.retrieved:''}. ${esc((window.WEATHER_META||{}).note||'')}</p>`:''}<h3>Scores</h3><ul>${SCORE_CATS.map(([k,e,l,d])=>`<li><b>${e} ${l}.</b> ${esc(d)}</li>`).join('')}<li><b>Overall.</b> 40% your priority + 12% each other.</li></ul><h3>Model (educational, unvalidated)</h3><ul>${ASSUMPTIONS.map(([a,t])=>`<li><b>${a}.</b> ${esc(t)}</li>`).join('')}</ul><p>One representative 40-acre field. No farm advisor has reviewed this.</p>`;document.getElementById('ev').showModal()}

/* ---------- actions ---------- */
function addCrop(k,id,at){const rot=U.rots[k];U.msg[k]='';reset();
  if(U.sel&&U.sel.rot===k&&at==null)at=U.sel.i;
  if(at!=null&&rot[at]){const s=rot[at];s.crop=id;const cf=coverConflict(id,s.cover,U.zone);if(cf){s.cover=null;U.msg[k]='Cover removed — overlaps crop.'}}else rot.push({crop:id,cover:null});
  if(rot.length>20){rot.length=20;U.msg[k]='Max 20 years.'}U.sel=null;U.cq[k]='';render()}
document.addEventListener('click',e=>{
  const ctl=e.target.closest('[data-act]');
  if(!ctl){const s=e.target.closest('[data-slot]');if(s&&!e.target.closest('select')){const[k,i]=s.dataset.slot.split(':');U.sel=U.sel&&U.sel.rot===k&&U.sel.i===+i?null:{rot:k,i:+i};render();const inp=document.getElementById('cq-'+k);inp&&inp.focus()}return}
  const act=ctl.dataset.act,v=ctl.dataset.v,id=ctl.dataset.id,k=ctl.dataset.rot,i=+ctl.dataset.i;
  const H={
   pick:()=>{const g=GAZ.find(x=>x.id===id);U.q=g.name;loadLoc({...g})},nearby:useNearby,synth:useSynthetic,
   pri:()=>{U.priority=v;change()},
   demo:async()=>{U.q='Five Points';await loadLoc({...GAZ.find(x=>x.id==='five-points')});if(U.recState!=='ready')return;U.horizon=9;U.seed=57;U.priority='soil';U.alloc=100;U.soil='sandy loam';U.mg={equip:[],fert:'standard',irrig:'full'};U.rots.cur=[{crop:'tomato',cover:null}];U.rots.prop=ROT_PRESETS.tgwc[1]('sjv');runSim()},
   addcrop:()=>addCrop(k,id),focussearch:()=>{U.sel=null;const inp=document.getElementById('cq-'+k);inp&&inp.focus()},
   mvleft:()=>{const r=U.rots[k];[r[i-1],r[i]]=[r[i],r[i-1]];U.sel=null;change()},mvright:()=>{const r=U.rots[k];[r[i+1],r[i]]=[r[i],r[i+1]];U.sel=null;change()},
   rmslot:()=>{U.rots[k].splice(i,1);U.sel=null;change()},
   usesug:runSearch,usecand:()=>{const keep=U.sugRes;U.rots.prop=copy(keep.list[i].rot);U.sel=null;change();U.sugRes=keep;render()},
   run:runSim,tplay:()=>{if(U.timer){stop();render()}else play()},tprev:()=>{stop();U.t=Math.max(1,U.t-1);render()},tnext:()=>{stop();U.t=Math.min(U.horizon,U.t+1);render()},
   replay:()=>{U.t=1;play()},newweather:()=>{U.seed+=1000;runSim()},
   'export-json':exportJSON,'export-csv':exportCSV};
  if(H[act])H[act]()});
document.addEventListener('keydown',e=>{
  if(e.target.matches&&e.target.matches('[data-slot]')&&(e.key==='Enter'||e.key===' ')){e.preventDefault();const[k,i]=e.target.dataset.slot.split(':');U.sel=U.sel&&U.sel.rot===k&&U.sel.i===+i?null:{rot:k,i:+i};render();const inp=document.getElementById('cq-'+k);inp&&inp.focus();return}
  if(e.target.dataset&&e.target.dataset.cq){const k=e.target.dataset.cq;if(e.key==='Enter'){const m=cropMatches(U.cq[k])[0];if(m){e.preventDefault();addCrop(k,m.id)}}if(e.key==='Escape'){U.cq[k]='';U.sel=null;render()}}
  if(e.target.id==='q'&&e.key==='Enter'){const m=search(U.q)[0];if(m){e.preventDefault();U.q=m.name;loadLoc({...m})}}});
document.addEventListener('input',e=>{const t=e.target;
  if(t.id==='q'){U.q=t.value;const ll=parseLL(U.q);U.matches=ll?[]:search(U.q);render();if(ll){clearTimeout(U._t);U._t=setTimeout(()=>loadLoc({name:'Typed coordinates',...ll}),700)}}
  if(t.dataset&&t.dataset.cq){U.cq[t.dataset.cq]=t.value;render()}
  if(t.id==='tr'){stop();U.t=+t.value;render()}
  if(t.id==='hz'){U.horizon=+t.value;change()}
  if(t.id==='soil'){U.soil=t.value;change()}if(t.id==='alloc'){U.alloc=+t.value;change()}
  if(t.id==='fert'){U.mg.fert=t.value;change()}if(t.id==='irrig'){U.mg.irrig=t.value;change()}
  if(t.dataset&&t.dataset.eq){const a=U.mg.equip,k=t.dataset.eq,p=a.indexOf(k);t.checked?(p<0&&a.push(k)):(p>=0&&a.splice(p,1));change()}});
document.addEventListener('change',e=>{const t=e.target;
  if(t.dataset&&t.dataset.cv){const[k,i]=t.dataset.cv.split(':');U.rots[k][+i].cover=t.value||null;change()}
  if(t.dataset&&t.dataset.preset&&t.value){const k=t.dataset.preset;U.rots[k]=copy(ROT_PRESETS[t.value][1](U.zone));U.sel=null;change()}});
document.addEventListener('dragstart',e=>{const d=e.target.closest('[data-drag]');if(d){e.dataTransfer.setData('text/plain',d.dataset.drag);e.dataTransfer.effectAllowed='copyMove'}});
document.addEventListener('dragover',e=>{const t=e.target.closest('[data-slot],[data-drag-add]');if(t){e.preventDefault();t.classList.add('over')}});
document.addEventListener('dragleave',e=>{const t=e.target.closest('[data-slot],[data-drag-add]');if(t)t.classList.remove('over')});
document.addEventListener('drop',e=>{const t=e.target.closest('[data-slot],[data-drag-add]');if(!t)return;e.preventDefault();const tok=e.dataTransfer.getData('text/plain');if(!tok)return;const p=tok.split(':');
  const dest=t.dataset.slot?t.dataset.slot.split(':'):[t.dataset.dragAdd,null];
  if(p[0]==='crop')addCrop(dest[0],p[1],dest[1]==null?null:+dest[1]);
  else if(p[0]==='slot'&&p[1]===dest[0]){const r=U.rots[p[1]],from=+p[2],to=dest[1]==null?r.length-1:+dest[1];const[m]=r.splice(from,1);r.splice(to,0,m);U.sel=null;change()}});
document.getElementById('evBtn').onclick=showEvidence;
render();

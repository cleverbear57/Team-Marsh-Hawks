# Rotate & Thrive — Team Marsh Hawks (NASA Space Apps 2026)

One-page crop-rotation explorer for a single representative 40-acre field. Search a California place → build your **current rotation** and a **proposed rotation** (any length, 1–20 years, each year = a crop + optional winter cover) → press Run: a 0–100 scoreboard (incl. dry-year resilience) appears and steps through the simulation year by year (play/pause/scrub). “✨ Suggest” fills the proposal with an auto-generated alternative.

## Run it
```bash
python3 -m http.server 8765      # from this folder (serve over http, not file://)
```
Open http://localhost:8765/ — `tests.html` runs the functional tests.

## Files
`index.html` + `game.css` + `game.js` (UI) · `gamecore.js` (simulation, scoring, rotation logic) · `data/crops.js` (35-crop catalog) · `data/gazetteer.js`, `data/weather.js` (cached NASA POWER for 63 places) · `raw/power/` (raw API responses) · `tools/fetch_power.py` (refresh the cache; needs curl) · `legacy/` (earlier multi-plot and detailed-analysis pages).

## How it works
Each rotation is run over the chosen number of years (repeating the cycle) on **30 resampled sequences of 2001–2025 NASA POWER weather**; all rotations see identical weather and prices. Scores (Water, Soil, Fertilizer, Pests, Income, Dry-year resilience, Overall) are medians with a 10th–90th spread. Overall = 40% your priority + 12% each of the others. Formulas are on the page.

## Honest limits
- Weather is NASA POWER monthly reanalysis (MERRA-2 grid, ~50 km), not an on-farm station; years are resampled in contiguous seeded blocks — a scenario, not a forecast.
- Crop, cost, yield and soil coefficients are **educational estimates** (see “Evidence & model”). Nothing is calibrated or validated; no farm advisor has reviewed it.
- Soil is an editable regional texture default; SSURGO retrieval, SMAP/GPM/ECOSTRESS/GRACE inside the model, rice, salinity and markets are not implemented. The soil measure is a 0–100 proxy, not % organic matter.
- If NASA POWER is unreachable for a custom pin, the page says so and offers cached nearby data or clearly labeled *illustrative* weather — never silent fake data.
